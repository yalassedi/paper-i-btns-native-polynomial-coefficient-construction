"""
Unit tests for run_wfc_ablation.py, the WFC ablation evidence runner used by
PythonApplication157 under Script Contract v28.

These tests verify that the ablation runner exposes the required v28 branches,
executes them through the already validated BTNS/WFC construction stack, writes
machine-readable sidecars, and remains a runner/evidence layer rather than a
new arithmetic, WFC-selection, or Certified-construction implementation.
"""

from __future__ import annotations

import ast
import csv
import inspect
import json
from pathlib import Path
import tempfile
import unittest

import audit
import btns_core as core
import btns_poly as poly
import btns_wfc as wfc
import run_wfc_ablation as ablation


def one(trace_id: str = "ONE", *, k_min: int = -1, k_max: int = 1) -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(trace_id: str = "TWO", *, k_min: int = -1, k_max: int = 1) -> core.BTNSNumber:
    return core.add_btns(
        one(trace_id=trace_id + "_A", k_min=k_min, k_max=k_max),
        one(trace_id=trace_id + "_B", k_min=k_min, k_max=k_max),
    )


def base_config(**overrides: object) -> poly.CampaignConfig:
    params: dict[str, object] = {
        "k_min": -1,
        "k_max": 1,
        "trace_prefix": "TEST_WFC_ABLATION_V28",
        "wfc_window_width": 1,
        "wfc_policy": wfc.RN_ZERO,
    }
    params.update(overrides)
    return poly.CampaignConfig(**params)


class TestAblationBranchConfig(unittest.TestCase):
    def test_required_branch_tokens_are_present_and_ordered(self) -> None:
        self.assertEqual(
            ablation.REQUIRED_WFC_ABLATION_BRANCHES,
            (
                ablation.A0_CANONIZE_ONLY_BASELINE,
                ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
                ablation.A2_FULL_WFC_RN_EVEN_MAIN_WINDOW,
                ablation.A3_FULL_WFC_SMALLER_WINDOW,
                ablation.A4_FULL_WFC_LARGER_WINDOW,
            ),
        )

    def test_default_branch_configs_include_baseline_rn_zero_rn_even_and_window_variants(self) -> None:
        cfg = base_config(k_min=-2, k_max=1, wfc_window_width=1)
        branches = ablation.make_default_ablation_branch_configs(cfg)

        self.assertEqual([branch.branch_id for branch in branches], list(ablation.REQUIRED_WFC_ABLATION_BRANCHES))
        self.assertFalse(branches[0].wfc_enabled)
        self.assertFalse(branches[0].canonize_each_stage)
        self.assertIsNone(branches[0].policy)
        self.assertEqual(branches[1].policy, wfc.RN_ZERO)
        self.assertEqual(branches[2].policy, wfc.RN_EVEN)
        self.assertEqual(branches[1].window_width, 1)
        self.assertEqual(branches[3].window_width, 0)
        self.assertEqual(branches[4].window_width, 2)

    def test_branch_config_rejects_unknown_branch_and_bad_policy(self) -> None:
        with self.assertRaises(ValueError):
            ablation.WFCAblationBranchConfig("BAD_BRANCH", True, 0, wfc.RN_ZERO, True)
        with self.assertRaises(ValueError):
            ablation.WFCAblationBranchConfig(
                ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
                True,
                0,
                "RN_BAD",
                True,
            )
        with self.assertRaises(ValueError):
            ablation.WFCAblationBranchConfig(
                ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
                True,
                -1,
                wfc.RN_ZERO,
                True,
            )

    def test_branch_config_as_dict_is_machine_readable(self) -> None:
        branch = ablation.WFCAblationBranchConfig(
            ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
            True,
            1,
            wfc.RN_ZERO,
            True,
            "main",
        )
        row = branch.as_dict()
        self.assertEqual(row["branch_id"], ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW)
        self.assertTrue(row["wfc_enabled"])
        self.assertEqual(row["policy"], wfc.RN_ZERO)


class TestRunWFCAblation(unittest.TestCase):
    def test_run_wfc_ablation_executes_all_required_branches(self) -> None:
        cfg = base_config()
        result = ablation.run_wfc_ablation((one("R1"), two("R2")), cfg)

        self.assertEqual(result.m, 2)
        self.assertEqual(len(result.branch_results), 5)
        self.assertEqual(len(result.summary_records), 5)
        self.assertEqual({row.branch_id for row in result.summary_records}, set(ablation.REQUIRED_WFC_ABLATION_BRANCHES))
        self.assertTrue(all(branch.status == ablation.WFC_ABLATION_BRANCH_COMPLETE for branch in result.branch_results))

    def test_baseline_branch_is_canonize_only_and_not_reported_as_full_wfc(self) -> None:
        cfg = base_config()
        result = ablation.run_wfc_ablation((one("R1"), two("R2")), cfg)
        baseline = next(item for item in result.branch_results if item.branch_config.branch_id == ablation.A0_CANONIZE_ONLY_BASELINE)
        baseline_summary = next(row for row in result.summary_records if row.branch_id == ablation.A0_CANONIZE_ONLY_BASELINE)

        self.assertFalse(baseline.branch_config.wfc_enabled)
        self.assertFalse(baseline.branch_config.canonize_each_stage)
        self.assertEqual(baseline_summary.candidate_count_total, 0)
        self.assertEqual(baseline_summary.strict_candidate_count_total, 0)
        self.assertIsNotNone(baseline.noncertified_result)
        self.assertTrue(all(item.trace.wfc_status == wfc.WFC_NOT_APPLICABLE for item in baseline.noncertified_result.wfc_results))

    def test_full_wfc_branches_have_candidate_metrics_and_matched_depth_counts(self) -> None:
        cfg = base_config()
        result = ablation.run_wfc_ablation((one("R1"), two("R2")), cfg)
        records = {row.branch_id: row for row in result.summary_records}

        for branch_id in (
            ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
            ablation.A2_FULL_WFC_RN_EVEN_MAIN_WINDOW,
            ablation.A3_FULL_WFC_SMALLER_WINDOW,
            ablation.A4_FULL_WFC_LARGER_WINDOW,
        ):
            row = records[branch_id]
            self.assertTrue(row.wfc_enabled)
            self.assertGreater(row.candidate_count_total, 0)
            self.assertGreater(row.strict_candidate_count_total, 0)
            self.assertEqual(row.matched_depth_NOT_RUN_INVALID_count, 0)
            self.assertEqual(row.branch_status, ablation.WFC_ABLATION_BRANCH_COMPLETE)

    def test_run_wfc_ablation_with_gold_marks_exact_roots_true(self) -> None:
        result = ablation.run_wfc_ablation_from_root_strings(("1", "2"), k_min=-1, k_max=1, build_gold=True)

        self.assertEqual(len(result.summary_records), 5)
        for row in result.summary_records:
            self.assertEqual(row.FALSE_count, 0)
            self.assertEqual(row.TRUE_count, 3)
            self.assertEqual(row.TUBE_count, 0)

    def test_missing_required_branch_raises(self) -> None:
        cfg = base_config()
        partial = ablation.make_default_ablation_branch_configs(cfg)[:4]
        with self.assertRaises(ValueError):
            ablation.run_wfc_ablation((one("R1"), two("R2")), cfg, branch_configs=partial)

    def test_invalid_roots_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ablation.run_wfc_ablation(tuple(), base_config())
        with self.assertRaises(ValueError):
            ablation.run_wfc_ablation((object(),), base_config())  # type: ignore[arg-type]

    def test_summary_records_as_dicts_preserves_branch_rows(self) -> None:
        result = ablation.run_wfc_ablation((one("R1"), two("R2")), base_config())
        rows = ablation.summary_records_as_dicts(result)

        self.assertEqual(len(rows), 5)
        self.assertTrue(all("branch_id" in row for row in rows))
        self.assertTrue(all("candidate_count_total" in row for row in rows))
        self.assertTrue(all("matched_depth_EQUAL_count" in row for row in rows))

    def test_run_result_as_dict_contains_configs_and_sensitivity_tokens(self) -> None:
        result = ablation.run_wfc_ablation((one("R1"), two("R2")), base_config())
        payload = result.as_dict()

        self.assertEqual(payload["m"], 2)
        self.assertIn("branch_configs", payload)
        self.assertIn("summary_records", payload)
        self.assertIn(result.window_sensitivity_token, {ablation.WFC_NO_OBSERVED_EFFECT, ablation.WFC_WINDOW_SENSITIVITY_DETECTED})
        self.assertIn(result.policy_sensitivity_token, {ablation.WFC_NO_OBSERVED_EFFECT, ablation.WFC_POLICY_SENSITIVITY_DETECTED})


class TestAblationSidecarOutputs(unittest.TestCase):
    def test_write_wfc_ablation_outputs_creates_required_sidecars(self) -> None:
        result = ablation.run_wfc_ablation_from_root_strings(("1", "2"), k_min=-1, k_max=1, build_gold=True)
        with tempfile.TemporaryDirectory() as tmp:
            paths = ablation.write_wfc_ablation_outputs(result, tmp)
            expected = {
                "wfc_ablation_config.json",
                "wfc_ablation_summary.csv",
                "wfc_window_sensitivity.csv",
                "wfc_tie_policy_ablation.csv",
            }
            self.assertEqual(set(paths), expected)
            for path in paths.values():
                self.assertTrue(Path(path).exists())

            config_payload = json.loads(Path(paths["wfc_ablation_config.json"]).read_text(encoding="utf-8"))
            self.assertEqual(set(config_payload["required_branches"]), set(ablation.REQUIRED_WFC_ABLATION_BRANCHES))

            with Path(paths["wfc_ablation_summary.csv"]).open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 5)
            self.assertEqual({row["branch_id"] for row in rows}, set(ablation.REQUIRED_WFC_ABLATION_BRANCHES))

    def test_window_and_policy_sidecars_contain_expected_tokens(self) -> None:
        result = ablation.run_wfc_ablation_from_root_strings(("1", "2"), k_min=-1, k_max=1, build_gold=True)
        with tempfile.TemporaryDirectory() as tmp:
            paths = ablation.write_wfc_ablation_outputs(result, tmp)
            with Path(paths["wfc_window_sensitivity.csv"]).open("r", encoding="utf-8", newline="") as handle:
                window_rows = list(csv.DictReader(handle))
            with Path(paths["wfc_tie_policy_ablation.csv"]).open("r", encoding="utf-8", newline="") as handle:
                policy_rows = list(csv.DictReader(handle))

        self.assertEqual(len(window_rows), 1)
        self.assertEqual(len(policy_rows), 1)
        self.assertIn(window_rows[0]["token"], {ablation.WFC_NO_OBSERVED_EFFECT, ablation.WFC_WINDOW_SENSITIVITY_DETECTED})
        self.assertIn(policy_rows[0]["token"], {ablation.WFC_NO_OBSERVED_EFFECT, ablation.WFC_POLICY_SENSITIVITY_DETECTED})
        self.assertEqual(policy_rows[0]["rn_zero_branch"], ablation.A1_FULL_WFC_RN_ZERO_MAIN_WINDOW)
        self.assertEqual(policy_rows[0]["rn_even_branch"], ablation.A2_FULL_WFC_RN_EVEN_MAIN_WINDOW)


class TestAblationAuditAndBoundarySafety(unittest.TestCase):
    def test_audit_final_package_passes_with_real_ablation_runner_present(self) -> None:
        report = audit.audit_project(Path(__file__).resolve().parent, stage=audit.STAGE_FINAL_PACKAGE)
        self.assertEqual(report.status, audit.STATUS_PASS)
        self.assertEqual(len(report.violations), 0)

    def test_ablation_source_does_not_implement_wfc_selection_or_arithmetic_directly(self) -> None:
        source = inspect.getsource(ablation)
        tree = ast.parse(source)
        forbidden_calls = {
            "strict_wfc",
            "select_wfc_candidate",
            "propagate_wfc_candidate",
            "enumerate_wfc_candidates",
            "normalize_digits",
            "add_btns",
            "mul_btns",
            "sub_btns",
            "neg_btns",
            "certify_operation",
            "certify_coefficient",
        }
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_ablation_source_uses_allowed_runner_dependencies(self) -> None:
        source = inspect.getsource(ablation)
        self.assertIn("from btns_poly import", source)
        self.assertIn("from ingress import", source)
        self.assertIn("from gold_reference import", source)
        self.assertIn("from btns_wfc import", source)
        self.assertNotIn("from decimal", source)
        self.assertNotIn("import numpy", source)
        self.assertNotIn("import sympy", source)
        self.assertNotIn("openpyxl", source)

    def test_run_wfc_ablation_import_does_not_create_output_files(self) -> None:
        # Output creation is explicit through write_wfc_ablation_outputs(), not import side effects.
        with tempfile.TemporaryDirectory() as tmp:
            before = set(Path(tmp).iterdir())
            result = ablation.run_wfc_ablation((one("R1"), two("R2")), base_config())
            after_run = set(Path(tmp).iterdir())
            self.assertEqual(before, after_run)
            ablation.write_wfc_ablation_outputs(result, tmp)
            after_write = set(Path(tmp).iterdir())
            self.assertGreater(len(after_write), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
