"""
Unit tests for run_m10_stress_campaign.py.

These tests verify the stress/evidence harness for adaptive Certified rebuild
and WFC sensitivity.  The stress runner is diagnostic evidence complementary to
the clean run_m10_campaign.py; it must not replace the production construction
pipeline.
"""

from __future__ import annotations

import ast
import csv
import inspect
import json
from pathlib import Path
import tempfile
import unittest

import btns_poly as poly
import btns_wfc as wfc
import run_m10_stress_campaign as stress


class TestAdaptiveStressEvidence(unittest.TestCase):
    def test_adaptive_stress_rows_include_refine_rebuild_and_tube_hold(self) -> None:
        rows, cost_rows = stress.adaptive_rebuild_stress_rows()
        tokens = {row.get("expected_token") for row in rows}
        governance = {row.get("governance_token") for row in rows}

        self.assertIn(poly.CERT_REFINE, tokens)
        self.assertIn(poly.CERT_REBUILD, tokens)
        self.assertIn(poly.CERT_TUBE_HOLD, tokens)
        self.assertIn(poly.CERT_REFINE_REQUEST, governance)
        self.assertIn(poly.CERT_REBUILD, governance)
        self.assertIn(poly.CERT_TUBE_HOLD, governance)
        self.assertGreaterEqual(len(cost_rows), 3)

    def test_rebuild_case_reduces_external_gold_error(self) -> None:
        rows, _ = stress.adaptive_rebuild_stress_rows()
        rebuild = next(row for row in rows if row["stress_case_id"] == "ADAPT_REBUILD_AFTER_REFINE")

        self.assertEqual(rebuild["governance_token"], poly.CERT_REBUILD)
        self.assertTrue(rebuild["error_reduction_detected"])
        self.assertLess(float(rebuild["rebuild_total_abs_error"]), float(rebuild["initial_total_abs_error"]))
        self.assertEqual(rebuild["matched_depth_records_initial"], 11)
        self.assertEqual(rebuild["matched_depth_records_rebuild"], 11)

    def test_tube_hold_case_uses_strict_empty_wfc(self) -> None:
        rows, _ = stress.adaptive_rebuild_stress_rows()
        tube = next(row for row in rows if row["stress_case_id"] == "ADAPT_TUBE_HOLD_STRICT_EMPTY_WFC")

        self.assertEqual(tube["wfc_status"], wfc.WFC_UNDEFINED_STRICT_EMPTY)
        self.assertEqual(tube["selection_certificate_token"], poly.CERT_TUBE_HOLD)
        self.assertEqual(tube["strict_candidate_count"], 0)
        self.assertEqual(tube["candidate_count"], 3)
        self.assertTrue(tube["valid_trace"])


class TestWFCSensitivityEvidence(unittest.TestCase):
    def test_wfc_sensitivity_rows_detect_policy_and_window_sensitivity(self) -> None:
        rows = stress.wfc_sensitivity_stress_rows()
        by_id = {row["stress_case_id"]: row for row in rows}

        policy = by_id["WFC_POLICY_RN_ZERO_VS_RN_EVEN"]
        window = by_id["WFC_WINDOW_SMALL_VS_LARGE"]

        self.assertTrue(policy["sensitivity_detected"])
        self.assertTrue(window["sensitivity_detected"])
        self.assertEqual(policy["policy_a"], wfc.RN_ZERO)
        self.assertEqual(policy["policy_b"], wfc.RN_EVEN)
        self.assertNotEqual(policy["selected_c_in_a"], policy["selected_c_in_b"])
        self.assertNotEqual(window["selected_c_in_a"], window["selected_c_in_b"])
        self.assertTrue(policy["valid_trace_a"])
        self.assertTrue(policy["valid_trace_b"])
        self.assertTrue(window["valid_trace_a"])
        self.assertTrue(window["valid_trace_b"])


class TestStressRunnerOutputs(unittest.TestCase):
    def test_run_stress_campaign_writes_required_sidecars_and_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            summary = stress.run_stress_campaign(tmp)
            expected = {
                "adaptive_rebuild_stress.csv",
                "wfc_sensitivity_stress.csv",
                "stress_operation_cost_accounting.csv",
                "stress_audit_summary.csv",
                "stress_run_summary.json",
            }
            self.assertEqual(summary["stress_status"], stress.STRESS_VALID_RUN)
            self.assertTrue(summary["cert_refine_observed"])
            self.assertTrue(summary["cert_rebuild_observed"])
            self.assertTrue(summary["cert_tube_hold_observed"])
            self.assertTrue(summary["wfc_policy_sensitivity_detected"])
            self.assertTrue(summary["wfc_window_sensitivity_detected"])
            for name in expected:
                self.assertTrue((Path(tmp) / name).exists(), name)

            with (Path(tmp) / "stress_run_summary.json").open("r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            self.assertEqual(loaded["runner"], stress.RUNNER_NAME)

            with (Path(tmp) / "adaptive_rebuild_stress.csv").open("r", encoding="utf-8", newline="") as handle:
                adaptive_rows = list(csv.DictReader(handle))
            self.assertEqual(len(adaptive_rows), 3)

            with (Path(tmp) / "wfc_sensitivity_stress.csv").open("r", encoding="utf-8", newline="") as handle:
                wfc_rows = list(csv.DictReader(handle))
            self.assertEqual(len(wfc_rows), 2)

    def test_self_check_runs(self) -> None:
        stress.self_check()

    def test_consolidated_stress_runner_has_current_stage_defaults(self) -> None:
        source = inspect.getsource(stress)
        self.assertIn('default="btns_m10_stress_output_157"', source)
        self.assertNotIn('default="btns_m10_stress_output_153"', source)
        self.assertIn('source_base_package', source)


class TestStressRunnerBoundarySafety(unittest.TestCase):
    def test_stress_runner_is_not_a_new_arithmetic_or_wfc_selection_kernel(self) -> None:
        source = inspect.getsource(stress)
        tree = ast.parse(source)
        forbidden_calls = {
            "add_btns",
            "mul_btns",
            "sub_btns",
            "neg_btns",
            "normalize_digits",
            "select_wfc_candidate",
            "propagate_wfc_candidate",
            "enumerate_wfc_candidates",
        }
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_stress_runner_uses_expected_delegates(self) -> None:
        source = inspect.getsource(stress)
        self.assertIn("build_polynomial_coeffs_certified_independent", source)
        self.assertIn("build_polynomial_coeffs_noncertified_matched_depth", source)
        self.assertIn("request_certified_refinement", source)
        self.assertIn("strict_wfc", source)
        self.assertNotIn("openpyxl", source)
        self.assertNotIn("numpy", source)
        self.assertNotIn("sympy", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
