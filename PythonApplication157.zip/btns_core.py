"""
btns_core.py

Core BTNS arithmetic kernel for Script Contract v28.

This module preserves the P129/v22 integer-only balanced-ternary arithmetic
kernel while replacing the old canonization wrapper with a v28-compliant
strict WFC boundary call through canonize_btns().

Construction-boundary guarantees:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel, workbook, gold-reference, egress, or reporting calls
    - WFC is delegated only to btns_wfc.strict_wfc()
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
from typing import Dict, Iterable, Optional, Tuple

from btns_wfc import (
    WFCConfig,
    WFCSelectionResult,
    strict_wfc,
    WFC_NOT_APPLICABLE,
    WFC_UNDEFINED_STRICT_EMPTY,
)


RADIX = 3
DIGIT_SET = (-1, 0, 1)

CANONICAL_LEGAL = "LEGAL"
CANONICAL_ILLEGAL = "ILLEGAL"
CANONICAL_PENDING = "PENDING"

SOURCE_INGRESS = "INGRESS"
SOURCE_ARITHMETIC = "ARITHMETIC"
SOURCE_COEFFICIENT = "COEFFICIENT"
SOURCE_CERTIFIED = "CERTIFIED"
SOURCE_REPORT = "REPORT"
SOURCE_TEST = "TEST"

TAIL_NONE = "TAIL_NONE"
TAIL_INGRESS_ROUNDING = "TAIL_INGRESS_ROUNDING"
TAIL_MULTIPLICATION_TRUNCATION = "TAIL_MULTIPLICATION_TRUNCATION"
TAIL_CANONIZATION = "TAIL_CANONIZATION"
TAIL_OVERFLOW = "TAIL_OVERFLOW"
TAIL_REFINEMENT = "TAIL_REFINEMENT"

_ALLOWED_CANONICALITY = {CANONICAL_LEGAL, CANONICAL_ILLEGAL, CANONICAL_PENDING}
_ALLOWED_SOURCE_TAGS = {
    SOURCE_INGRESS,
    SOURCE_ARITHMETIC,
    SOURCE_COEFFICIENT,
    SOURCE_CERTIFIED,
    SOURCE_REPORT,
    SOURCE_TEST,
    "UNSPECIFIED",
}
_ALLOWED_TAIL_POLICIES = {
    TAIL_NONE,
    TAIL_INGRESS_ROUNDING,
    TAIL_MULTIPLICATION_TRUNCATION,
    TAIL_CANONIZATION,
    TAIL_OVERFLOW,
    TAIL_REFINEMENT,
}


@dataclass(frozen=True)
class TailBound:
    """Structured base-3 absolute tail bound: abs(T) <= num / 3**den_power3."""

    lower_exp: int
    abs_bound_num: int
    abs_bound_den_power3: int
    policy: str
    source: str

    def __post_init__(self) -> None:
        if not isinstance(self.lower_exp, int):
            raise TypeError("lower_exp must be int")
        if not isinstance(self.abs_bound_num, int):
            raise TypeError("abs_bound_num must be int")
        if not isinstance(self.abs_bound_den_power3, int):
            raise TypeError("abs_bound_den_power3 must be int")
        if self.abs_bound_num < 0:
            raise ValueError("abs_bound_num must be non-negative")
        if self.abs_bound_den_power3 < 0:
            raise ValueError("abs_bound_den_power3 must be non-negative")
        if self.policy not in _ALLOWED_TAIL_POLICIES:
            raise ValueError(f"unregistered tail policy: {self.policy}")
        if not isinstance(self.source, str) or not self.source:
            raise ValueError("source must be a non-empty string")

    @property
    def is_zero(self) -> bool:
        return self.abs_bound_num == 0


@dataclass(frozen=True)
class BTNSNumber:
    """Finite BTNS number object over digits {-1, 0, +1}."""

    digits: Dict[int, int]
    k_min: int
    k_max: int
    radix: int = RADIX
    digit_set: Tuple[int, int, int] = DIGIT_SET
    tail_bound: Optional[TailBound] = None
    canonicality_flag: str = CANONICAL_PENDING
    source_tag: str = "UNSPECIFIED"
    precision_depth: Optional[int] = None
    trace_id: Optional[str] = None
    wfc_trace_id: Optional[str] = None
    wfc_status: Optional[str] = None

    def __post_init__(self) -> None:
        if self.radix != RADIX:
            raise ValueError("BTNS radix must be 3")
        if tuple(self.digit_set) != DIGIT_SET:
            raise ValueError("BTNS digit_set must be (-1, 0, 1)")
        if not isinstance(self.k_min, int) or not isinstance(self.k_max, int):
            raise TypeError("k_min and k_max must be int")
        if self.k_min > self.k_max:
            raise ValueError("k_min must be <= k_max")
        if self.canonicality_flag not in _ALLOWED_CANONICALITY:
            raise ValueError(f"unregistered canonicality flag: {self.canonicality_flag}")
        if self.source_tag not in _ALLOWED_SOURCE_TAGS:
            raise ValueError(f"unregistered source tag: {self.source_tag}")
        if self.precision_depth is not None and not isinstance(self.precision_depth, int):
            raise TypeError("precision_depth must be int or None")
        if self.trace_id is not None and not isinstance(self.trace_id, str):
            raise TypeError("trace_id must be str or None")
        if self.wfc_trace_id is not None and not isinstance(self.wfc_trace_id, str):
            raise TypeError("wfc_trace_id must be str or None")
        if self.wfc_status is not None and not isinstance(self.wfc_status, str):
            raise TypeError("wfc_status must be str or None")
        if self.tail_bound is not None and not isinstance(self.tail_bound, TailBound):
            raise TypeError("tail_bound must be TailBound or None")

        clean: Dict[int, int] = {}
        for key, value in self.digits.items():
            if not isinstance(key, int):
                raise TypeError("digit exponent keys must be int")
            if not isinstance(value, int):
                raise TypeError("digits must be int")
            if value not in DIGIT_SET:
                raise ValueError(f"non-canonical BTNS digit at exponent {key}: {value}")
            if self.k_min <= key <= self.k_max:
                clean[key] = value
            elif value != 0:
                raise ValueError("nonzero digit outside [k_min, k_max]")

        for exponent in range(self.k_min, self.k_max + 1):
            clean.setdefault(exponent, 0)

        object.__setattr__(self, "digits", clean)


def _pow3(exp: int) -> int:
    if exp < 0:
        raise ValueError("power exponent must be non-negative")
    return RADIX ** exp


def _stable_trace_id(parts: Iterable[object]) -> str:
    text = "|".join(str(part) for part in parts)
    return sha256(text.encode("utf-8")).hexdigest()[:32]


def _digits_signature(digits: Dict[int, int]) -> Tuple[Tuple[int, int], ...]:
    return tuple(sorted((int(k), int(v)) for k, v in digits.items() if v != 0))


def _tail_to_bound_pair(tail: Optional[TailBound]) -> Tuple[int, int]:
    if tail is None or tail.abs_bound_num == 0:
        return 0, 0
    return tail.abs_bound_num, tail.abs_bound_den_power3


def _add_bound_pairs(a: Tuple[int, int], b: Tuple[int, int]) -> Tuple[int, int]:
    an, ad = a
    bn, bd = b
    if an == 0:
        return bn, bd
    if bn == 0:
        return an, ad
    common = ad if ad >= bd else bd
    total = an * _pow3(common - ad) + bn * _pow3(common - bd)
    return total, common


def _mul_bound_pairs(a: Tuple[int, int], b: Tuple[int, int]) -> Tuple[int, int]:
    an, ad = a
    bn, bd = b
    if an == 0 or bn == 0:
        return 0, 0
    return an * bn, ad + bd


def _make_tail(
    pair: Tuple[int, int],
    lower_exp: int,
    policy: str,
    source: str,
) -> Optional[TailBound]:
    num, den = pair
    if num == 0:
        return None
    return TailBound(
        lower_exp=lower_exp,
        abs_bound_num=num,
        abs_bound_den_power3=den,
        policy=policy,
        source=source,
    )


def _combine_tails(
    *tails: Optional[TailBound],
    lower_exp: int,
    policy: str,
    source: str,
) -> Optional[TailBound]:
    pair = (0, 0)
    for tail in tails:
        pair = _add_bound_pairs(pair, _tail_to_bound_pair(tail))
    return _make_tail(pair, lower_exp=lower_exp, policy=policy, source=source)


def _abs_bound_of_digits(digits: Dict[int, int]) -> Tuple[int, int]:
    nonzero = [(k, abs(v)) for k, v in digits.items() if v != 0]
    if not nonzero:
        return 0, 0
    min_exp = min(k for k, _ in nonzero)
    den = -min_exp if min_exp < 0 else 0
    num = 0
    for exponent, value in nonzero:
        num += value * _pow3(exponent + den)
    return num, den


def _abs_bound_of_number(x: BTNSNumber) -> Tuple[int, int]:
    digit_pair = _abs_bound_of_digits(x.digits)
    tail_pair = _tail_to_bound_pair(x.tail_bound)
    return _add_bound_pairs(digit_pair, tail_pair)


def _tail_from_omitted_digits(
    omitted_digits: Dict[int, int],
    policy: str,
    source: str,
) -> Optional[TailBound]:
    if not omitted_digits:
        return None
    lower_exp = min(omitted_digits)
    pair = _abs_bound_of_digits(omitted_digits)
    return _make_tail(pair, lower_exp=lower_exp, policy=policy, source=source)


def validate_digits(x: BTNSNumber) -> bool:
    """Return True only if x is a legal finite BTNS digit object."""

    if not isinstance(x, BTNSNumber):
        return False
    if x.radix != RADIX or tuple(x.digit_set) != DIGIT_SET:
        return False
    if x.k_min > x.k_max:
        return False
    for exponent, digit in x.digits.items():
        if not isinstance(exponent, int) or not isinstance(digit, int):
            return False
        if digit not in DIGIT_SET:
            return False
        if not (x.k_min <= exponent <= x.k_max):
            return False
    return all(exponent in x.digits for exponent in range(x.k_min, x.k_max + 1))


def normalize_digits(
    raw_digits: Dict[int, int],
    k_min: int,
    k_max: int,
    tail_policy: str = TAIL_CANONIZATION,
    source_tag: str = SOURCE_ARITHMETIC,
    trace_id: str = "NORMALIZE",
) -> BTNSNumber:
    """Normalize arbitrary integer coefficients into balanced ternary digits.

    Carry is propagated until it vanishes. Terms below k_min are normalized first
    so their carry can affect retained exponents; omitted low exponents are then
    stored as a structured TailBound instead of being silently discarded.
    """

    if tail_policy not in _ALLOWED_TAIL_POLICIES:
        raise ValueError(f"unregistered tail policy: {tail_policy}")
    if source_tag not in _ALLOWED_SOURCE_TAGS:
        raise ValueError(f"unregistered source tag: {source_tag}")
    if not isinstance(k_min, int) or not isinstance(k_max, int):
        raise TypeError("k_min and k_max must be int")
    if k_min > k_max:
        raise ValueError("k_min must be <= k_max")

    clean_raw: Dict[int, int] = {}
    for exponent, coeff in raw_digits.items():
        if not isinstance(exponent, int):
            raise TypeError("raw exponent keys must be int")
        if not isinstance(coeff, int):
            raise TypeError("raw coefficients must be int")
        if coeff != 0:
            clean_raw[exponent] = coeff

    if clean_raw:
        start = min(min(clean_raw), k_min)
        stop = max(max(clean_raw), k_max)
    else:
        start = k_min
        stop = k_max

    normalized: Dict[int, int] = {}
    carry = 0
    exponent = start
    while exponent <= stop or carry != 0:
        s_k = clean_raw.get(exponent, 0) + carry
        c_k = (s_k + 1) // RADIX
        z_k = s_k - RADIX * c_k
        if z_k not in DIGIT_SET:
            raise ArithmeticError("normalization produced illegal digit")
        normalized[exponent] = z_k
        carry = c_k
        exponent += 1

    actual_k_max = max(k_max, exponent - 1)
    omitted = {k: v for k, v in normalized.items() if k < k_min and v != 0}
    tail = _tail_from_omitted_digits(omitted, policy=tail_policy, source=source_tag)

    retained: Dict[int, int] = {}
    for exponent in range(k_min, actual_k_max + 1):
        retained[exponent] = normalized.get(exponent, 0)

    if tail_policy == TAIL_NONE and tail is not None:
        raise ArithmeticError("TAIL_NONE requested but low-exponent tail is nonzero")

    out_trace = _stable_trace_id(
        (
            trace_id,
            "normalize",
            k_min,
            actual_k_max,
            _digits_signature(retained),
            tail.abs_bound_num if tail else 0,
            tail.abs_bound_den_power3 if tail else 0,
        )
    )

    return BTNSNumber(
        digits=retained,
        k_min=k_min,
        k_max=actual_k_max,
        tail_bound=tail,
        canonicality_flag=CANONICAL_LEGAL,
        source_tag=source_tag,
        precision_depth=k_min,
        trace_id=out_trace,
    )


def _copy_with_tail(x: BTNSNumber, tail: Optional[TailBound], trace_id: str) -> BTNSNumber:
    return replace(x, tail_bound=tail, trace_id=trace_id)


def add_btns(x: BTNSNumber, y: BTNSNumber) -> BTNSNumber:
    """Native BTNS addition using balanced carry normalization."""

    if not validate_digits(x) or not validate_digits(y):
        raise ValueError("add_btns requires legal BTNSNumber inputs")

    k_min = x.k_min if x.k_min <= y.k_min else y.k_min
    k_max = x.k_max if x.k_max >= y.k_max else y.k_max
    raw: Dict[int, int] = {}
    for exponent in range(k_min, k_max + 1):
        raw[exponent] = x.digits.get(exponent, 0) + y.digits.get(exponent, 0)

    trace = _stable_trace_id(("add", x.trace_id, y.trace_id, _digits_signature(raw)))
    result = normalize_digits(
        raw,
        k_min=k_min,
        k_max=k_max,
        tail_policy=TAIL_REFINEMENT,
        source_tag=SOURCE_ARITHMETIC,
        trace_id=trace,
    )
    combined_tail = _combine_tails(
        result.tail_bound,
        x.tail_bound,
        y.tail_bound,
        lower_exp=k_min,
        policy=TAIL_REFINEMENT,
        source=SOURCE_ARITHMETIC,
    )
    return _copy_with_tail(result, combined_tail, trace_id=trace)


def neg_btns(x: BTNSNumber) -> BTNSNumber:
    """Native BTNS digitwise negation."""

    if not validate_digits(x):
        raise ValueError("neg_btns requires a legal BTNSNumber input")
    digits = {exponent: -digit for exponent, digit in x.digits.items()}
    trace = _stable_trace_id(("neg", x.trace_id, _digits_signature(digits)))
    return BTNSNumber(
        digits=digits,
        k_min=x.k_min,
        k_max=x.k_max,
        tail_bound=x.tail_bound,
        canonicality_flag=CANONICAL_LEGAL,
        source_tag=SOURCE_ARITHMETIC,
        precision_depth=x.precision_depth,
        trace_id=trace,
    )


def sub_btns(x: BTNSNumber, y: BTNSNumber) -> BTNSNumber:
    """Native BTNS subtraction defined as x + (-y)."""

    return add_btns(x, neg_btns(y))


def mul_btns(x: BTNSNumber, y: BTNSNumber) -> BTNSNumber:
    """Native BTNS multiplication by convolution followed by normalization."""

    if not validate_digits(x) or not validate_digits(y):
        raise ValueError("mul_btns requires legal BTNSNumber inputs")

    raw: Dict[int, int] = {}
    for i, x_digit in x.digits.items():
        if x_digit == 0:
            continue
        for j, y_digit in y.digits.items():
            if y_digit == 0:
                continue
            exponent = i + j
            raw[exponent] = raw.get(exponent, 0) + x_digit * y_digit

    target_k_min = x.k_min if x.k_min <= y.k_min else y.k_min
    natural_k_min = x.k_min + y.k_min
    working_k_min = natural_k_min if natural_k_min < target_k_min else target_k_min
    target_k_max = x.k_max + y.k_max

    trace = _stable_trace_id(("mul", x.trace_id, y.trace_id, _digits_signature(raw)))
    working = normalize_digits(
        raw,
        k_min=working_k_min,
        k_max=target_k_max,
        tail_policy=TAIL_MULTIPLICATION_TRUNCATION,
        source_tag=SOURCE_ARITHMETIC,
        trace_id=trace,
    )

    if working_k_min < target_k_min:
        retained_raw = {k: v for k, v in working.digits.items() if k >= target_k_min}
        low_digits = {k: v for k, v in working.digits.items() if k < target_k_min and v != 0}
        trunc_tail = _tail_from_omitted_digits(
            low_digits,
            policy=TAIL_MULTIPLICATION_TRUNCATION,
            source=SOURCE_ARITHMETIC,
        )
        result = normalize_digits(
            retained_raw,
            k_min=target_k_min,
            k_max=working.k_max,
            tail_policy=TAIL_MULTIPLICATION_TRUNCATION,
            source_tag=SOURCE_ARITHMETIC,
            trace_id=trace,
        )
    else:
        trunc_tail = working.tail_bound
        result = working

    x_abs = _abs_bound_of_number(x)
    y_abs = _abs_bound_of_number(y)
    x_tail = _tail_to_bound_pair(x.tail_bound)
    y_tail = _tail_to_bound_pair(y.tail_bound)

    propagated = (0, 0)
    propagated = _add_bound_pairs(propagated, _mul_bound_pairs(x_abs, y_tail))
    propagated = _add_bound_pairs(propagated, _mul_bound_pairs(y_abs, x_tail))
    propagated = _add_bound_pairs(propagated, _mul_bound_pairs(x_tail, y_tail))

    propagated_tail = _make_tail(
        propagated,
        lower_exp=target_k_min,
        policy=TAIL_MULTIPLICATION_TRUNCATION,
        source=SOURCE_ARITHMETIC,
    )
    combined_tail = _combine_tails(
        result.tail_bound,
        trunc_tail,
        propagated_tail,
        lower_exp=target_k_min,
        policy=TAIL_MULTIPLICATION_TRUNCATION,
        source=SOURCE_ARITHMETIC,
    )
    return _copy_with_tail(result, combined_tail, trace_id=trace)


def _trim_high_zero_exponents(x: BTNSNumber) -> BTNSNumber:
    """Trim high zero exponents while preserving k_min and tail metadata.

    This helper is not reported as full WFC. It only prepares the finite digit
    object before strict_wfc() is invoked by canonize_btns().
    """

    if not validate_digits(x):
        raise ValueError("_trim_high_zero_exponents requires a legal BTNSNumber input")

    highest = x.k_min
    for exponent in range(x.k_max, x.k_min - 1, -1):
        if x.digits.get(exponent, 0) != 0:
            highest = exponent
            break
    if all(digit == 0 for digit in x.digits.values()):
        highest = 0 if x.k_min <= 0 else x.k_min

    raw = {k: v for k, v in x.digits.items() if x.k_min <= k <= highest}
    trace = _stable_trace_id(("pre_wfc_trim", x.trace_id, _digits_signature(raw)))
    result = normalize_digits(
        raw,
        k_min=x.k_min,
        k_max=highest,
        tail_policy=TAIL_CANONIZATION,
        source_tag=SOURCE_ARITHMETIC,
        trace_id=trace,
    )
    combined_tail = _combine_tails(
        result.tail_bound,
        x.tail_bound,
        lower_exp=x.k_min,
        policy=TAIL_CANONIZATION,
        source=SOURCE_ARITHMETIC,
    )
    return _copy_with_tail(result, combined_tail, trace_id=trace)


def canonize_btns(
    x: BTNSNumber,
    wfc_config: WFCConfig,
    operation_context: object,
    *,
    return_result: bool = False,
) -> BTNSNumber | WFCSelectionResult:
    """Canonize a BTNS object through the full strict WFC boundary operator.

    v28 forbids treating canonization as ordinary normalization/trimming when
    the returned object is reported as WFC-canonical. Therefore this function
    performs only a conservative high-zero pre-trim and then delegates the
    canonical boundary decision to btns_wfc.strict_wfc().

    Parameters
    ----------
    x:
        Legal BTNSNumber input.
    wfc_config:
        Mandatory WFCConfig. No implicit default is created, because the WFC
        policy and window width are part of the mathematical settings signature.
    operation_context:
        A string operation id or a mapping accepted by strict_wfc(). Use
        {"wfc_applicable": False, "not_applicable_reason": "..."} only for
        explicitly non-applicable cases such as exact leading coefficients.
    return_result:
        If True, return WFCSelectionResult so callers can access candidates and
        traces. If False, return only the canonical BTNSNumber and raise
        ArithmeticError on WFC_UNDEFINED_STRICT_EMPTY.
    """

    if not validate_digits(x):
        raise ValueError("canonize_btns requires a legal BTNSNumber input")
    if not isinstance(wfc_config, WFCConfig):
        raise TypeError("canonize_btns requires an explicit WFCConfig")

    prepared = _trim_high_zero_exponents(x)
    result = strict_wfc(prepared, wfc_config, operation_context)

    if return_result:
        return result

    if result.canonical_object is None:
        raise ArithmeticError(
            "strict WFC produced no canonical object: "
            f"{result.trace.wfc_status}; operation_id={result.trace.operation_id}"
        )
    if not isinstance(result.canonical_object, BTNSNumber):
        raise TypeError("strict_wfc returned a non-BTNSNumber canonical object")
    if result.trace.wfc_status == WFC_UNDEFINED_STRICT_EMPTY:
        raise ArithmeticError("strict WFC undefined strict-empty result cannot be promoted")
    return result.canonical_object


def canonize_btns_not_applicable(
    x: BTNSNumber,
    wfc_config: WFCConfig,
    reason: str,
    operation_id: str,
    *,
    return_result: bool = False,
) -> BTNSNumber | WFCSelectionResult:
    """Explicit helper for cases where v28 allows WFC_NOT_APPLICABLE."""

    return canonize_btns(
        x,
        wfc_config,
        {
            "operation_id": operation_id,
            "wfc_applicable": False,
            "not_applicable_reason": reason,
        },
        return_result=return_result,
    )

def btns_equal_digits(x: BTNSNumber, y: BTNSNumber) -> bool:
    """Digitwise equality after legal normalization-range comparison."""

    if not validate_digits(x) or not validate_digits(y):
        return False
    k_min = x.k_min if x.k_min <= y.k_min else y.k_min
    k_max = x.k_max if x.k_max >= y.k_max else y.k_max
    for exponent in range(k_min, k_max + 1):
        if x.digits.get(exponent, 0) != y.digits.get(exponent, 0):
            return False

    x_tail = _tail_to_bound_pair(x.tail_bound)
    y_tail = _tail_to_bound_pair(y.tail_bound)
    return x_tail == y_tail


def digit_string_kmax_to_kmin(x: BTNSNumber, separator: str = " | ") -> str:
    """Human-readable digit string ordered from k_max down to k_min."""

    if not validate_digits(x):
        raise ValueError("digit_string_kmax_to_kmin requires a legal BTNSNumber input")
    left = []
    right = []
    for exponent in range(x.k_max, x.k_min - 1, -1):
        digit = x.digits.get(exponent, 0)
        if exponent >= 0:
            left.append(str(digit))
        else:
            right.append(str(digit))
    if not left:
        left.append("0")
    if right:
        return "[" + ",".join(left) + separator + ",".join(right) + "]"
    return "[" + ",".join(left) + "]"


def make_btns_number_from_digits(
    digits: Dict[int, int],
    k_min: int,
    k_max: int,
    source_tag: str = SOURCE_TEST,
    trace_id: str = "MANUAL",
) -> BTNSNumber:
    """Small helper for tests and manually provided canonical digit maps."""

    return normalize_digits(
        digits,
        k_min=k_min,
        k_max=k_max,
        tail_policy=TAIL_NONE,
        source_tag=source_tag,
        trace_id=trace_id,
    )


__all__ = [
    "RADIX",
    "DIGIT_SET",
    "CANONICAL_LEGAL",
    "CANONICAL_ILLEGAL",
    "CANONICAL_PENDING",
    "SOURCE_INGRESS",
    "SOURCE_ARITHMETIC",
    "SOURCE_COEFFICIENT",
    "SOURCE_CERTIFIED",
    "SOURCE_REPORT",
    "SOURCE_TEST",
    "TAIL_NONE",
    "TAIL_INGRESS_ROUNDING",
    "TAIL_MULTIPLICATION_TRUNCATION",
    "TAIL_CANONIZATION",
    "TAIL_OVERFLOW",
    "TAIL_REFINEMENT",
    "WFCConfig",
    "WFCSelectionResult",
    "TailBound",
    "BTNSNumber",
    "validate_digits",
    "normalize_digits",
    "add_btns",
    "neg_btns",
    "sub_btns",
    "mul_btns",
    "canonize_btns",
    "canonize_btns_not_applicable",
    "btns_equal_digits",
    "digit_string_kmax_to_kmin",
    "make_btns_number_from_digits",
]


if __name__ == "__main__":
    one = make_btns_number_from_digits({0: 1}, 0, 0, trace_id="one")
    minus_one = make_btns_number_from_digits({0: -1}, 0, 0, trace_id="minus_one")
    zero = add_btns(one, minus_one)
    assert validate_digits(zero)
    assert zero.digits[0] == 0
    two = add_btns(one, one)
    assert validate_digits(two)
    assert two.digits[0] == -1 and two.digits[1] == 1
    product = mul_btns(two, two)
    assert validate_digits(product)
    assert product.digits[0] == 1 and product.digits[1] == 1
    assert btns_equal_digits(sub_btns(two, one), one)
    print("btns_core.py self-check PASS")
