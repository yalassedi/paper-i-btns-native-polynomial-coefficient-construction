"""
tests_egress.py

Unit tests for egress.py, the report-only egress boundary used by
PythonApplication157 under Script Contract v28.

These tests verify that BTNS outputs are converted into human-readable and
machine-readable report strings only, without feeding decimal/report values back
into coefficient-producing construction modules.

They cover:
    - exact power-of-3 rational reporting;
    - deterministic decimal string formatting;
    - lower/center/upper interval reporting from TailBound;
    - coefficient report rows with WFC metadata;
    - sequence reporting helpers;
    - rejection of illegal inputs and invalid digit settings;
    - construction-boundary safety: no ingress, gold, Excel, NumPy, SymPy,
      polynomial, certified, or WFC-selection calls inside egress.py.
"""

from __future__ import annotations

import ast
import inspect
import unittest

import btns_core as core
import btns_wfc as wfc
import egress


def one(trace_id: str = "ONE") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=0,
        k_max=0,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def third(trace_id: str = "THIRD") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {-1: 1, 0: 0},
        k_min=-1,
        k_max=0,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(trace_id: str = "TWO") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: -1, 1: 1},
        k_min=0,
        k_max=1,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


class TestRationalPower3AndFiniteValues(unittest.TestCase):
    def test_rational_power3_validation_and_dict(self) -> None:
        value = egress.RationalPower3(7, 2)
        self.assertEqual(value.as_dict(), {"numerator": 7, "den_power3": 2})

        with self.assertRaises(TypeError):
            egress.RationalPower3("7", 2)  # type: ignore[arg-type]
        with self.assertRaises(ValueError):
            egress.RationalPower3(7, -1)

    def test_finite_value_for_exact_one(self) -> None:
        rational = egress.finite_value_as_power3_rational(one())

        self.assertEqual(rational.numerator, 1)
        self.assertEqual(rational.den_power3, 0)

    def test_finite_value_for_one_third(self) -> None:
        rational = egress.finite_value_as_power3_rational(third())

        self.assertEqual(rational.numerator, 1)
        self.assertEqual(rational.den_power3, 1)

    def test_finite_value_for_two_as_balanced_digits(self) -> None:
        rational = egress.finite_value_as_power3_rational(two())

        self.assertEqual(rational.numerator, 2)
        self.assertEqual(rational.den_power3, 0)

    def test_illegal_input_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            egress.finite_value_as_power3_rational(object())  # type: ignore[arg-type]


class TestDecimalFormatting(unittest.TestCase):
    def test_decimal_string_for_exact_one(self) -> None:
        self.assertEqual(egress.btns_to_decimal_string_for_report(one(), 6), "1.000000")

    def test_decimal_string_for_one_third_is_deterministic_truncated(self) -> None:
        self.assertEqual(egress.btns_to_decimal_string_for_report(third(), 6), "0.333333")

    def test_decimal_string_for_negative_value(self) -> None:
        minus_one = core.make_btns_number_from_digits({0: -1}, 0, 0, trace_id="MINUS_ONE")
        self.assertEqual(egress.btns_to_decimal_string_for_report(minus_one, 4), "-1.0000")

    def test_zero_digits_decimal_format(self) -> None:
        self.assertEqual(egress.btns_to_decimal_string_for_report(two(), 0), "2")

    def test_report_rounding_nearest_ties_to_zero(self) -> None:
        value = egress.RationalPower3(5, 1)  # 5/3 = 1.666...
        self.assertEqual(
            egress.power3_rational_to_decimal_string_for_report(
                value,
                2,
                rounding="ROUND_NEAREST_TIES_TO_ZERO",
            ),
            "1.67",
        )

    def test_invalid_decimal_digits_and_rounding_mode_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            egress.btns_to_decimal_string_for_report(one(), -1)
        with self.assertRaises(ValueError):
            egress.power3_rational_to_decimal_string_for_report(egress.RationalPower3(1, 0), 3, rounding="BAD")


class TestIntervalsAndTailReporting(unittest.TestCase):
    def test_interval_without_tail_is_exact(self) -> None:
        lower, center, upper = egress.interval_as_power3_rationals(one())

        self.assertEqual(lower, center)
        self.assertEqual(center, upper)
        self.assertEqual(center.numerator, 1)
        self.assertEqual(center.den_power3, 0)

    def test_interval_with_tail_bound_is_reported_separately(self) -> None:
        tail = core.TailBound(
            lower_exp=-1,
            abs_bound_num=1,
            abs_bound_den_power3=1,
            policy=core.TAIL_REFINEMENT,
            source=core.SOURCE_CERTIFIED,
        )
        uncertain = core.BTNSNumber(
            digits={0: 1},
            k_min=0,
            k_max=0,
            tail_bound=tail,
            canonicality_flag=core.CANONICAL_LEGAL,
            source_tag=core.SOURCE_CERTIFIED,
            trace_id="UNCERTAIN_ONE",
        )

        interval = egress.btns_to_decimal_interval_strings_for_report(uncertain, digits=3)

        self.assertEqual(interval.lower, "0.666")
        self.assertEqual(interval.center, "1.000")
        self.assertEqual(interval.upper, "1.333")
        self.assertEqual(interval.as_dict()["decimal_digits"], 3)

    def test_exact_rational_string_for_integer_and_fraction(self) -> None:
        self.assertEqual(egress.btns_to_exact_rational_string_for_report(one()), "1")
        self.assertEqual(egress.btns_to_exact_rational_string_for_report(third()), "1/3^1")


class TestReportRows(unittest.TestCase):
    def test_report_dict_contains_required_fields_and_wfc_metadata(self) -> None:
        x = core.canonize_btns(
            core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="ZERO_FOR_REPORT"),
            wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO),
            {"operation_id": "REPORT_WFC_ZERO"},
        )
        self.assertIsInstance(x, core.BTNSNumber)

        row = egress.btns_to_report_dict(x, coefficient_index=2, digits=4)

        required = {
            "coefficient_index",
            "trace_id",
            "k_min",
            "k_max",
            "digit_string",
            "exact_rational",
            "decimal_center",
            "decimal_lower",
            "decimal_upper",
            "tail_abs_bound_num",
            "tail_abs_bound_den_power3",
            "canonicality_flag",
            "source_tag",
            "wfc_trace_id",
            "wfc_status",
        }
        self.assertTrue(required.issubset(row))
        self.assertEqual(row["coefficient_index"], 2)
        self.assertTrue(row["wfc_trace_id"])
        self.assertTrue(row["wfc_status"])

    def test_coefficients_to_report_rows_preserves_sequence_order(self) -> None:
        rows = egress.coefficients_to_report_rows((one("C0"), third("C1"), two("C2")), digits=3)

        self.assertEqual(len(rows), 3)
        self.assertEqual([row["coefficient_index"] for row in rows], [0, 1, 2])
        self.assertEqual(rows[0]["decimal_center"], "1.000")
        self.assertEqual(rows[1]["decimal_center"], "0.333")
        self.assertEqual(rows[2]["decimal_center"], "2.000")

    def test_coefficient_digit_strings_for_report(self) -> None:
        strings = egress.coefficient_digit_strings_for_report((one(), third(), two()))

        self.assertEqual(len(strings), 3)
        self.assertTrue(all(item.startswith("[") and item.endswith("]") for item in strings))

    def test_report_row_rejects_non_btns_object(self) -> None:
        with self.assertRaises(ValueError):
            egress.btns_to_report_dict(object(), coefficient_index=0)  # type: ignore[arg-type]


class TestEgressBoundarySafety(unittest.TestCase):
    def test_egress_source_has_no_forbidden_imports_or_construction_calls(self) -> None:
        source = inspect.getsource(egress)
        tree = ast.parse(source)

        forbidden_import_roots = {
            "decimal",
            "fractions",
            "numpy",
            "sympy",
            "openpyxl",
            "pandas",
            "xlrd",
            "pyxlsb",
            "ingress",
            "btns_poly",
            "btns_certified",
            "btns_wfc",
            "gold_reference",
            "reporting",
        }
        forbidden_calls = {
            "Decimal",
            "Fraction",
            "eval",
            "exec",
            "parse_decimal_string_to_btns",
            "load_root_input_csv",
            "build_polynomial_coeffs_noncertified",
            "build_polynomial_coeffs_certified_independent",
            "build_polynomial_coeffs_noncertified_matched_depth",
            "strict_wfc",
            "select_wfc_candidate",
            "certify_operation",
            "certify_coefficient",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                root = module.split(".")[0]
                self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_egress_imports_btns_core_only_from_project_modules(self) -> None:
        source = inspect.getsource(egress)
        self.assertIn("from btns_core import", source)
        self.assertNotIn("import btns_poly", source)
        self.assertNotIn("import btns_certified", source)
        self.assertNotIn("import ingress", source)
        self.assertNotIn("import btns_wfc", source)

    def test_report_only_functions_do_not_mutate_input_object(self) -> None:
        x = third("IMMUTABLE_THIRD")
        before = (dict(x.digits), x.trace_id, x.wfc_trace_id, x.wfc_status)
        _ = egress.btns_to_report_dict(x, coefficient_index=1, digits=5)
        after = (dict(x.digits), x.trace_id, x.wfc_trace_id, x.wfc_status)
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main(verbosity=2)
