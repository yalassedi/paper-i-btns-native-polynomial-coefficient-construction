"""
btns_wfc.py

Full strict Windowed Fractional Canonization (WFC) operator for the
BTNS-native polynomial-coefficient construction package.

This module is intentionally construction-boundary safe:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel, workbook, gold-reference, egress, or reporting calls
    - integer-only digit and carry logic over the balanced-ternary digit set

The implementation follows Script Contract v28 for the formal WFC object:

    W_w = {0, -1, -2, ..., -w}
    C_in = {-1, 0, +1}
    q_{-w-1}^{(c_in)} = c_in
    k = -w, -w+1, ..., -1, 0

A candidate is strictly admissible only if:
    - all window digits remain in {-1, 0, +1}
    - q_0 = 0
    - value preservation is exact or explicitly compensated by boundary mode
    - no undeclared support expansion is accepted
    - traceability is deterministic
"""

from __future__ import annotations

from dataclasses import dataclass, fields, is_dataclass, replace
from hashlib import sha256
from typing import Any, Mapping, Optional, Tuple


RADIX = 3
DIGIT_SET = (-1, 0, 1)

# WFC policies: machine-readable tokens.
RN_ZERO = "RN_ZERO"
RN_EVEN = "RN_EVEN"
ALLOWED_WFC_POLICIES = (RN_ZERO, RN_EVEN)

# Boundary modes.
LOWER_BOUNDARY_COMPENSATED = "LOWER_BOUNDARY_COMPENSATED"
EXTENDED_SUPPORT_BOUNDARY = "EXTENDED_SUPPORT_BOUNDARY"
REJECT_NONZERO_C_IN = "REJECT_NONZERO_C_IN"
ALLOWED_BOUNDARY_MODES = (
    LOWER_BOUNDARY_COMPENSATED,
    EXTENDED_SUPPORT_BOUNDARY,
    REJECT_NONZERO_C_IN,
)

# WFC status tokens required/compatible with Script Contract v28.
FULL_STRICT_WFC_EXECUTED = "FULL_STRICT_WFC_EXECUTED"
WFC_NOT_APPLICABLE = "WFC_NOT_APPLICABLE"
WFC_STRICT_VALID_UNIQUE = "WFC_STRICT_VALID_UNIQUE"
WFC_TIE_RESOLVED_RN_ZERO = "WFC_TIE_RESOLVED_RN_ZERO"
WFC_TIE_RESOLVED_RN_EVEN = "WFC_TIE_RESOLVED_RN_EVEN"
WFC_UNDEFINED_STRICT_EMPTY = "WFC_UNDEFINED_STRICT_EMPTY"
WFC_VALUE_PRESERVATION_FAIL = "WFC_VALUE_PRESERVATION_FAIL"
WFC_NO_LEAKAGE_FAIL = "WFC_NO_LEAKAGE_FAIL"
WFC_SUPPORT_FAIL = "WFC_SUPPORT_FAIL"
WFC_TRACE_INCOMPLETE = "WFC_TRACE_INCOMPLETE"
WFC_REJECTED = "WFC_REJECTED"
CANONIZE_ONLY_BASELINE = "CANONIZE_ONLY_BASELINE"

# Candidate-level status tokens.
LEGAL_DIGITS_PASS = "LEGAL_DIGITS_PASS"
LEGAL_DIGITS_FAIL = "LEGAL_DIGITS_FAIL"
NO_LEAKAGE_PASS = "NO_LEAKAGE_PASS"
NO_LEAKAGE_FAIL = WFC_NO_LEAKAGE_FAIL
VALUE_PRESERVED_EXACT = "VALUE_PRESERVED_EXACT"
VALUE_PRESERVED_COMPENSATED = "VALUE_PRESERVED_COMPENSATED"
VALUE_PRESERVATION_FAIL = WFC_VALUE_PRESERVATION_FAIL
SUPPORT_OK = "SUPPORT_OK"
SUPPORT_COMPENSATED_LOWER_BOUNDARY = "SUPPORT_COMPENSATED_LOWER_BOUNDARY"
SUPPORT_REQUIRES_EXTENSION = "SUPPORT_REQUIRES_EXTENSION"
SUPPORT_FAIL = WFC_SUPPORT_FAIL
STRICT_PASS = "STRICT_PASS"
STRICT_FAIL = "STRICT_FAIL"

# Canonicality tags used when the host BTNSNumber supports them.
CANONICAL_LEGAL = "LEGAL"
CANONICAL_PENDING = "PENDING"


class WFCError(RuntimeError):
    """Raised when a WFC configuration or trace is structurally invalid."""


@dataclass(frozen=True)
class WFCConfig:
    window_width: int
    policy: str
    candidate_C_in_set: Tuple[int, int, int] = (-1, 0, 1)
    boundary_mode: str = LOWER_BOUNDARY_COMPENSATED
    strict_value_preservation_required: bool = True
    no_leakage_required: bool = True
    secondary_ordering: str = "LEXICOGRAPHIC_STABLE"

    def __post_init__(self) -> None:
        if not isinstance(self.window_width, int):
            raise TypeError("window_width must be int")
        if self.window_width < 0:
            raise ValueError("window_width must be non-negative")
        if self.policy not in ALLOWED_WFC_POLICIES:
            raise ValueError(f"unregistered WFC policy: {self.policy}")
        if tuple(self.candidate_C_in_set) != (-1, 0, 1):
            raise ValueError("candidate_C_in_set must be exactly (-1, 0, 1)")
        if self.boundary_mode not in ALLOWED_BOUNDARY_MODES:
            raise ValueError(f"unregistered boundary_mode: {self.boundary_mode}")
        if not isinstance(self.strict_value_preservation_required, bool):
            raise TypeError("strict_value_preservation_required must be bool")
        if not isinstance(self.no_leakage_required, bool):
            raise TypeError("no_leakage_required must be bool")
        if not isinstance(self.secondary_ordering, str) or not self.secondary_ordering:
            raise ValueError("secondary_ordering must be a non-empty string")


@dataclass(frozen=True)
class WFCCandidate:
    candidate_id: str
    operation_id: str
    input_trace_id: str
    c_in: int
    window_width: int
    digits_before: dict[int, int]
    digits_after: dict[int, int]
    q0: int
    legal_digit_status: str
    value_preservation_status: str
    support_status: str
    no_leakage_status: str
    strict_status: str
    policy_key_zero: tuple[Any, ...]
    policy_key_even: tuple[Any, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "operation_id": self.operation_id,
            "input_trace_id": self.input_trace_id,
            "c_in": self.c_in,
            "window_width": self.window_width,
            "digits_before": dict(sorted(self.digits_before.items())),
            "digits_after": dict(sorted(self.digits_after.items())),
            "q0": self.q0,
            "legal_digit_status": self.legal_digit_status,
            "value_preservation_status": self.value_preservation_status,
            "support_status": self.support_status,
            "no_leakage_status": self.no_leakage_status,
            "strict_status": self.strict_status,
            "policy_key_zero": list(self.policy_key_zero),
            "policy_key_even": list(self.policy_key_even),
        }


@dataclass(frozen=True)
class WFCTrace:
    wfc_trace_id: str
    operation_id: str
    input_trace_id: str
    output_trace_id: str
    window_width: int
    policy: str
    candidate_count: int
    strict_candidate_count: int
    selected_candidate_id: Optional[str]
    selected_c_in: Optional[int]
    q0_selected: Optional[int]
    wfc_status: str
    wfc_boundary_mode: str
    wfc_not_applicable_reason: Optional[str]

    def as_dict(self) -> dict[str, object]:
        return {
            "wfc_trace_id": self.wfc_trace_id,
            "operation_id": self.operation_id,
            "input_trace_id": self.input_trace_id,
            "output_trace_id": self.output_trace_id,
            "window_width": self.window_width,
            "policy": self.policy,
            "candidate_count": self.candidate_count,
            "strict_candidate_count": self.strict_candidate_count,
            "selected_candidate_id": self.selected_candidate_id,
            "selected_c_in": self.selected_c_in,
            "q0_selected": self.q0_selected,
            "wfc_status": self.wfc_status,
            "wfc_boundary_mode": self.wfc_boundary_mode,
            "wfc_not_applicable_reason": self.wfc_not_applicable_reason,
        }


@dataclass(frozen=True)
class WFCSelectionResult:
    canonical_object: Any | None
    trace: WFCTrace
    candidates: Tuple[WFCCandidate, ...]


@dataclass(frozen=True)
class WFCAblationRecord:
    branch_id: str
    wfc_enabled: bool
    window_width: int | None
    policy: str | None
    candidate_count_total: int
    strict_candidate_count_total: int
    strict_empty_count: int
    tie_resolved_count: int
    undefined_count: int

    def as_dict(self) -> dict[str, object]:
        return {
            "branch_id": self.branch_id,
            "wfc_enabled": self.wfc_enabled,
            "window_width": self.window_width,
            "policy": self.policy,
            "candidate_count_total": self.candidate_count_total,
            "strict_candidate_count_total": self.strict_candidate_count_total,
            "strict_empty_count": self.strict_empty_count,
            "tie_resolved_count": self.tie_resolved_count,
            "undefined_count": self.undefined_count,
        }


def _stable_hash(*parts: object, length: int = 16) -> str:
    payload = "|".join(str(part) for part in parts)
    return sha256(payload.encode("utf-8")).hexdigest()[:length]


def _digits_of(x: Any) -> dict[int, int]:
    digits = getattr(x, "digits", None)
    if not isinstance(digits, Mapping):
        raise TypeError("WFC input object must expose a mapping-like 'digits' attribute")
    clean: dict[int, int] = {}
    for key, value in digits.items():
        if not isinstance(key, int):
            raise TypeError("digit exponent keys must be int")
        if not isinstance(value, int):
            raise TypeError("digit values must be int")
        clean[key] = value
    return clean


def _k_min_of(x: Any) -> int:
    value = getattr(x, "k_min", None)
    if not isinstance(value, int):
        raise TypeError("WFC input object must expose integer k_min")
    return value


def _k_max_of(x: Any) -> int:
    value = getattr(x, "k_max", None)
    if not isinstance(value, int):
        raise TypeError("WFC input object must expose integer k_max")
    return value


def _trace_id_of(x: Any) -> str:
    trace_id = getattr(x, "trace_id", None)
    if isinstance(trace_id, str) and trace_id:
        return trace_id
    return "NO_INPUT_TRACE_" + _stable_hash(_digits_of(x), _k_min_of(x), _k_max_of(x))


def _field_names_for_dataclass_instance(x: Any) -> set[str]:
    if not is_dataclass(x):
        return set()
    return {field.name for field in fields(x)}


def _replace_number(
    x: Any,
    *,
    digits: dict[int, int],
    trace_id: str,
    wfc_trace_id: str,
    wfc_status: str,
) -> Any:
    """Return an object of the same dataclass type when possible.

    This function is deliberately structural. It avoids importing btns_core.py,
    preventing circular imports while allowing the host BTNSNumber class to be
    extended later with WFC fields.
    """

    if not is_dataclass(x):
        # Fallback for tests that pass a simple structural object.
        return {
            "digits": dict(digits),
            "k_min": _k_min_of(x),
            "k_max": _k_max_of(x),
            "trace_id": trace_id,
            "wfc_trace_id": wfc_trace_id,
            "wfc_status": wfc_status,
        }

    kwargs: dict[str, object] = {"digits": dict(digits)}
    names = _field_names_for_dataclass_instance(x)
    if "trace_id" in names:
        kwargs["trace_id"] = trace_id
    if "canonicality_flag" in names:
        kwargs["canonicality_flag"] = CANONICAL_LEGAL
    if "wfc_trace_id" in names:
        kwargs["wfc_trace_id"] = wfc_trace_id
    if "wfc_status" in names:
        kwargs["wfc_status"] = wfc_status
    return replace(x, **kwargs)


def _context_get(operation_context: object, key: str, default: object = None) -> object:
    if isinstance(operation_context, Mapping):
        return operation_context.get(key, default)
    return default


def _operation_id(operation_context: object, input_trace_id: str) -> str:
    explicit = _context_get(operation_context, "operation_id", None)
    if isinstance(explicit, str) and explicit:
        return explicit
    if isinstance(operation_context, str) and operation_context:
        return operation_context
    return "WFC_OP_" + _stable_hash(input_trace_id, operation_context)


def _wfc_applicable(operation_context: object) -> bool:
    marker = _context_get(operation_context, "wfc_applicable", True)
    if isinstance(marker, bool):
        return marker
    return True


def _not_applicable_reason(operation_context: object) -> str:
    reason = _context_get(operation_context, "not_applicable_reason", None)
    if isinstance(reason, str) and reason:
        return reason
    return "OPERATION_CONTEXT_DECLARED_WFC_NOT_APPLICABLE"


def _window_positions(window_width: int) -> tuple[int, ...]:
    return tuple(range(-window_width, 1))


def _window_scaled_value(digits: Mapping[int, int], window_width: int) -> int:
    """Return sum_{k=-w..0} d_k * 3^{k+w}; integer scaled by 3^w."""

    total = 0
    for exponent in _window_positions(window_width):
        total += int(digits.get(exponent, 0)) * (RADIX ** (exponent + window_width))
    return total


def _window_lex_key(digits: Mapping[int, int], window_width: int) -> tuple[int, ...]:
    # Deterministic order from boundary toward lower fractional positions.
    return tuple(int(digits.get(exponent, 0)) for exponent in range(0, -window_width - 1, -1))


def _window_l1_norm(digits: Mapping[int, int], window_width: int) -> int:
    return sum(abs(int(digits.get(exponent, 0))) for exponent in _window_positions(window_width))


def _support_status_for_candidate(
    x: Any,
    config: WFCConfig,
    c_in: int,
    diff_scaled: int,
) -> str:
    k_min = _k_min_of(x)
    k_max = _k_max_of(x)
    lower = -config.window_width

    if lower < k_min or 0 > k_max:
        return SUPPORT_FAIL

    if diff_scaled == 0:
        return SUPPORT_OK

    if config.boundary_mode == LOWER_BOUNDARY_COMPENSATED:
        return SUPPORT_COMPENSATED_LOWER_BOUNDARY

    if config.boundary_mode == REJECT_NONZERO_C_IN and c_in != 0:
        return SUPPORT_FAIL

    if config.boundary_mode == EXTENDED_SUPPORT_BOUNDARY:
        # Conservative v28-safe behavior: do not silently expand support in this
        # standalone WFC kernel. Future integration may add explicit legal support
        # extension, but it must be traced before this becomes strict-pass.
        return SUPPORT_REQUIRES_EXTENSION

    return SUPPORT_FAIL


def _value_preservation_status(config: WFCConfig, diff_scaled: int, support_status: str) -> str:
    if diff_scaled == 0:
        return VALUE_PRESERVED_EXACT
    if config.boundary_mode == LOWER_BOUNDARY_COMPENSATED and support_status == SUPPORT_COMPENSATED_LOWER_BOUNDARY:
        return VALUE_PRESERVED_COMPENSATED
    return VALUE_PRESERVATION_FAIL


def kappa_zero_key(candidate: WFCCandidate) -> tuple[Any, ...]:
    """Deterministic κ_ZERO key.

    The policy prefers the least lower-boundary disturbance, then the sparsest
    boundary-window digit pattern, then a stable lexicographic ordering.
    """

    w = candidate.window_width
    return (
        abs(candidate.c_in),
        _window_l1_norm(candidate.digits_after, w),
        abs(candidate.digits_after.get(0, 0)),
        _window_lex_key(candidate.digits_after, w),
        candidate.c_in,
        candidate.candidate_id,
    )


def kappa_even_key(candidate: WFCCandidate) -> tuple[Any, ...]:
    """Deterministic κ_EVEN key.

    In the finite balanced-ternary boundary context, the boundary digit 0 is the
    even representative. Thus this key first prefers z_0 = 0, then falls back to
    κ_ZERO-like stability.
    """

    w = candidate.window_width
    z0 = candidate.digits_after.get(0, 0)
    parity_score = abs(z0) % 2  # 0 for z_0 = 0, 1 for z_0 = +/-1.
    return (
        parity_score,
        abs(candidate.c_in),
        _window_l1_norm(candidate.digits_after, w),
        _window_lex_key(candidate.digits_after, w),
        candidate.c_in,
        candidate.candidate_id,
    )


def _candidate_id(
    operation_id: str,
    input_trace_id: str,
    c_in: int,
    window_width: int,
    digits_after: Mapping[int, int],
    q0: int,
) -> str:
    return "WFC_CAND_" + _stable_hash(
        operation_id,
        input_trace_id,
        c_in,
        window_width,
        tuple(sorted(digits_after.items())),
        q0,
        length=24,
    )


def propagate_wfc_candidate(
    x: Any,
    config: WFCConfig,
    c_in: int,
    operation_id: str,
) -> WFCCandidate:
    if c_in not in config.candidate_C_in_set:
        raise ValueError(f"c_in must be one of {config.candidate_C_in_set}")

    input_trace_id = _trace_id_of(x)
    digits_before = _digits_of(x)
    digits_after = dict(digits_before)

    carry = c_in  # q_{-w-1}^{(c_in)} = c_in
    legal = True

    for exponent in _window_positions(config.window_width):
        s_k = int(digits_before.get(exponent, 0)) + carry
        q_k = (s_k + 1) // RADIX
        z_tilde = s_k - RADIX * q_k
        if z_tilde not in DIGIT_SET:
            legal = False
        digits_after[exponent] = z_tilde
        carry = q_k

    q0 = carry
    diff_scaled = _window_scaled_value(digits_after, config.window_width) - _window_scaled_value(
        digits_before, config.window_width
    )

    legal_digit_status = LEGAL_DIGITS_PASS if legal else LEGAL_DIGITS_FAIL
    no_leakage_status = NO_LEAKAGE_PASS if q0 == 0 else NO_LEAKAGE_FAIL
    support_status = _support_status_for_candidate(x, config, c_in, diff_scaled)
    value_status = _value_preservation_status(config, diff_scaled, support_status)

    strict = (
        legal_digit_status == LEGAL_DIGITS_PASS
        and (not config.no_leakage_required or no_leakage_status == NO_LEAKAGE_PASS)
        and (
            not config.strict_value_preservation_required
            or value_status in (VALUE_PRESERVED_EXACT, VALUE_PRESERVED_COMPENSATED)
        )
        and support_status in (SUPPORT_OK, SUPPORT_COMPENSATED_LOWER_BOUNDARY)
    )
    strict_status = STRICT_PASS if strict else STRICT_FAIL

    cid = _candidate_id(operation_id, input_trace_id, c_in, config.window_width, digits_after, q0)

    # Construct once without policy keys, then compute deterministic policy keys.
    tmp = WFCCandidate(
        candidate_id=cid,
        operation_id=operation_id,
        input_trace_id=input_trace_id,
        c_in=c_in,
        window_width=config.window_width,
        digits_before=dict(sorted(digits_before.items())),
        digits_after=dict(sorted(digits_after.items())),
        q0=q0,
        legal_digit_status=legal_digit_status,
        value_preservation_status=value_status,
        support_status=support_status,
        no_leakage_status=no_leakage_status,
        strict_status=strict_status,
        policy_key_zero=tuple(),
        policy_key_even=tuple(),
    )
    return replace(tmp, policy_key_zero=kappa_zero_key(tmp), policy_key_even=kappa_even_key(tmp))


def enumerate_wfc_candidates(
    x: Any,
    config: WFCConfig,
    operation_id: str,
) -> tuple[WFCCandidate, ...]:
    return tuple(propagate_wfc_candidate(x, config, c_in, operation_id) for c_in in config.candidate_C_in_set)


def filter_wfc_strict_candidates(candidates: tuple[WFCCandidate, ...] | list[WFCCandidate]) -> tuple[WFCCandidate, ...]:
    return tuple(candidate for candidate in candidates if candidate.strict_status == STRICT_PASS)


def select_wfc_candidate(strict_candidates: tuple[WFCCandidate, ...] | list[WFCCandidate], config: WFCConfig) -> WFCCandidate:
    candidates = tuple(strict_candidates)
    if not candidates:
        raise WFCError("cannot select WFC candidate from an empty strict family")
    if config.policy == RN_ZERO:
        return min(candidates, key=lambda candidate: candidate.policy_key_zero)
    if config.policy == RN_EVEN:
        return min(candidates, key=lambda candidate: candidate.policy_key_even)
    raise ValueError(f"unregistered WFC policy: {config.policy}")


def _trace_id(
    operation_id: str,
    input_trace_id: str,
    output_trace_id: str,
    config: WFCConfig,
    selected_candidate_id: str | None,
    wfc_status: str,
) -> str:
    return "WFC_TRACE_" + _stable_hash(
        operation_id,
        input_trace_id,
        output_trace_id,
        config.window_width,
        config.policy,
        config.boundary_mode,
        selected_candidate_id,
        wfc_status,
        length=24,
    )


def _output_trace_id(operation_id: str, input_trace_id: str, selected_candidate_id: str | None, status: str) -> str:
    return "BTNS_WFC_OUT_" + _stable_hash(operation_id, input_trace_id, selected_candidate_id, status, length=24)


def strict_wfc(x: Any, config: WFCConfig, operation_context: object) -> WFCSelectionResult:
    """Execute full strict WFC or emit a deterministic WFC_NOT_APPLICABLE trace.

    Parameters
    ----------
    x:
        BTNSNumber-like object exposing digits, k_min, k_max, and optionally
        trace_id, canonicality_flag, wfc_trace_id, and wfc_status.
    config:
        WFCConfig with window width, selection policy, and boundary convention.
    operation_context:
        Either a string operation id or a mapping. Recognized mapping keys:
            operation_id, wfc_applicable, not_applicable_reason.
    """

    input_trace_id = _trace_id_of(x)
    operation_id = _operation_id(operation_context, input_trace_id)

    if not _wfc_applicable(operation_context):
        output_trace_id = _output_trace_id(operation_id, input_trace_id, None, WFC_NOT_APPLICABLE)
        trace_id = _trace_id(operation_id, input_trace_id, output_trace_id, config, None, WFC_NOT_APPLICABLE)
        trace = WFCTrace(
            wfc_trace_id=trace_id,
            operation_id=operation_id,
            input_trace_id=input_trace_id,
            output_trace_id=output_trace_id,
            window_width=config.window_width,
            policy=config.policy,
            candidate_count=0,
            strict_candidate_count=0,
            selected_candidate_id=None,
            selected_c_in=None,
            q0_selected=None,
            wfc_status=WFC_NOT_APPLICABLE,
            wfc_boundary_mode=config.boundary_mode,
            wfc_not_applicable_reason=_not_applicable_reason(operation_context),
        )
        canonical_object = _replace_number(
            x,
            digits=_digits_of(x),
            trace_id=output_trace_id,
            wfc_trace_id=trace_id,
            wfc_status=WFC_NOT_APPLICABLE,
        )
        return WFCSelectionResult(canonical_object=canonical_object, trace=trace, candidates=tuple())

    candidates = enumerate_wfc_candidates(x, config, operation_id)
    strict_candidates = filter_wfc_strict_candidates(candidates)

    if not strict_candidates:
        output_trace_id = _output_trace_id(operation_id, input_trace_id, None, WFC_UNDEFINED_STRICT_EMPTY)
        trace_id = _trace_id(operation_id, input_trace_id, output_trace_id, config, None, WFC_UNDEFINED_STRICT_EMPTY)
        trace = WFCTrace(
            wfc_trace_id=trace_id,
            operation_id=operation_id,
            input_trace_id=input_trace_id,
            output_trace_id=output_trace_id,
            window_width=config.window_width,
            policy=config.policy,
            candidate_count=len(candidates),
            strict_candidate_count=0,
            selected_candidate_id=None,
            selected_c_in=None,
            q0_selected=None,
            wfc_status=WFC_UNDEFINED_STRICT_EMPTY,
            wfc_boundary_mode=config.boundary_mode,
            wfc_not_applicable_reason=None,
        )
        return WFCSelectionResult(canonical_object=None, trace=trace, candidates=candidates)

    selected = select_wfc_candidate(strict_candidates, config)
    if len(strict_candidates) == 1:
        status = WFC_STRICT_VALID_UNIQUE
    elif config.policy == RN_ZERO:
        status = WFC_TIE_RESOLVED_RN_ZERO
    else:
        status = WFC_TIE_RESOLVED_RN_EVEN

    output_trace_id = _output_trace_id(operation_id, input_trace_id, selected.candidate_id, status)
    trace_id = _trace_id(operation_id, input_trace_id, output_trace_id, config, selected.candidate_id, status)
    trace = WFCTrace(
        wfc_trace_id=trace_id,
        operation_id=operation_id,
        input_trace_id=input_trace_id,
        output_trace_id=output_trace_id,
        window_width=config.window_width,
        policy=config.policy,
        candidate_count=len(candidates),
        strict_candidate_count=len(strict_candidates),
        selected_candidate_id=selected.candidate_id,
        selected_c_in=selected.c_in,
        q0_selected=selected.q0,
        wfc_status=status,
        wfc_boundary_mode=config.boundary_mode,
        wfc_not_applicable_reason=None,
    )

    canonical_object = _replace_number(
        x,
        digits=selected.digits_after,
        trace_id=output_trace_id,
        wfc_trace_id=trace_id,
        wfc_status=status,
    )
    return WFCSelectionResult(canonical_object=canonical_object, trace=trace, candidates=candidates)


def validate_wfc_trace(
    trace: WFCTrace,
    candidates: tuple[WFCCandidate, ...] | list[WFCCandidate],
    *,
    raise_on_error: bool = False,
) -> bool:
    errors = validate_wfc_trace_errors(trace, candidates)
    if errors and raise_on_error:
        raise WFCError("; ".join(errors))
    return not errors


def validate_wfc_trace_errors(
    trace: WFCTrace,
    candidates: tuple[WFCCandidate, ...] | list[WFCCandidate],
) -> tuple[str, ...]:
    errors: list[str] = []
    candidate_tuple = tuple(candidates)

    if not trace.wfc_trace_id:
        errors.append("missing wfc_trace_id")
    if not trace.operation_id:
        errors.append("missing operation_id")
    if not trace.input_trace_id:
        errors.append("missing input_trace_id")
    if not trace.output_trace_id:
        errors.append("missing output_trace_id")
    if trace.policy not in ALLOWED_WFC_POLICIES:
        errors.append(f"invalid policy: {trace.policy}")
    if trace.wfc_boundary_mode not in ALLOWED_BOUNDARY_MODES:
        errors.append(f"invalid boundary mode: {trace.wfc_boundary_mode}")
    if trace.candidate_count != len(candidate_tuple):
        errors.append("candidate_count does not match candidate list length")

    strict_count = sum(1 for candidate in candidate_tuple if candidate.strict_status == STRICT_PASS)
    if trace.strict_candidate_count != strict_count:
        errors.append("strict_candidate_count does not match strict candidate list length")

    if trace.wfc_status == WFC_NOT_APPLICABLE:
        if trace.candidate_count != 0:
            errors.append("WFC_NOT_APPLICABLE trace must not enumerate candidates")
        if not trace.wfc_not_applicable_reason:
            errors.append("WFC_NOT_APPLICABLE trace must include a reason")
        return tuple(errors)

    if trace.wfc_status == WFC_UNDEFINED_STRICT_EMPTY:
        if trace.strict_candidate_count != 0:
            errors.append("undefined strict-empty trace cannot have strict candidates")
        if trace.selected_candidate_id is not None:
            errors.append("undefined strict-empty trace cannot have a selected candidate")
        return tuple(errors)

    selected_candidates = [candidate for candidate in candidate_tuple if candidate.candidate_id == trace.selected_candidate_id]
    if len(selected_candidates) != 1:
        errors.append("selected_candidate_id does not identify exactly one candidate")
    else:
        selected = selected_candidates[0]
        if selected.strict_status != STRICT_PASS:
            errors.append("selected candidate is not strict-pass")
        if trace.selected_c_in != selected.c_in:
            errors.append("selected_c_in does not match selected candidate")
        if trace.q0_selected != selected.q0:
            errors.append("q0_selected does not match selected candidate")
        if trace.q0_selected != 0:
            errors.append("selected candidate violates q0 no-leakage")

    if trace.wfc_status in (WFC_STRICT_VALID_UNIQUE, WFC_TIE_RESOLVED_RN_ZERO, WFC_TIE_RESOLVED_RN_EVEN):
        if trace.strict_candidate_count < 1:
            errors.append("strict-valid/tie-resolved trace must have at least one strict candidate")

    return tuple(errors)


__all__ = [
    "RADIX",
    "DIGIT_SET",
    "RN_ZERO",
    "RN_EVEN",
    "ALLOWED_WFC_POLICIES",
    "LOWER_BOUNDARY_COMPENSATED",
    "EXTENDED_SUPPORT_BOUNDARY",
    "REJECT_NONZERO_C_IN",
    "ALLOWED_BOUNDARY_MODES",
    "FULL_STRICT_WFC_EXECUTED",
    "WFC_NOT_APPLICABLE",
    "WFC_STRICT_VALID_UNIQUE",
    "WFC_TIE_RESOLVED_RN_ZERO",
    "WFC_TIE_RESOLVED_RN_EVEN",
    "WFC_UNDEFINED_STRICT_EMPTY",
    "WFC_VALUE_PRESERVATION_FAIL",
    "WFC_NO_LEAKAGE_FAIL",
    "WFC_SUPPORT_FAIL",
    "WFC_TRACE_INCOMPLETE",
    "WFC_REJECTED",
    "CANONIZE_ONLY_BASELINE",
    "LEGAL_DIGITS_PASS",
    "LEGAL_DIGITS_FAIL",
    "NO_LEAKAGE_PASS",
    "NO_LEAKAGE_FAIL",
    "VALUE_PRESERVED_EXACT",
    "VALUE_PRESERVED_COMPENSATED",
    "VALUE_PRESERVATION_FAIL",
    "SUPPORT_OK",
    "SUPPORT_COMPENSATED_LOWER_BOUNDARY",
    "SUPPORT_REQUIRES_EXTENSION",
    "SUPPORT_FAIL",
    "STRICT_PASS",
    "STRICT_FAIL",
    "WFCError",
    "WFCConfig",
    "WFCCandidate",
    "WFCTrace",
    "WFCSelectionResult",
    "WFCAblationRecord",
    "enumerate_wfc_candidates",
    "propagate_wfc_candidate",
    "filter_wfc_strict_candidates",
    "kappa_zero_key",
    "kappa_even_key",
    "select_wfc_candidate",
    "strict_wfc",
    "validate_wfc_trace",
    "validate_wfc_trace_errors",
]
