"""
tests_audit.py

Unit tests for audit.py, the static audit layer used by PythonApplication157
under Script Contract v28.

These tests verify that the audit layer detects the contract-critical failures
that would invalidate the package as a v28 BTNS/WFC reference artifact:
    - WFC bypass in canonize_btns();
    - missing WFC operator/candidate enumeration/strict filter;
    - gold leakage into construction modules;
    - forbidden construction-boundary imports/calls;
    - matched-depth implementation missing or copied from Certified output;
    - run_wfc_ablation.py required at FINAL_PACKAGE stage;
    - parse errors and missing files;
    - warning handling at CORE_STACK stage.

The tests are static-audit tests. They copy the current source files into a
temporary project root, mutate selected files, and confirm that audit.py emits
the expected violation codes.
"""

from __future__ import annotations

from pathlib import Path
import shutil
import tempfile
import unittest

import audit


MODULE_FILES = (
    "btns_wfc.py",
    "btns_core.py",
    "btns_poly.py",
    "btns_certified.py",
    "ingress.py",
    "egress.py",
    "gold_reference.py",
)


def source_root() -> Path:
    return Path(__file__).resolve().parent


def copy_core_project(dst: Path) -> None:
    root = source_root()
    for filename in MODULE_FILES:
        shutil.copy2(root / filename, dst / filename)


def write_minimal_ablation_runner(dst: Path) -> None:
    (dst / "run_wfc_ablation.py").write_text(
        "\n".join(
            [
                '"""Minimal v28 WFC ablation runner stub for audit tests."""',
                "A0_CANONIZE_ONLY_BASELINE = 'A0_CANONIZE_ONLY_BASELINE'",
                "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW = 'A1_FULL_WFC_RN_ZERO_MAIN_WINDOW'",
                "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW = 'A2_FULL_WFC_RN_EVEN_MAIN_WINDOW'",
                "A3_FULL_WFC_SMALLER_WINDOW = 'A3_FULL_WFC_SMALLER_WINDOW'",
                "A4_FULL_WFC_LARGER_WINDOW = 'A4_FULL_WFC_LARGER_WINDOW'",
                "def run_wfc_ablation():",
                "    return [A0_CANONIZE_ONLY_BASELINE, A1_FULL_WFC_RN_ZERO_MAIN_WINDOW, A2_FULL_WFC_RN_EVEN_MAIN_WINDOW, A3_FULL_WFC_SMALLER_WINDOW, A4_FULL_WFC_LARGER_WINDOW]",
                "",
            ]
        ),
        encoding="utf-8",
    )


def violation_codes(report_or_result: object) -> set[str]:
    if isinstance(report_or_result, audit.AuditReport):
        return {item.code for item in report_or_result.violations}
    if isinstance(report_or_result, audit.ModuleAuditResult):
        return {item.code for item in report_or_result.violations}
    raise TypeError("expected AuditReport or ModuleAuditResult")


def module_result(report: audit.AuditReport, module_name: str) -> audit.ModuleAuditResult:
    for result in report.module_results:
        if result.module == module_name:
            return result
    raise AssertionError(f"module result not found: {module_name}")


class TestAuditCleanProject(unittest.TestCase):
    def test_core_stack_passes_with_expected_ablation_warning_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            report = audit.audit_project(root, stage=audit.STAGE_CORE_STACK)

        self.assertEqual(report.status, audit.STATUS_WARN)
        self.assertEqual(report.as_dict()["fail_count"], 0)
        self.assertEqual(violation_codes(report), {audit.RUNNER_REQUIRED_LATER})
        self.assertEqual(module_result(report, "btns_wfc.py").status, audit.STATUS_PASS)
        self.assertEqual(module_result(report, "btns_core.py").status, audit.STATUS_PASS)
        self.assertEqual(module_result(report, "btns_poly.py").status, audit.STATUS_PASS)

    def test_assert_audit_passes_allows_core_stack_warning_when_requested(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            report = audit.assert_audit_passes(root, stage=audit.STAGE_CORE_STACK, allow_warnings=True)

        self.assertEqual(report.status, audit.STATUS_WARN)

    def test_assert_audit_passes_can_reject_core_stack_warning(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            with self.assertRaises(AssertionError) as ctx:
                audit.assert_audit_passes(root, stage=audit.STAGE_CORE_STACK, allow_warnings=False)

        self.assertIn(audit.RUNNER_REQUIRED_LATER, str(ctx.exception))

    def test_final_package_passes_when_ablation_runner_contains_required_branches(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            write_minimal_ablation_runner(root)
            report = audit.audit_project(root, stage=audit.STAGE_FINAL_PACKAGE)

        self.assertEqual(report.status, audit.STATUS_PASS)
        self.assertEqual(len(report.violations), 0)

    def test_final_package_fails_when_ablation_runner_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            report = audit.audit_project(root, stage=audit.STAGE_FINAL_PACKAGE)

        self.assertEqual(report.status, audit.STATUS_FAIL)
        self.assertIn(audit.WFC_ABLATION_NOT_GENERATED, violation_codes(report))

    def test_invalid_stage_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            with self.assertRaises(ValueError):
                audit.audit_project(root, stage="BAD_STAGE")


class TestAuditDetectsWFCBypass(unittest.TestCase):
    def test_btns_core_canonize_without_strict_wfc_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_core.py"
            source = path.read_text(encoding="utf-8")
            source = source.replace("from btns_wfc import (", "from btns_wfc import (")
            source = source.replace("    strict_wfc,\n", "")
            source = source.replace("    result = strict_wfc(prepared, wfc_config, operation_context)", "    result = None")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_core(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.WFC_BYPASS_DETECTED, violation_codes(result))

    def test_btns_wfc_missing_strict_filter_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_wfc.py"
            source = path.read_text(encoding="utf-8")
            source = source.replace("def filter_wfc_strict_candidates", "def filter_wfc_strict_candidates_removed")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_wfc(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.REQUIRED_FUNCTION_MISSING, violation_codes(result))
        self.assertIn(audit.WFC_STRICT_FILTER_MISSING, violation_codes(result))

    def test_btns_wfc_missing_q0_no_leakage_text_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_wfc.py"
            source = path.read_text(encoding="utf-8")
            source = source.replace("q0 == 0", "q0 <= 0")
            source = source.replace("q0_selected != 0", "q0_selected < 0")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_wfc(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.WFC_NO_LEAKAGE_CHECK_MISSING, violation_codes(result))

    def test_btns_wfc_missing_policy_token_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_wfc.py"
            source = path.read_text(encoding="utf-8")
            source = source.replace("RN_EVEN", "RN_ALT")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_wfc(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.WFC_POLICY_SELECTION_MISSING, violation_codes(result))


class TestAuditDetectsConstructionBoundaryViolations(unittest.TestCase):
    def test_btns_poly_gold_leakage_import_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_poly.py"
            source = "import gold_reference\n" + path.read_text(encoding="utf-8")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_poly(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.FORBIDDEN_IMPORT_DETECTED, violation_codes(result))

    def test_btns_poly_gold_build_call_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_poly.py"
            source = path.read_text(encoding="utf-8") + "\ndef _bad_gold_call():\n    return build_gold_polynomial_coefficients([])\n"
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_poly(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.FORBIDDEN_CALL_DETECTED, violation_codes(result))

    def test_btns_certified_gold_reference_text_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_certified.py"
            source = path.read_text(encoding="utf-8") + "\nGOLD_BAD = 'gold_reference'\n"
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_certified(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.GOLD_LEAKAGE_DETECTED, violation_codes(result))

    def test_ingress_poly_import_is_flagged_as_policy_violation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "ingress.py"
            source = "import btns_poly\n" + path.read_text(encoding="utf-8")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_ingress(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.INGRESS_POLICY_VIOLATION, violation_codes(result))

    def test_egress_strict_wfc_call_is_flagged_as_policy_violation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "egress.py"
            source = path.read_text(encoding="utf-8") + "\ndef _bad_wfc_call(x, cfg):\n    return strict_wfc(x, cfg, {})\n"
            path.write_text(source, encoding="utf-8")

            result = audit.audit_egress(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.EGRESS_POLICY_VIOLATION, violation_codes(result))

    def test_gold_reference_strict_wfc_call_is_flagged_as_gold_leakage(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "gold_reference.py"
            source = path.read_text(encoding="utf-8") + "\ndef _bad_wfc_gold(x, cfg):\n    return strict_wfc(x, cfg, {})\n"
            path.write_text(source, encoding="utf-8")

            result = audit.audit_gold_reference(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.GOLD_LEAKAGE_DETECTED, violation_codes(result))


class TestAuditDetectsMatchedDepthProblems(unittest.TestCase):
    def test_missing_matched_depth_function_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_poly.py"
            source = path.read_text(encoding="utf-8")
            source = source.replace("def build_polynomial_coeffs_noncertified_matched_depth", "def build_polynomial_coeffs_noncertified_matched_depth_removed")
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_poly(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        codes = violation_codes(result)
        self.assertIn(audit.REQUIRED_FUNCTION_MISSING, codes)
        self.assertIn(audit.MATCHED_DEPTH_NOT_IMPLEMENTED, codes)

    def test_matched_depth_copying_certified_outputs_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            path = root / "btns_poly.py"
            source = path.read_text(encoding="utf-8")
            source += "\n# bad copy pattern for audit test\nCOPIED = 'coefficients=certified_result.coefficients'\n"
            path.write_text(source, encoding="utf-8")

            result = audit.audit_btns_poly(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.MATCHED_DEPTH_COPIES_CERTIFIED_OUTPUT, violation_codes(result))


class TestAuditInfrastructureFailures(unittest.TestCase):
    def test_missing_required_file_is_reported(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            (root / "btns_wfc.py").unlink()
            result = audit.audit_btns_wfc(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.FILE_MISSING, violation_codes(result))

    def test_python_parse_error_is_reported(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            (root / "btns_wfc.py").write_text("def broken(:\n    pass\n", encoding="utf-8")
            result = audit.audit_btns_wfc(root)

        self.assertEqual(result.status, audit.STATUS_FAIL)
        self.assertIn(audit.PYTHON_PARSE_ERROR, violation_codes(result))

    def test_audit_summary_lines_include_module_statuses(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_core_project(root)
            report = audit.audit_project(root, stage=audit.STAGE_CORE_STACK)
            lines = audit.audit_summary_lines(report)

        self.assertTrue(lines[0].startswith("audit_status="))
        self.assertTrue(any("btns_wfc.py:" in line for line in lines))
        self.assertTrue(any(audit.RUNNER_REQUIRED_LATER in line for line in lines))

    def test_dataclass_as_dict_methods_are_machine_readable(self) -> None:
        violation = audit.AuditViolation("CODE", "module.py", "message", audit.STATUS_WARN, 7)
        module_result_obj = audit.ModuleAuditResult("module.py", "/tmp/module.py", audit.STATUS_WARN, (violation,))
        report = audit.AuditReport("/tmp", audit.STAGE_CORE_STACK, audit.STATUS_WARN, (module_result_obj,), (violation,))

        self.assertEqual(violation.as_dict()["code"], "CODE")
        self.assertEqual(module_result_obj.as_dict()["status"], audit.STATUS_WARN)
        self.assertEqual(report.as_dict()["warn_count"], 1)
        self.assertEqual(report.as_dict()["fail_count"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
