"""
tests_core.py

Unit tests for btns_core.py, the BTNS arithmetic kernel used by
PythonApplication157 under Script Contract v28.

These tests verify that the preserved P129/v22 integer-only BTNS arithmetic
remains stable while the new v28 canonize_btns() interface routes canonical
boundary decisions through btns_wfc.strict_wfc().

The tests are intentionally construction-boundary safe:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel / workbook / gold-reference / egress calls

They cover:
    - BTNSNumber and TailBound validation
    - digit legality and closed BTNS representation
    - native addition / negation / subtraction / multiplication
    - balanced carry normalization
    - no silent low-exponent truncation when TAIL_NONE is requested
    - canonize_btns() requiring explicit WFCConfig
    - canonize_btns() invoking strict_wfc() and returning WFC traces
    - WFC_NOT_APPLICABLE handling through explicit context only
    - strict-empty WFC propagation raising in normal canonization mode
    - return_result=True giving access to WFCSelectionResult
"""

from __future__ import annotations

import unittest

import btns_core as core
import btns_wfc as wfc


class TestTailBoundAndBTNSNumber(unittest.TestCase):
    def test_tail_bound_accepts_zero_tail(self) -> None:
        tail = core.TailBound(
            lower_exp=-3,
            abs_bound_num=0,
            abs_bound_den_power3=3,
            policy=core.TAIL_NONE,
            source=core.SOURCE_TEST,
        )
        self.assertTrue(tail.is_zero)

    def test_tail_bound_rejects_unknown_policy(self) -> None:
        with self.assertRaises(ValueError):
            core.TailBound(
                lower_exp=-1,
                abs_bound_num=1,
                abs_bound_den_power3=1,
                policy="BAD_POLICY",
                source=core.SOURCE_TEST,
            )

    def test_btns_number_fills_missing_digits_and_validates(self) -> None:
        x = core.BTNSNumber(
            digits={0: 1, -2: -1},
            k_min=-2,
            k_max=0,
            canonicality_flag=core.CANONICAL_LEGAL,
            source_tag=core.SOURCE_TEST,
            trace_id="X",
        )
        self.assertEqual(x.digits[-1], 0)
        self.assertTrue(core.validate_digits(x))

    def test_btns_number_rejects_illegal_digit(self) -> None:
        with self.assertRaises(ValueError):
            core.BTNSNumber(
                digits={0: 2},
                k_min=0,
                k_max=0,
                canonicality_flag=core.CANONICAL_LEGAL,
                source_tag=core.SOURCE_TEST,
            )

    def test_btns_number_rejects_nonzero_digit_outside_support(self) -> None:
        with self.assertRaises(ValueError):
            core.BTNSNumber(
                digits={0: 1, 2: 1},
                k_min=0,
                k_max=0,
                canonicality_flag=core.CANONICAL_LEGAL,
                source_tag=core.SOURCE_TEST,
            )


class TestNormalizationAndArithmetic(unittest.TestCase):
    def test_normalize_positive_two_to_balanced_digits(self) -> None:
        x = core.normalize_digits(
            {0: 2},
            k_min=0,
            k_max=0,
            tail_policy=core.TAIL_NONE,
            source_tag=core.SOURCE_TEST,
            trace_id="NORMALIZE_TWO",
        )
        self.assertEqual(x.digits[0], -1)
        self.assertEqual(x.digits[1], 1)
        self.assertTrue(core.validate_digits(x))

    def test_normalize_negative_two_to_balanced_digits(self) -> None:
        x = core.normalize_digits(
            {0: -2},
            k_min=0,
            k_max=0,
            tail_policy=core.TAIL_NONE,
            source_tag=core.SOURCE_TEST,
            trace_id="NORMALIZE_MINUS_TWO",
        )
        self.assertEqual(x.digits[0], 1)
        self.assertEqual(x.digits[1], -1)
        self.assertTrue(core.validate_digits(x))

    def test_tail_none_blocks_silent_low_exponent_truncation(self) -> None:
        with self.assertRaises(ArithmeticError):
            core.normalize_digits(
                {-1: 1, 0: 0},
                k_min=0,
                k_max=0,
                tail_policy=core.TAIL_NONE,
                source_tag=core.SOURCE_TEST,
                trace_id="NO_SILENT_TRUNCATION",
            )

    def test_addition_closure_one_plus_one(self) -> None:
        one = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="ONE")
        two = core.add_btns(one, one)
        self.assertTrue(core.validate_digits(two))
        self.assertEqual(two.digits[0], -1)
        self.assertEqual(two.digits[1], 1)

    def test_negation_and_subtraction_consistency(self) -> None:
        one = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="ONE")
        two = core.add_btns(one, one)
        minus_one = core.neg_btns(one)
        self.assertEqual(minus_one.digits[0], -1)
        self.assertTrue(core.btns_equal_digits(core.sub_btns(two, one), one))

    def test_multiplication_closure_two_times_two(self) -> None:
        one = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="ONE")
        two = core.add_btns(one, one)
        four = core.mul_btns(two, two)
        self.assertTrue(core.validate_digits(four))
        self.assertEqual(four.digits[0], 1)
        self.assertEqual(four.digits[1], 1)

    def test_digit_string_kmax_to_kmin(self) -> None:
        x = core.make_btns_number_from_digits({0: -1, 1: 1, -1: 1}, -1, 1, trace_id="STR")
        self.assertEqual(core.digit_string_kmax_to_kmin(x), "[1,-1 | 1]")


class TestCanonizeBTNSWFCIntegration(unittest.TestCase):
    def test_canonize_requires_explicit_wfc_config(self) -> None:
        x = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="X")
        with self.assertRaises(TypeError):
            core.canonize_btns(x, None, {"operation_id": "NO_CONFIG"})  # type: ignore[arg-type]

    def test_canonize_invokes_strict_wfc_and_updates_trace_fields(self) -> None:
        x = core.make_btns_number_from_digits({-2: 0, -1: 0, 0: 0}, -2, 0, trace_id="X")
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        y = core.canonize_btns(x, cfg, {"operation_id": "CANONIZE_ZERO"})

        self.assertIsInstance(y, core.BTNSNumber)
        self.assertIsNotNone(y.wfc_trace_id)
        self.assertIn(y.wfc_status, {wfc.WFC_STRICT_VALID_UNIQUE, wfc.WFC_TIE_RESOLVED_RN_ZERO})
        self.assertTrue(core.validate_digits(y))

    def test_canonize_return_result_exposes_wfc_candidates_and_trace(self) -> None:
        x = core.make_btns_number_from_digits({-1: 0, 0: 0}, -1, 0, trace_id="X")
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_ZERO)

        result = core.canonize_btns(x, cfg, {"operation_id": "RETURN_RESULT"}, return_result=True)

        self.assertIsInstance(result, wfc.WFCSelectionResult)
        self.assertEqual(result.trace.candidate_count, 3)
        self.assertEqual(len(result.candidates), 3)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))
        self.assertIsInstance(result.canonical_object, core.BTNSNumber)

    def test_canonize_not_applicable_requires_explicit_reason_and_records_trace(self) -> None:
        one = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="ONE")
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)

        result = core.canonize_btns_not_applicable(
            one,
            cfg,
            reason="EXACT_LEADING_COEFFICIENT",
            operation_id="LEADING_COEFF",
            return_result=True,
        )

        self.assertIsInstance(result, wfc.WFCSelectionResult)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_NOT_APPLICABLE)
        self.assertEqual(result.trace.wfc_not_applicable_reason, "EXACT_LEADING_COEFFICIENT")
        self.assertEqual(result.trace.candidate_count, 0)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))
        self.assertIsInstance(result.canonical_object, core.BTNSNumber)
        self.assertEqual(result.canonical_object.wfc_status, wfc.WFC_NOT_APPLICABLE)

    def test_canonize_raises_when_strict_wfc_family_is_empty(self) -> None:
        # Legal BTNS support is too narrow for W_w={0,-1}; the WFC support check
        # must reject the candidates rather than silently expanding support.
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="NARROW_ZERO")
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_ZERO)

        with self.assertRaises(ArithmeticError):
            core.canonize_btns(x, cfg, {"operation_id": "STRICT_EMPTY_BY_SUPPORT"})

        result = core.canonize_btns(
            x,
            cfg,
            {"operation_id": "STRICT_EMPTY_BY_SUPPORT_RESULT"},
            return_result=True,
        )
        self.assertIsNone(result.canonical_object)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_UNDEFINED_STRICT_EMPTY)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))

    def test_canonize_after_addition_can_commit_with_wfc_trace(self) -> None:
        one = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="ONE")
        minus_one = core.make_btns_number_from_digits({0: -1}, 0, 0, trace_id="MINUS_ONE")
        raw_zero = core.add_btns(one, minus_one)
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)

        committed = core.canonize_btns(raw_zero, cfg, {"operation_id": "A1_COMMIT_ZERO"})

        self.assertTrue(core.validate_digits(committed))
        self.assertIsNotNone(committed.wfc_trace_id)
        self.assertIsNotNone(committed.wfc_status)
        self.assertEqual(committed.digits[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
