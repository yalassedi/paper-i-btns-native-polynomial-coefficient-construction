"""
Unit tests for run_m10_campaign.py, the ninth-stage m = 10 campaign runner used by
PythonApplication157 under Script Contract v28.

These tests verify that the campaign runner integrates the already validated
BTNS/WFC construction stack and emits the required ninth-stage evidence package:
    - manifest.json;
    - settings_signature.json;
    - final_run_summary.json;
    - BTNS_m10_results_v28.xlsx;
    - workbook payload JSON;
    - WFC sidecars;
    - matched-depth fairness sidecars;
    - WFC ablation sidecars.

The runner is an evidence/campaign layer. It must coordinate validated modules,
not implement BTNS arithmetic, WFC candidate selection, or Certified construction
logic directly.
"""

from __future__ import annotations

import ast
import csv
import inspect
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

import audit
import ingress
import reporting
import run_m10_campaign as campaign


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


class CampaignFixture:
    """Run one small but complete m=10 campaign for test reuse."""

    def __init__(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.input_csv = self.root / "sample_roots_m10.csv"
        self.output_dir = self.root / "out"
        campaign.write_default_sample_roots(self.input_csv)
        self.result = campaign.run_m10_campaign(
            input_csv=self.input_csv,
            output_dir=self.output_dir,
            k_min_grid=(-1,),
            k_max=1,
            wfc_window_width=1,
            max_groups=1,
            report_decimal_digits=6,
        )

    def cleanup(self) -> None:
        self.tmp.cleanup()


class TestDefaultInputAndHelpers(unittest.TestCase):
    def test_write_default_sample_roots_creates_valid_csv(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample_roots_m10.csv"
            returned = campaign.write_default_sample_roots(path)

            self.assertEqual(str(path), returned)
            self.assertTrue(path.exists())

            rows = ingress.load_root_input_csv(path)
            self.assertEqual(len(rows), 20)
            self.assertEqual({row.group_id for row in rows}, {"G01", "G02"})
            self.assertTrue(all(row.active_for_m.upper() == "TRUE" for row in rows))

    def test_parse_k_min_grid_accepts_comma_separated_integers(self) -> None:
        self.assertEqual(campaign._parse_k_min_grid("-20,-30,-40"), (-20, -30, -40))

    def test_parse_k_min_grid_rejects_empty_grid(self) -> None:
        with self.assertRaises(Exception):
            campaign._parse_k_min_grid(" , , ")

    def test_consolidated_package_has_current_stage_defaults(self) -> None:
        source = inspect.getsource(campaign)
        self.assertIn('default="btns_m10_output_157"', source)
        self.assertNotIn('default="btns_m10_output_153"', source)
        self.assertIn('PythonApplication157', source)


class TestRunM10CampaignOutputs(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = CampaignFixture()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.fixture.cleanup()

    @property
    def output_dir(self) -> Path:
        return self.fixture.output_dir

    @property
    def result(self) -> campaign.CampaignRunResult:
        return self.fixture.result

    def test_campaign_returns_valid_and_promotable_run(self) -> None:
        self.assertEqual(self.result.run_status, campaign.VALID_RUN)
        self.assertEqual(self.result.promotion_status, campaign.PROMOTABLE_RUN)
        self.assertEqual(len(self.result.cases), 1)
        self.assertEqual(self.result.cases[0].group_id, "G01")
        self.assertEqual(self.result.cases[0].k_min, -1)

    def test_required_json_outputs_exist_and_have_v28_identity(self) -> None:
        manifest_path = self.output_dir / "manifest.json"
        settings_path = self.output_dir / "settings_signature.json"
        summary_path = self.output_dir / "final_run_summary.json"

        for path in (manifest_path, settings_path, summary_path):
            self.assertTrue(path.exists(), f"missing {path.name}")

        manifest = read_json(manifest_path)
        settings = read_json(settings_path)
        final_summary = read_json(summary_path)

        self.assertEqual(manifest["contract_version"], "v28")
        self.assertEqual(manifest["package_name"], "PythonApplication157")
        self.assertEqual(manifest["reference_label"], campaign.REFERENCE_LABEL)
        self.assertEqual(settings["m"], 10)
        self.assertEqual(settings["matched_depth_fairness_policy"], "REQUIRED")
        self.assertEqual(settings["wfc_ablation_policy"], "REQUIRED")
        self.assertEqual(final_summary["run_status"], campaign.VALID_RUN)
        self.assertEqual(final_summary["promotion_status"], campaign.PROMOTABLE_RUN)


    def test_run_config_json_is_nested_and_not_key_value_bug(self) -> None:
        run_config = read_json(self.output_dir / "run_config.json")

        self.assertEqual(run_config["contract_version"], "v28")
        self.assertEqual(run_config["runner"], "run_m10_campaign.py")
        self.assertEqual(run_config["m"], 10)
        self.assertIn("wfc_config", run_config)
        self.assertIsInstance(run_config["wfc_config"], dict)
        self.assertNotEqual(run_config, {"key": "value"})

    def test_operation_cost_accounting_is_populated(self) -> None:
        rows = read_csv_rows(self.output_dir / "operation_cost_accounting.csv")

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["m"], "10")
        self.assertGreater(int(rows[0]["wfc_candidate_count"]), 0)
        self.assertGreater(int(rows[0]["certified_decision_count"]), 0)

    def test_empty_wfc_undefined_cases_has_headers(self) -> None:
        path = self.output_dir / "wfc_undefined_cases.csv"
        text = path.read_text(encoding="utf-8")

        self.assertTrue(text.startswith("group_id,k_min_case,wfc_trace_id"))

    def test_manifest_contains_reproducibility_hashes(self) -> None:
        manifest = read_json(self.output_dir / "manifest.json")

        for key in (
            "script_hashes",
            "input_hashes",
            "config_hash",
            "output_hashes",
            "matched_depth_completion_hash",
            "wfc_trace_hash",
            "wfc_candidate_family_hash",
            "wfc_ablation_hash",
        ):
            self.assertIn(key, manifest)

        self.assertIn("BTNS_m10_results_v28.xlsx", manifest["output_hashes"])
        self.assertIn("run_m10_campaign.py", manifest["script_hashes"])
        self.assertNotEqual(manifest["wfc_trace_hash"], "MISSING")

    def test_final_summary_gates_are_clean(self) -> None:
        final_summary = read_json(self.output_dir / "final_run_summary.json")
        gates = final_summary["gates"]

        self.assertEqual(gates["audit_fail_count"], 0)
        self.assertEqual(gates["matched_depth_not_run_invalid_count"], 0)
        self.assertEqual(gates["matched_depth_copied_trace_invalid_count"], 0)
        self.assertEqual(gates["certified_path_not_distinct_count"], 0)
        self.assertGreater(gates["certified_construction_decision_count"], 0)
        self.assertGreater(gates["wfc_trace_count"], 0)
        self.assertEqual(gates["wfc_invalid_trace_count"], 0)
        self.assertEqual(gates["wfc_ablation_incomplete_count"], 0)
        self.assertEqual(gates["worse_count"], 0)

    def test_required_sidecar_files_exist(self) -> None:
        required = {
            "run_config.json",
            "manifest.json",
            "settings_signature.json",
            "final_run_summary.json",
            "operation_cost_accounting.csv",
            "input_roots_all.csv",
            "input_roots_selected.csv",
            "root_ingress_btns.csv",
            "noncertified_coefficients.csv",
            "certified_coefficients.csv",
            "gold_comparison.csv",
            "campaign_summary.csv",
            "campaign_summary_by_k_min.csv",
            "certified_path_comparison.csv",
            "certified_decision_chain.csv",
            "wfc_operation_trace.csv",
            "wfc_candidate_family.csv",
            "wfc_strict_admissibility.csv",
            "wfc_tie_policy_selection.csv",
            "wfc_ablation_summary.csv",
            "matched_depth_fairness.csv",
            "wfc_ucc_cross_summary.csv",
            "BTNS_m10_results_v28_workbook_payload.json",
            "BTNS_m10_results_v28.xlsx",
        }

        missing = [name for name in required if not (self.output_dir / name).exists()]
        self.assertEqual(missing, [])

    def test_wfc_and_matched_depth_sidecars_are_populated(self) -> None:
        wfc_ops = read_csv_rows(self.output_dir / "wfc_operation_trace.csv")
        wfc_candidates = read_csv_rows(self.output_dir / "wfc_candidate_family.csv")
        strict_rows = read_csv_rows(self.output_dir / "wfc_strict_admissibility.csv")
        tie_rows = read_csv_rows(self.output_dir / "wfc_tie_policy_selection.csv")
        matched_rows = read_csv_rows(self.output_dir / "matched_depth_fairness.csv")
        ablation_rows = read_csv_rows(self.output_dir / "wfc_ablation_summary.csv")

        self.assertGreater(len(wfc_ops), 0)
        self.assertGreater(len(wfc_candidates), 0)
        self.assertGreater(len(strict_rows), 0)
        self.assertGreater(len(tie_rows), 0)
        self.assertEqual(len(matched_rows), 11)
        self.assertEqual(len(ablation_rows), 5)
        self.assertTrue(all(row["matched_depth_comparison"] == "MATCHED_DEPTH_EQUAL" for row in matched_rows))
        self.assertEqual({row["branch_id"] for row in ablation_rows}, {
            "A0_CANONIZE_ONLY_BASELINE",
            "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW",
            "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW",
            "A3_FULL_WFC_SMALLER_WINDOW",
            "A4_FULL_WFC_LARGER_WINDOW",
        })

    def test_coefficients_and_gold_comparison_are_populated(self) -> None:
        noncert_rows = read_csv_rows(self.output_dir / "noncertified_coefficients.csv")
        cert_rows = read_csv_rows(self.output_dir / "certified_coefficients.csv")
        gold_rows = read_csv_rows(self.output_dir / "gold_comparison.csv")

        self.assertEqual(len(noncert_rows), 11)
        self.assertEqual(len(cert_rows), 11)
        self.assertEqual(len(gold_rows), 11)
        self.assertTrue(all("wfc_trace_id" in row for row in noncert_rows))
        self.assertTrue(all("decimal_center" in row for row in cert_rows))
        self.assertTrue(all(row["abs_error_numerator"] == "0" for row in gold_rows))

    def test_workbook_payload_contains_all_required_sheets(self) -> None:
        payload = read_json(self.output_dir / "BTNS_m10_results_v28_workbook_payload.json")

        self.assertEqual(set(payload), set(reporting.DEFAULT_SHEET_ORDER))
        self.assertEqual(len(payload[reporting.SHEET_NONCERTIFIED_COEFFICIENTS]), 11)
        self.assertEqual(len(payload[reporting.SHEET_CERTIFIED_COEFFICIENTS]), 11)
        self.assertGreater(len(payload[reporting.SHEET_WFC_OPERATION_TRACE]), 0)
        self.assertEqual(len(payload[reporting.SHEET_WFC_ABLATION_SUMMARY]), 5)
        self.assertEqual(len(payload[reporting.SHEET_MATCHED_DEPTH_FAIRNESS]), 11)

    def test_xlsx_workbook_is_valid_zip_with_expected_worksheet_count(self) -> None:
        workbook = self.output_dir / "BTNS_m10_results_v28.xlsx"

        self.assertTrue(workbook.exists())
        self.assertTrue(zipfile.is_zipfile(workbook))
        with zipfile.ZipFile(workbook, "r") as zf:
            names = set(zf.namelist())
            worksheet_names = [name for name in names if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")]
            self.assertIn("[Content_Types].xml", names)
            self.assertIn("xl/workbook.xml", names)
            self.assertEqual(len(worksheet_names), len(reporting.DEFAULT_SHEET_ORDER))

    def test_campaign_summary_by_k_min_is_present(self) -> None:
        rows = read_csv_rows(self.output_dir / "campaign_summary_by_k_min.csv")

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["k_min"], "-1")
        self.assertEqual(rows[0]["all_certified_equal_matched_values"], "True")
        self.assertEqual(rows[0]["matched_depth_invalid_total"], "0")


class TestRunM10CampaignBoundarySafety(unittest.TestCase):
    def test_runner_source_does_not_implement_wfc_selection_or_btns_arithmetic_directly(self) -> None:
        source = inspect.getsource(campaign)
        tree = ast.parse(source)

        forbidden_calls = {
            "strict_wfc",
            "select_wfc_candidate",
            "propagate_wfc_candidate",
            "enumerate_wfc_candidates",
            "normalize_digits",
            "add_btns",
            "mul_btns",
            "sub_btns",
            "neg_btns",
            "certify_operation",
            "certify_coefficient",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_runner_uses_allowed_campaign_dependencies(self) -> None:
        source = inspect.getsource(campaign)

        self.assertIn("import ingress", source)
        self.assertIn("import reporting", source)
        self.assertIn("import run_wfc_ablation", source)
        self.assertIn("import gold_reference as gold", source)
        self.assertIn("from btns_poly import", source)
        self.assertNotIn("from decimal", source)
        self.assertNotIn("import numpy", source)
        self.assertNotIn("import sympy", source)
        self.assertNotIn("openpyxl", source)

    def test_audit_final_package_passes_for_current_source_root(self) -> None:
        report = audit.audit_project(Path(__file__).resolve().parent, stage=audit.STAGE_FINAL_PACKAGE)

        self.assertEqual(report.status, audit.STATUS_PASS)
        self.assertEqual(len(report.violations), 0)


class TestRunM10CampaignSelfCheck(unittest.TestCase):
    def test_self_check_runs_to_completion(self) -> None:
        # The self-check runs in a temporary directory and verifies the central
        # output files. It is intentionally small: one group and one k_min.
        campaign.self_check()


if __name__ == "__main__":
    unittest.main(verbosity=2)
