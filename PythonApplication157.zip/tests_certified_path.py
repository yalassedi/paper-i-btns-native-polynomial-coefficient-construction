"""
tests_certified_path.py

Unit tests for btns_certified.py, the Certified governance layer used by
PythonApplication157 under Script Contract v28.

These tests verify that the certified governance layer complements the already
validated WFC/core/poly layers without violating the construction boundary:
    - no Decimal / Fraction arithmetic in the certified module;
    - no NumPy / SymPy;
    - no Excel / workbook / egress / gold-reference construction calls;
    - no coefficient construction by decimal arithmetic;
    - WFC candidates and selections are certified using trace/status evidence;
    - Certified vs Non-Certified and matched-depth comparisons distinguish
      value equality from trace/path independence.
"""

from __future__ import annotations

import ast
import inspect
import unittest

import btns_certified as cert
import btns_core as core
import btns_poly as poly
import btns_wfc as wfc


def one(trace_id: str = "ONE", *, k_min: int = 0, k_max: int = 0) -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(trace_id: str = "TWO", *, k_min: int = 0, k_max: int = 0) -> core.BTNSNumber:
    return core.add_btns(
        one(trace_id=trace_id + "_A", k_min=k_min, k_max=k_max),
        one(trace_id=trace_id + "_B", k_min=k_min, k_max=k_max),
    )


def basic_config(**overrides: object) -> poly.CampaignConfig:
    params: dict[str, object] = {
        "k_min": 0,
        "k_max": 0,
        "trace_prefix": "TEST_CERTIFIED_PATH_V28",
        "wfc_window_width": 0,
        "wfc_policy": wfc.RN_ZERO,
    }
    params.update(overrides)
    return poly.CampaignConfig(**params)


def build_reference_results() -> tuple[poly.PolynomialResult, poly.CertifiedPolynomialResult, poly.MatchedDepthPolynomialResult]:
    cfg = basic_config()
    r1 = one("R1")
    r2 = two("R2")
    noncert = poly.build_quadratic_coeffs_noncertified(r1, r2, cfg)
    certified = poly.build_quadratic_coeffs_certified_independent(r1, r2, cfg)
    matched = poly.build_quadratic_coeffs_noncertified_matched_depth(r1, r2, cfg.k_min, cfg, certified)
    return noncert, certified, matched


class TestIntervalEnclosureAndCoefficientCertification(unittest.TestCase):
    def test_compute_tail_bound_returns_zero_structured_bound_when_absent(self) -> None:
        x = one("TAIL_ZERO")
        tail = cert.compute_tail_bound(x)

        self.assertIsInstance(tail, core.TailBound)
        self.assertEqual(tail.abs_bound_num, 0)
        self.assertEqual(tail.policy, core.TAIL_REFINEMENT)
        self.assertEqual(tail.source, core.SOURCE_CERTIFIED)

    def test_make_interval_enclosure_for_exact_two(self) -> None:
        x = two("EXACT_TWO")
        interval = cert.make_interval_enclosure(x)

        # 2 has an exact finite enclosure [2, 2] at denominator 3^0.
        self.assertEqual(interval.lower_num, 2)
        self.assertEqual(interval.upper_num, 2)
        self.assertEqual(interval.den_power3, 0)
        self.assertEqual(interval.width_num, 0)

    def test_classify_true_false_and_tube(self) -> None:
        exact_one_interval = cert.make_interval_enclosure(one("CLASSIFY_ONE"))

        self.assertEqual(
            cert.classify_true_tube_false(
                exact_one_interval,
                gold_num=1,
                gold_den_power3=0,
                accepted_width_num=0,
                accepted_width_den_power3=0,
            ),
            cert.TRUE,
        )
        self.assertEqual(
            cert.classify_true_tube_false(
                exact_one_interval,
                gold_num=2,
                gold_den_power3=0,
                accepted_width_num=0,
                accepted_width_den_power3=0,
            ),
            cert.FALSE,
        )

        tail = core.TailBound(
            lower_exp=-1,
            abs_bound_num=1,
            abs_bound_den_power3=1,
            policy=core.TAIL_REFINEMENT,
            source=core.SOURCE_CERTIFIED,
        )
        uncertain = core.BTNSNumber(
            digits={0: 1},
            k_min=0,
            k_max=0,
            tail_bound=tail,
            canonicality_flag=core.CANONICAL_LEGAL,
            source_tag=core.SOURCE_CERTIFIED,
            trace_id="UNCERTAIN_ONE",
        )
        uncertain_interval = cert.make_interval_enclosure(uncertain)
        self.assertEqual(
            cert.classify_true_tube_false(
                uncertain_interval,
                gold_num=1,
                gold_den_power3=0,
                accepted_width_num=0,
                accepted_width_den_power3=0,
            ),
            cert.TUBE,
        )

    def test_certify_coefficient_without_gold_is_tube(self) -> None:
        certificate = cert.certify_coefficient(one("NO_GOLD"), 0)

        self.assertEqual(certificate.decision_token, cert.TUBE)
        self.assertIsNone(certificate.gold_num)
        self.assertEqual(certificate.message, "NO_EXTERNAL_GOLD_SUPPLIED_POST_CONSTRUCTION")

    def test_certify_coefficient_with_gold_can_be_true_or_false(self) -> None:
        true_cert = cert.certify_coefficient(
            one("GOLD_TRUE"),
            0,
            gold_num=1,
            gold_den_power3=0,
            accepted_width_num=0,
            accepted_width_den_power3=0,
        )
        false_cert = cert.certify_coefficient(
            one("GOLD_FALSE"),
            0,
            gold_num=2,
            gold_den_power3=0,
            accepted_width_num=0,
            accepted_width_den_power3=0,
        )

        self.assertEqual(true_cert.decision_token, cert.TRUE)
        self.assertEqual(false_cert.decision_token, cert.FALSE)


class TestRefinementInterface(unittest.TestCase):
    def test_refinement_request_is_formal_and_does_not_run_ingress(self) -> None:
        request = cert.request_certified_refinement(
            root_records=("r1", "r2"),
            current_k_min=-20,
            target_k_min=-30,
            rounding_policy="ROUND_NEAREST_TIES_TO_ZERO",
            config={"m": 2},
        )

        self.assertEqual(request.status, cert.REFINEMENT_REQUESTED)
        self.assertEqual(request.current_k_min, -20)
        self.assertEqual(request.target_k_min, -30)
        self.assertIn("ingress.py", request.message)

    def test_refinement_request_rejects_non_deeper_target(self) -> None:
        request = cert.request_certified_refinement(
            root_records=("r1",),
            current_k_min=-20,
            target_k_min=-20,
            rounding_policy="ROUND_NEAREST_TIES_TO_ZERO",
            config={},
        )

        self.assertEqual(request.status, cert.REFINEMENT_INVALID)


class TestWFCCandidateAndSelectionCertification(unittest.TestCase):
    def test_certify_wfc_candidate_accepts_strict_candidate(self) -> None:
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="STRICT_CANDIDATE_INPUT")
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        candidates = wfc.enumerate_wfc_candidates(x, cfg, "STRICT_CANDIDATE_OP")
        strict_candidates = wfc.filter_wfc_strict_candidates(candidates)

        self.assertGreater(len(strict_candidates), 0)
        certificate = cert.certify_wfc_candidate(strict_candidates[0])

        self.assertEqual(certificate.decision_token, cert.WFC_CANDIDATE_CERTIFIED)
        self.assertEqual(certificate.q0, 0)

    def test_certify_wfc_candidate_rejects_q0_leakage(self) -> None:
        x = core.make_btns_number_from_digits({0: 1}, 0, 0, trace_id="LEAK_INPUT")
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        leaking = wfc.propagate_wfc_candidate(x, cfg, 1, "LEAKING_CANDIDATE_OP")

        certificate = cert.certify_wfc_candidate(leaking)

        self.assertEqual(certificate.decision_token, cert.WFC_CANDIDATE_REJECTED)
        self.assertIn("q0", certificate.message)

    def test_certify_wfc_selection_accepts_valid_selection(self) -> None:
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="VALID_WFC_SELECTION")
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        result = wfc.strict_wfc(x, cfg, {"operation_id": "VALID_SELECTION"})

        selection_certificate = cert.certify_wfc_selection(result)

        self.assertEqual(selection_certificate.decision_token, cert.WFC_SELECTION_CERTIFIED)
        self.assertEqual(selection_certificate.q0_selected, 0)

    def test_certify_wfc_selection_maps_strict_empty_to_tube_hold(self) -> None:
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="STRICT_EMPTY_INPUT")
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_ZERO)
        result = core.canonize_btns(x, cfg, {"operation_id": "STRICT_EMPTY_SELECTION"}, return_result=True)

        self.assertIsInstance(result, wfc.WFCSelectionResult)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_UNDEFINED_STRICT_EMPTY)
        selection_certificate = cert.certify_wfc_selection(result)

        self.assertEqual(selection_certificate.decision_token, poly.CERT_TUBE_HOLD)
        self.assertEqual(selection_certificate.strict_candidate_count, 0)

    def test_certified_candidate_acceptance_uses_wfc_metadata_not_gold(self) -> None:
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="ACCEPT_CANDIDATE_INPUT")
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        candidates = wfc.enumerate_wfc_candidates(x, cfg, "ACCEPTANCE_OP")

        record = cert.certified_candidate_acceptance(candidates)

        self.assertTrue(record.accepted)
        self.assertEqual(record.decision_token, poly.CERT_ACCEPT)
        self.assertIsNotNone(record.candidate_id)


class TestOperationCertification(unittest.TestCase):
    def test_certify_operation_carries_wfc_fields(self) -> None:
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="OP_INPUT")
        result = core.canonize_btns(x, cfg, {"operation_id": "OP_WFC"}, return_result=True)
        self.assertIsInstance(result, wfc.WFCSelectionResult)
        self.assertIsInstance(result.canonical_object, core.BTNSNumber)

        operation_certificate = cert.certify_operation(
            "TEST_WFC_OPERATION",
            result.canonical_object,
            inputs=(x,),
            wfc_result=result,
            decision_token=poly.CERT_ACCEPT,
        )

        self.assertTrue(operation_certificate.operation_id.startswith("CERT_OP_"))
        self.assertEqual(operation_certificate.wfc_trace_id, result.trace.wfc_trace_id)
        self.assertEqual(operation_certificate.wfc_window_width, 0)
        self.assertEqual(operation_certificate.wfc_policy, wfc.RN_ZERO)
        self.assertEqual(operation_certificate.decision_token, poly.CERT_ACCEPT)

    def test_certify_operation_rejects_invalid_wfc_trace(self) -> None:
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)
        x = core.make_btns_number_from_digits({0: 0}, 0, 0, trace_id="BAD_OP_INPUT")
        result = core.canonize_btns(x, cfg, {"operation_id": "BAD_OP_WFC"}, return_result=True)
        self.assertIsInstance(result, wfc.WFCSelectionResult)
        self.assertIsInstance(result.canonical_object, core.BTNSNumber)

        bad_trace = wfc.WFCTrace(
            wfc_trace_id=result.trace.wfc_trace_id,
            operation_id=result.trace.operation_id,
            input_trace_id=result.trace.input_trace_id,
            output_trace_id=result.trace.output_trace_id,
            window_width=result.trace.window_width,
            policy=result.trace.policy,
            candidate_count=999,
            strict_candidate_count=result.trace.strict_candidate_count,
            selected_candidate_id=result.trace.selected_candidate_id,
            selected_c_in=result.trace.selected_c_in,
            q0_selected=result.trace.q0_selected,
            wfc_status=result.trace.wfc_status,
            wfc_boundary_mode=result.trace.wfc_boundary_mode,
            wfc_not_applicable_reason=result.trace.wfc_not_applicable_reason,
        )
        bad_result = wfc.WFCSelectionResult(
            canonical_object=result.canonical_object,
            trace=bad_trace,
            candidates=result.candidates,
        )

        with self.assertRaises(ValueError):
            cert.certify_operation(
                "BAD_WFC_OPERATION",
                result.canonical_object,
                inputs=(x,),
                wfc_result=bad_result,
            )


class TestPathComparisonGovernance(unittest.TestCase):
    def test_compare_certified_path_to_noncertified_reports_value_equal_trace_distinct(self) -> None:
        noncert, certified, _matched = build_reference_results()
        records = cert.compare_certified_path_to_noncertified_path(certified, noncert)

        self.assertEqual(len(records), 3)
        for record in records:
            self.assertEqual(record.value_comparison_token, cert.CERT_VALUE_EQUAL_TO_NONCERT)
            self.assertEqual(record.path_comparison_token, cert.CERT_PATH_DISTINCT_FROM_NONCERT)
            self.assertEqual(record.trace_comparison_token, cert.VALUE_IDENTICAL_TRACE_DIFFERENT)
            self.assertNotEqual(record.certified_trace_id, record.other_trace_id)

    def test_compare_certified_path_detects_identical_trace_invalid(self) -> None:
        _noncert, certified, _matched = build_reference_results()
        # Deliberately compare the Certified result to itself to simulate an
        # invalid copied-trace/path scenario.
        records = cert.compare_certified_path_to_noncertified_path(certified, certified)

        self.assertTrue(any(record.path_comparison_token == cert.CERT_PATH_IDENTICAL_TO_NONCERT_INVALID for record in records))
        self.assertTrue(any(record.trace_comparison_token == cert.VALUE_IDENTICAL_TRACE_IDENTICAL_INVALID for record in records))

    def test_compare_certified_to_matched_depth_reports_equal_and_not_copied(self) -> None:
        _noncert, certified, matched = build_reference_results()
        records = cert.compare_certified_path_to_matched_depth_noncertified_path(certified, matched)

        self.assertEqual(len(records), 3)
        for record in records:
            self.assertEqual(record.matched_depth_comparison, poly.MATCHED_DEPTH_EQUAL)
            self.assertFalse(record.copied_trace_invalid)
            self.assertNotEqual(record.certified_trace_id, record.matched_trace_id)

    def test_compare_certified_to_matched_depth_detects_copied_traces(self) -> None:
        _noncert, certified, _matched = build_reference_results()
        fake_matched = poly.MatchedDepthPolynomialResult(
            mode=poly.MODE_NONCERTIFIED_MATCHED_DEPTH,
            m=certified.m,
            coefficients=certified.coefficients,
            traces=certified.traces,
            status=certified.status,
            message="fake copied matched result for invalidity test",
            wfc_results=certified.wfc_results,
            certified_final_k_min=0,
            matched_depth_records=tuple(),
        )

        records = cert.compare_certified_path_to_matched_depth_noncertified_path(certified, fake_matched)

        self.assertTrue(all(record.matched_depth_comparison == poly.MATCHED_DEPTH_NOT_RUN_INVALID for record in records))
        self.assertTrue(all(record.copied_trace_invalid for record in records))


class TestClassificationAndBoundarySafety(unittest.TestCase):
    def test_classify_wfc_status_maps_expected_tokens(self) -> None:
        self.assertEqual(cert.classify_wfc_status(wfc.WFC_UNDEFINED_STRICT_EMPTY), poly.CERT_TUBE_HOLD)
        self.assertEqual(cert.classify_wfc_status(wfc.WFC_NOT_APPLICABLE), poly.CERT_ACCEPT)
        self.assertEqual(cert.classify_wfc_status(wfc.WFC_VALUE_PRESERVATION_FAIL), poly.CERT_REJECT)
        self.assertEqual(cert.classify_wfc_status("NOT_A_WFC_STATUS"), poly.CERT_REJECT)

    def test_btns_certified_source_uses_no_forbidden_imports_or_calls(self) -> None:
        source = inspect.getsource(cert)
        tree = ast.parse(source)

        forbidden_import_roots = {
            "decimal",
            "fractions",
            "numpy",
            "sympy",
            "openpyxl",
            "pandas",
            "xlrd",
            "pyxlsb",
            "egress",
            "gold_reference",
            "reporting",
        }
        forbidden_calls = {
            "Decimal",
            "Fraction",
            "eval",
            "exec",
            "to_decimal",
            "as_decimal",
            "btns_to_decimal_string_for_report",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                root = module.split(".")[0]
                self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)


if __name__ == "__main__":
    unittest.main(verbosity=2)
