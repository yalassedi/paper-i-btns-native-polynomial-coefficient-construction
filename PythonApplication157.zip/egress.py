"""
egress.py

Egress/reporting boundary module for PythonApplication157 under Script
Contract v28.

This module converts BTNS outputs into human-readable and machine-readable
reporting strings only. It must never feed decimal strings, report rows, or
interval strings back into btns_core.py, btns_poly.py, btns_certified.py, or any
coefficient-producing computation.

Allowed here by contract:
    - deterministic BTNS digit strings for reports;
    - deterministic decimal strings for human-readable reports;
    - exact rational report strings over powers of 3;
    - interval strings derived from BTNSNumber.tail_bound;
    - dictionary rows for CSV/JSON/workbook reporting.

Forbidden here by design:
    - no coefficient construction;
    - no WFC candidate selection;
    - no Certified decision making;
    - no ingress parsing;
    - no Excel workbook reading;
    - no gold-reference calls.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Optional, Sequence, Tuple

from btns_core import (
    BTNSNumber,
    TailBound,
    digit_string_kmax_to_kmin,
    validate_digits,
)


RADIX = 3
DEFAULT_REPORT_DECIMAL_DIGITS = 18


@dataclass(frozen=True)
class RationalPower3:
    """Exact rational value represented as numerator / 3**den_power3."""

    numerator: int
    den_power3: int

    def __post_init__(self) -> None:
        if not isinstance(self.numerator, int):
            raise TypeError("numerator must be int")
        if not isinstance(self.den_power3, int):
            raise TypeError("den_power3 must be int")
        if self.den_power3 < 0:
            raise ValueError("den_power3 must be non-negative")

    def as_dict(self) -> dict[str, int]:
        return {"numerator": self.numerator, "den_power3": self.den_power3}


@dataclass(frozen=True)
class DecimalIntervalStrings:
    """Human-readable decimal interval strings for reporting only."""

    lower: str
    center: str
    upper: str
    digits: int

    def as_dict(self) -> dict[str, object]:
        return {
            "decimal_lower": self.lower,
            "decimal_center": self.center,
            "decimal_upper": self.upper,
            "decimal_digits": self.digits,
        }


@dataclass(frozen=True)
class EgressRow:
    """Machine-readable row for CSV/JSON/workbook reporting."""

    coefficient_index: int
    trace_id: str
    k_min: int
    k_max: int
    digit_string: str
    exact_rational: str
    decimal_center: str
    decimal_lower: str
    decimal_upper: str
    tail_abs_bound_num: int
    tail_abs_bound_den_power3: int
    canonicality_flag: str
    source_tag: str
    wfc_trace_id: str
    wfc_status: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "trace_id": self.trace_id,
            "k_min": self.k_min,
            "k_max": self.k_max,
            "digit_string": self.digit_string,
            "exact_rational": self.exact_rational,
            "decimal_center": self.decimal_center,
            "decimal_lower": self.decimal_lower,
            "decimal_upper": self.decimal_upper,
            "tail_abs_bound_num": self.tail_abs_bound_num,
            "tail_abs_bound_den_power3": self.tail_abs_bound_den_power3,
            "canonicality_flag": self.canonicality_flag,
            "source_tag": self.source_tag,
            "wfc_trace_id": self.wfc_trace_id,
            "wfc_status": self.wfc_status,
        }


def _pow3(exp: int) -> int:
    if exp < 0:
        raise ValueError("power exponent must be non-negative")
    return RADIX ** exp


def _require_digits(digits: int) -> int:
    if not isinstance(digits, int):
        raise TypeError("digits must be int")
    if digits < 0:
        raise ValueError("digits must be non-negative")
    return digits


def _require_btns(x: BTNSNumber) -> BTNSNumber:
    if not isinstance(x, BTNSNumber) or not validate_digits(x):
        raise ValueError("egress requires a legal BTNSNumber")
    return x


def _align_power3(value: RationalPower3, common_den_power3: int) -> int:
    if common_den_power3 < value.den_power3:
        raise ValueError("common denominator power must be >= value.den_power3")
    return value.numerator * _pow3(common_den_power3 - value.den_power3)


def _tail_abs_rational(tail: Optional[TailBound]) -> RationalPower3:
    if tail is None or tail.abs_bound_num == 0:
        return RationalPower3(0, 0)
    return RationalPower3(tail.abs_bound_num, tail.abs_bound_den_power3)


def finite_value_as_power3_rational(x: BTNSNumber) -> RationalPower3:
    """Return the finite digit-center value as numerator / 3**den_power3."""

    obj = _require_btns(x)
    den_power3 = -obj.k_min if obj.k_min < 0 else 0
    numerator = 0
    for exponent, digit in obj.digits.items():
        numerator += int(digit) * _pow3(exponent + den_power3)
    return RationalPower3(numerator, den_power3)


def interval_as_power3_rationals(x: BTNSNumber) -> tuple[RationalPower3, RationalPower3, RationalPower3]:
    """Return lower, center, upper rational bounds for reporting.

    The center is the finite digit value. The lower/upper bounds include the
    absolute TailBound if present. No construction decision should use this.
    """

    obj = _require_btns(x)
    center = finite_value_as_power3_rational(obj)
    tail = _tail_abs_rational(obj.tail_bound)
    common = center.den_power3 if center.den_power3 >= tail.den_power3 else tail.den_power3
    center_num = _align_power3(center, common)
    tail_num = _align_power3(tail, common)
    return (
        RationalPower3(center_num - tail_num, common),
        RationalPower3(center_num, common),
        RationalPower3(center_num + tail_num, common),
    )


def _format_scaled_rational_truncated(value: RationalPower3, digits: int) -> str:
    places = _require_digits(digits)
    denominator = _pow3(value.den_power3)
    num = value.numerator
    sign = "-" if num < 0 else ""
    abs_num = -num if num < 0 else num
    integer_part, remainder = divmod(abs_num, denominator)
    if places == 0:
        return f"{sign}{integer_part}"
    out_digits = []
    for _ in range(places):
        remainder *= 10
        digit, remainder = divmod(remainder, denominator)
        out_digits.append(str(digit))
    return f"{sign}{integer_part}." + "".join(out_digits)


def _format_scaled_rational_rounded(value: RationalPower3, digits: int) -> str:
    """Round to nearest decimal place with ties toward zero for reporting."""

    places = _require_digits(digits)
    denominator = _pow3(value.den_power3)
    scale10 = 10 ** places
    num = value.numerator
    sign = -1 if num < 0 else 1
    abs_num = -num if num < 0 else num
    scaled_floor, remainder = divmod(abs_num * scale10, denominator)
    twice = remainder * 2
    if twice > denominator:
        scaled = scaled_floor + 1
    else:
        # ties and below-half both go toward zero; deterministic and conservative.
        scaled = scaled_floor
    if places == 0:
        return str(sign * scaled)
    integer_part, frac_part = divmod(scaled, scale10)
    prefix = "-" if sign < 0 and scaled != 0 else ""
    return f"{prefix}{integer_part}.{frac_part:0{places}d}"


def power3_rational_to_decimal_string_for_report(
    value: RationalPower3,
    digits: int = DEFAULT_REPORT_DECIMAL_DIGITS,
    *,
    rounding: str = "TRUNCATE",
) -> str:
    """Convert numerator / 3**den_power3 to a report decimal string.

    This function is egress-only. The returned decimal string must never be used
    as an arithmetic input to BTNS construction modules.
    """

    if not isinstance(value, RationalPower3):
        raise TypeError("value must be RationalPower3")
    if rounding == "TRUNCATE":
        return _format_scaled_rational_truncated(value, digits)
    if rounding == "ROUND_NEAREST_TIES_TO_ZERO":
        return _format_scaled_rational_rounded(value, digits)
    raise ValueError("rounding must be TRUNCATE or ROUND_NEAREST_TIES_TO_ZERO")


def btns_to_decimal_string_for_report(
    x: BTNSNumber,
    digits: int,
) -> str:
    """Mandatory v28 egress function.

    Returns the finite digit-center value as a deterministic truncated decimal
    string with exactly ``digits`` digits after the decimal point. Tail bounds,
    if present, are reported separately through interval functions.
    """

    return power3_rational_to_decimal_string_for_report(
        finite_value_as_power3_rational(_require_btns(x)),
        digits=digits,
        rounding="TRUNCATE",
    )


def btns_to_decimal_interval_strings_for_report(
    x: BTNSNumber,
    digits: int = DEFAULT_REPORT_DECIMAL_DIGITS,
) -> DecimalIntervalStrings:
    """Return lower/center/upper decimal strings including TailBound."""

    lower, center, upper = interval_as_power3_rationals(_require_btns(x))
    return DecimalIntervalStrings(
        lower=power3_rational_to_decimal_string_for_report(lower, digits),
        center=power3_rational_to_decimal_string_for_report(center, digits),
        upper=power3_rational_to_decimal_string_for_report(upper, digits),
        digits=digits,
    )


def btns_to_exact_rational_string_for_report(x: BTNSNumber) -> str:
    """Return an exact finite-center rational string over a power of 3."""

    rational = finite_value_as_power3_rational(_require_btns(x))
    if rational.den_power3 == 0:
        return str(rational.numerator)
    return f"{rational.numerator}/3^{rational.den_power3}"


def btns_to_report_dict(x: BTNSNumber, *, coefficient_index: int, digits: int = DEFAULT_REPORT_DECIMAL_DIGITS) -> dict[str, object]:
    """Return a dictionary row suitable for JSON/CSV/workbook reporting."""

    obj = _require_btns(x)
    interval = btns_to_decimal_interval_strings_for_report(obj, digits=digits)
    tail = obj.tail_bound
    row = EgressRow(
        coefficient_index=coefficient_index,
        trace_id=obj.trace_id or "NO_TRACE",
        k_min=obj.k_min,
        k_max=obj.k_max,
        digit_string=digit_string_kmax_to_kmin(obj),
        exact_rational=btns_to_exact_rational_string_for_report(obj),
        decimal_center=interval.center,
        decimal_lower=interval.lower,
        decimal_upper=interval.upper,
        tail_abs_bound_num=0 if tail is None else tail.abs_bound_num,
        tail_abs_bound_den_power3=0 if tail is None else tail.abs_bound_den_power3,
        canonicality_flag=obj.canonicality_flag,
        source_tag=obj.source_tag,
        wfc_trace_id=obj.wfc_trace_id or "",
        wfc_status=obj.wfc_status or "",
    )
    return row.as_dict()


def coefficients_to_report_rows(
    coefficients: Sequence[BTNSNumber],
    *,
    digits: int = DEFAULT_REPORT_DECIMAL_DIGITS,
) -> tuple[dict[str, object], ...]:
    """Return report rows for a coefficient sequence."""

    rows = []
    for idx, coefficient in enumerate(coefficients):
        rows.append(btns_to_report_dict(coefficient, coefficient_index=idx, digits=digits))
    return tuple(rows)


def coefficient_digit_strings_for_report(coefficients: Sequence[BTNSNumber]) -> tuple[str, ...]:
    """Return digit strings only; convenient for lightweight reports."""

    return tuple(digit_string_kmax_to_kmin(_require_btns(coefficient)) for coefficient in coefficients)


__all__ = [
    "DEFAULT_REPORT_DECIMAL_DIGITS",
    "RationalPower3",
    "DecimalIntervalStrings",
    "EgressRow",
    "finite_value_as_power3_rational",
    "interval_as_power3_rationals",
    "power3_rational_to_decimal_string_for_report",
    "btns_to_decimal_string_for_report",
    "btns_to_decimal_interval_strings_for_report",
    "btns_to_exact_rational_string_for_report",
    "btns_to_report_dict",
    "coefficients_to_report_rows",
    "coefficient_digit_strings_for_report",
]


if __name__ == "__main__":
    from btns_core import TAIL_REFINEMENT, SOURCE_CERTIFIED, make_btns_number_from_digits

    one = make_btns_number_from_digits({0: 1}, 0, 0, trace_id="egress_one")
    third = make_btns_number_from_digits({-1: 1}, -1, 0, trace_id="egress_third")
    assert btns_to_decimal_string_for_report(one, 6) == "1.000000"
    assert btns_to_decimal_string_for_report(third, 6).startswith("0.333333")

    tail = TailBound(
        lower_exp=-1,
        abs_bound_num=1,
        abs_bound_den_power3=1,
        policy=TAIL_REFINEMENT,
        source=SOURCE_CERTIFIED,
    )
    uncertain = BTNSNumber(
        digits={0: 1},
        k_min=0,
        k_max=0,
        tail_bound=tail,
        canonicality_flag="LEGAL",
        source_tag=SOURCE_CERTIFIED,
        trace_id="uncertain",
    )
    interval = btns_to_decimal_interval_strings_for_report(uncertain, 3)
    assert interval.lower == "0.666"
    assert interval.center == "1.000"
    assert interval.upper == "1.333"
    print("egress.py self-check PASS")
