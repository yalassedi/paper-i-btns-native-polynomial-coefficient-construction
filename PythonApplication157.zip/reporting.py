"""
Reporting and sidecar-table layer for PythonApplication157-or-later under Script Contract v28.

This module is a reporting boundary, not a construction module.  It converts
already constructed BTNS/WFC/Certified/Ablation objects into machine-readable
CSV/JSON/workbook-ready tables.  It must not build polynomial coefficients,
select WFC candidates, request Certified construction decisions, perform ingress
projection, or compute external gold references.

Allowed here by contract:
    - collect dataclass/as_dict() records emitted by validated modules;
    - convert BTNSNumber coefficients through egress.py for report rows only;
    - write CSV and JSON sidecars;
    - assemble workbook-ready sheet dictionaries.

Forbidden here by design:
    - no BTNS coefficient construction;
    - no WFC candidate selection;
    - no Certified construction decisions;
    - no ingress root projection;
    - no external-gold polynomial construction;
    - no Excel workbook reading/writing;
    - no Decimal/Fraction/NumPy/SymPy computation.
"""

from __future__ import annotations

from dataclasses import dataclass
import csv
import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple

from btns_core import BTNSNumber, digit_string_kmax_to_kmin, validate_digits
from btns_poly import PolynomialResult, CertifiedPolynomialResult, MatchedDepthPolynomialResult
from btns_wfc import WFCSelectionResult
from egress import btns_to_report_dict, coefficients_to_report_rows


REPORTING_CONTRACT_VERSION = "v28"
REPORTING_PACKAGE_NAME = "PythonApplication157"
REPORTING_REFERENCE_LABEL = "PythonApplication_BTNS_Native_v28_FULL_STRICT_WFC_MATCHED_DEPTH"

# Workbook-ready sheet names.  These match the v28 execution plan ordering.
SHEET_RUN_CONFIG = "01_RunConfig"
SHEET_INPUT_ROOTS = "02_InputRoots"
SHEET_ROOT_INGRESS_BTNS = "03_RootIngressBTNS"
SHEET_ARITHMETIC_SELF_TESTS = "04_ArithmeticSelfTests"
SHEET_ADDITION_TESTS = "05_AdditionTests"
SHEET_MULTIPLICATION_TESTS = "06_MultiplicationTests"
SHEET_POLYNOMIAL_EXPANSION_TRACE = "07_PolynomialExpansionTrace"
SHEET_NONCERTIFIED_COEFFICIENTS = "08_NonCertifiedCoefficients"
SHEET_CERTIFIED_COEFFICIENTS = "09_CertifiedCoefficients"
SHEET_GOLD_COMPARISON = "10_GoldComparison"
SHEET_GROUP_SUMMARY = "11_GroupSummary"
SHEET_ERROR_RANKING = "12_ErrorRanking"
SHEET_UCC_DECISION_SUMMARY = "13_UCCDecisionSummary"
SHEET_TRACE_AUDIT = "14_TraceAudit"
SHEET_FORBIDDEN_ARITHMETIC_AUDIT = "15_ForbiddenArithmeticAudit"
SHEET_MANIFEST = "16_Manifest"
SHEET_SETTINGS_SIGNATURE = "17_SettingsSignature"
SHEET_EXCEL_COMPLETENESS_CHECK = "18_ExcelCompletenessCheck"
SHEET_GOLD_COEFFICIENTS = "19_GoldCoefficients"
SHEET_NONCERTIFIED_ERROR = "20_NonCertifiedError"
SHEET_CERTIFIED_ERROR = "21_CertifiedError"
SHEET_INPUT_ROOTS_ALL = "22_InputRootsAll"
SHEET_INPUT_ROOTS_SELECTED = "23_InputRootsSelected"
SHEET_CAMPAIGN_SUMMARY = "24_CampaignSummary"
SHEET_METHOD_NOTES = "25_MethodNotes"
SHEET_CERTIFIED_PATH_COMPARISON = "26_CertifiedPathComparison"
SHEET_CERTIFIED_DECISION_CHAIN = "27_CertifiedDecisionChain"
SHEET_CERTIFIED_REFINEMENT_TRACE = "28_CertifiedRefinementTrace"
SHEET_CERTIFIED_CANDIDATE_SELECTION = "29_CertifiedCandidateSelection"
SHEET_WFC_CONFIG = "30_WFCConfig"
SHEET_WFC_OPERATION_TRACE = "31_WFCOperationTrace"
SHEET_WFC_CANDIDATE_FAMILY = "32_WFCCandidateFamily"
SHEET_WFC_STRICT_ADMISSIBILITY = "33_WFCStrictAdmissibility"
SHEET_WFC_TIE_POLICY_SELECTION = "34_WFCTiePolicySelection"
SHEET_WFC_UNDEFINED_CASES = "35_WFCUndefinedCases"
SHEET_WFC_ABLATION_CONFIG = "36_WFCAblationConfig"
SHEET_WFC_ABLATION_SUMMARY = "37_WFCAblationSummary"
SHEET_WFC_WINDOW_SENSITIVITY = "38_WFCWindowSensitivity"
SHEET_WFC_TIE_POLICY_ABLATION = "39_WFCTiePolicyAblation"
SHEET_MATCHED_DEPTH_FAIRNESS = "40_MatchedDepthFairness"
SHEET_ADAPTIVE_ADVANTAGE_CLASSIFICATION = "41_AdaptiveAdvantageClassification"
SHEET_WFC_AND_UCC_CROSS_SUMMARY = "42_WFCAndUCCCrossSummary"

DEFAULT_SHEET_ORDER = (
    SHEET_RUN_CONFIG,
    SHEET_INPUT_ROOTS,
    SHEET_ROOT_INGRESS_BTNS,
    SHEET_ARITHMETIC_SELF_TESTS,
    SHEET_ADDITION_TESTS,
    SHEET_MULTIPLICATION_TESTS,
    SHEET_POLYNOMIAL_EXPANSION_TRACE,
    SHEET_NONCERTIFIED_COEFFICIENTS,
    SHEET_CERTIFIED_COEFFICIENTS,
    SHEET_GOLD_COMPARISON,
    SHEET_GROUP_SUMMARY,
    SHEET_ERROR_RANKING,
    SHEET_UCC_DECISION_SUMMARY,
    SHEET_TRACE_AUDIT,
    SHEET_FORBIDDEN_ARITHMETIC_AUDIT,
    SHEET_MANIFEST,
    SHEET_SETTINGS_SIGNATURE,
    SHEET_EXCEL_COMPLETENESS_CHECK,
    SHEET_GOLD_COEFFICIENTS,
    SHEET_NONCERTIFIED_ERROR,
    SHEET_CERTIFIED_ERROR,
    SHEET_INPUT_ROOTS_ALL,
    SHEET_INPUT_ROOTS_SELECTED,
    SHEET_CAMPAIGN_SUMMARY,
    SHEET_METHOD_NOTES,
    SHEET_CERTIFIED_PATH_COMPARISON,
    SHEET_CERTIFIED_DECISION_CHAIN,
    SHEET_CERTIFIED_REFINEMENT_TRACE,
    SHEET_CERTIFIED_CANDIDATE_SELECTION,
    SHEET_WFC_CONFIG,
    SHEET_WFC_OPERATION_TRACE,
    SHEET_WFC_CANDIDATE_FAMILY,
    SHEET_WFC_STRICT_ADMISSIBILITY,
    SHEET_WFC_TIE_POLICY_SELECTION,
    SHEET_WFC_UNDEFINED_CASES,
    SHEET_WFC_ABLATION_CONFIG,
    SHEET_WFC_ABLATION_SUMMARY,
    SHEET_WFC_WINDOW_SENSITIVITY,
    SHEET_WFC_TIE_POLICY_ABLATION,
    SHEET_MATCHED_DEPTH_FAIRNESS,
    SHEET_ADAPTIVE_ADVANTAGE_CLASSIFICATION,
    SHEET_WFC_AND_UCC_CROSS_SUMMARY,
 )


# Header schemas for zero-row evidence tables.  These keep workbook-ready
# CSVs and workbook sheets auditable even when a run has no violations, no
# undefined WFC cases, or no adaptive refinement events.
TABLE_COLUMN_SCHEMAS: dict[str, Tuple[str, ...]] = {
    SHEET_ARITHMETIC_SELF_TESTS: ("test_id", "test_name", "status", "expected", "observed", "notes"),
    SHEET_ADDITION_TESTS: ("test_id", "test_name", "status", "lhs", "rhs", "expected", "observed", "notes"),
    SHEET_MULTIPLICATION_TESTS: ("test_id", "test_name", "status", "lhs", "rhs", "expected", "observed", "notes"),
    SHEET_FORBIDDEN_ARITHMETIC_AUDIT: ("code", "module", "message", "severity", "lineno"),
    SHEET_CERTIFIED_REFINEMENT_TRACE: (
        "group_id", "k_min_case", "certified_path_id", "certified_stage_id",
        "refinement_depth_requested", "refinement_reason", "status",
    ),
    SHEET_WFC_UNDEFINED_CASES: (
        "group_id", "k_min_case", "wfc_trace_id", "operation_id",
        "input_trace_id", "output_trace_id", "window_width", "policy",
        "candidate_count", "strict_candidate_count", "selected_candidate_id",
        "selected_c_in", "q0_selected", "wfc_status",
        "wfc_boundary_mode", "wfc_not_applicable_reason",
    ),
}


@dataclass(frozen=True)
class ReportingTable:
    """One workbook/CSV-ready table."""

    name: str
    rows: Tuple[Mapping[str, Any], ...]

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("table name must be a non-empty string")
        for row in self.rows:
            if not isinstance(row, Mapping):
                raise TypeError("ReportingTable rows must be mappings")

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def columns(self) -> Tuple[str, ...]:
        seen: list[str] = []
        for row in self.rows:
            for key in row.keys():
                text = str(key)
                if text not in seen:
                    seen.append(text)
        if seen:
            return tuple(seen)
        return TABLE_COLUMN_SCHEMAS.get(self.name, tuple())

    def as_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "row_count": self.row_count,
            "columns": list(self.columns),
            "rows": [dict(row) for row in self.rows],
        }


@dataclass(frozen=True)
class ReportingBundle:
    """Collection of workbook-ready reporting tables."""

    tables: Tuple[ReportingTable, ...]
    contract_version: str = REPORTING_CONTRACT_VERSION
    package_name: str = REPORTING_PACKAGE_NAME
    reference_label: str = REPORTING_REFERENCE_LABEL

    def __post_init__(self) -> None:
        names = [table.name for table in self.tables]
        if len(names) != len(set(names)):
            raise ValueError("duplicate reporting table names are not allowed")

    def table_by_name(self, name: str) -> Optional[ReportingTable]:
        for table in self.tables:
            if table.name == name:
                return table
        return None

    def as_dict(self) -> dict[str, object]:
        return {
            "contract_version": self.contract_version,
            "package_name": self.package_name,
            "reference_label": self.reference_label,
            "tables": [table.as_dict() for table in self.tables],
        }


@dataclass(frozen=True)
class SidecarWriteResult:
    """Paths written by the reporting layer."""

    output_dir: str
    files: Mapping[str, str]

    def as_dict(self) -> dict[str, object]:
        return {"output_dir": self.output_dir, "files": dict(self.files)}


def _as_dict(item: Any) -> dict[str, Any]:
    if item is None:
        return {}
    if isinstance(item, Mapping):
        return dict(item)
    method = getattr(item, "as_dict", None)
    if callable(method):
        value = method()
        if not isinstance(value, Mapping):
            raise TypeError("as_dict() must return a mapping")
        return dict(value)
    raise TypeError(f"object is not reportable as dict: {type(item).__name__}")


def _as_rows(items: Optional[Iterable[Any]]) -> Tuple[dict[str, Any], ...]:
    if items is None:
        return tuple()
    return tuple(_as_dict(item) for item in items)


def _scalar_rows(mapping: Mapping[str, Any]) -> Tuple[dict[str, Any], ...]:
    return tuple({"key": str(key), "value": value} for key, value in mapping.items())


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(_json_safe(payload), indent=2, sort_keys=True), encoding="utf-8")


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    columns: list[str] = list(fieldnames or tuple())
    for row in rows:
        for key in row.keys():
            text = str(key)
            if text not in columns:
                columns.append(text)
    with path.open("w", encoding="utf-8", newline="") as handle:
        if not columns:
            handle.write("")
            return
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _json_safe(row.get(key, "")) for key in columns})


def run_config_rows(config: Any) -> Tuple[dict[str, Any], ...]:
    """Return key/value rows for a config dataclass or mapping."""

    data = _as_dict(config) if not isinstance(config, Mapping) else dict(config)
    return _scalar_rows(data)


def manifest_rows(manifest: Mapping[str, Any]) -> Tuple[dict[str, Any], ...]:
    return _scalar_rows(manifest)


def settings_signature_rows(signature: Mapping[str, Any]) -> Tuple[dict[str, Any], ...]:
    return _scalar_rows(signature)


def ingress_rows(ingress_results: Optional[Iterable[Any]]) -> Tuple[dict[str, Any], ...]:
    """Return rows from ingress.IngressResult objects."""

    rows: list[dict[str, Any]] = []
    for item in ingress_results or tuple():
        data = _as_dict(item)
        trace = data.get("trace", {})
        if isinstance(trace, Mapping):
            flat = {f"trace_{key}": value for key, value in trace.items()}
        else:
            flat = {"trace": trace}
        for key, value in data.items():
            if key != "trace":
                flat[key] = value
        rows.append(flat)
    return tuple(rows)


def coefficient_rows(result: PolynomialResult, *, digits: int = 18, path_label: Optional[str] = None) -> Tuple[dict[str, Any], ...]:
    if not isinstance(result, PolynomialResult):
        raise TypeError("result must be PolynomialResult")
    rows = []
    label = path_label or result.mode
    for row in coefficients_to_report_rows(result.coefficients, digits=digits):
        full = dict(row)
        full["path_label"] = label
        full["mode"] = result.mode
        full["m"] = result.m
        full["result_status"] = result.status
        rows.append(full)
    return tuple(rows)


def polynomial_trace_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for result in results:
        if result is None:
            continue
        if not isinstance(result, PolynomialResult):
            raise TypeError("all results must be PolynomialResult instances")
        for trace in result.traces:
            row = _as_dict(trace)
            row["result_mode"] = result.mode
            row["result_m"] = result.m
            rows.append(row)
    return tuple(rows)


def wfc_operation_trace_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for result in results:
        if result is None:
            continue
        for wfc_result in result.wfc_results:
            row = _as_dict(wfc_result.trace)
            row["result_mode"] = result.mode
            rows.append(row)
    return tuple(rows)


def wfc_candidate_family_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for result in results:
        if result is None:
            continue
        for wfc_result in result.wfc_results:
            for candidate in wfc_result.candidates:
                row = _as_dict(candidate)
                row["wfc_trace_id"] = wfc_result.trace.wfc_trace_id
                row["result_mode"] = result.mode
                rows.append(row)
    return tuple(rows)


def wfc_strict_admissibility_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for row in wfc_candidate_family_rows(*results):
        rows.append(
            {
                "wfc_trace_id": row.get("wfc_trace_id", ""),
                "candidate_id": row.get("candidate_id", ""),
                "c_in": row.get("c_in", ""),
                "q0": row.get("q0", ""),
                "legal_digit_status": row.get("legal_digit_status", ""),
                "value_preservation_status": row.get("value_preservation_status", ""),
                "support_status": row.get("support_status", ""),
                "no_leakage_status": row.get("no_leakage_status", ""),
                "strict_status": row.get("strict_status", ""),
            }
        )
    return tuple(rows)


def wfc_tie_policy_selection_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for result in results:
        if result is None:
            continue
        for wfc_result in result.wfc_results:
            trace = wfc_result.trace
            rows.append(
                {
                    "wfc_trace_id": trace.wfc_trace_id,
                    "operation_id": trace.operation_id,
                    "policy": trace.policy,
                    "strict_candidate_count": trace.strict_candidate_count,
                    "selected_candidate_id": trace.selected_candidate_id or "",
                    "selected_c_in": trace.selected_c_in,
                    "q0_selected": trace.q0_selected,
                    "wfc_status": trace.wfc_status,
                }
            )
    return tuple(rows)


def wfc_undefined_case_rows(*results: PolynomialResult) -> Tuple[dict[str, Any], ...]:
    return tuple(row for row in wfc_operation_trace_rows(*results) if row.get("wfc_status") == "WFC_UNDEFINED_STRICT_EMPTY")


def certified_decision_rows(certified_result: Optional[CertifiedPolynomialResult]) -> Tuple[dict[str, Any], ...]:
    if certified_result is None:
        return tuple()
    return _as_rows(certified_result.certified_decision_chain)


def certified_candidate_selection_rows(certified_result: Optional[CertifiedPolynomialResult]) -> Tuple[dict[str, Any], ...]:
    if certified_result is None:
        return tuple()
    return _as_rows(certified_result.candidate_selections)


def operation_certificate_rows(certified_result: Optional[CertifiedPolynomialResult]) -> Tuple[dict[str, Any], ...]:
    if certified_result is None:
        return tuple()
    return _as_rows(certified_result.operation_certificates)


def matched_depth_rows(matched_result: Optional[MatchedDepthPolynomialResult]) -> Tuple[dict[str, Any], ...]:
    if matched_result is None:
        return tuple()
    rows = _as_rows(matched_result.matched_depth_records)
    return tuple({**row, "mode": matched_result.mode, "m": matched_result.m} for row in rows)


def path_comparison_rows(records: Optional[Iterable[Any]]) -> Tuple[dict[str, Any], ...]:
    return _as_rows(records)


def gold_coefficient_rows(gold_reference: Any, *, digits: int = 30) -> Tuple[dict[str, Any], ...]:
    if gold_reference is None:
        return tuple()
    method = getattr(gold_reference, "coefficient_records", None)
    if not callable(method):
        raise TypeError("gold_reference must expose coefficient_records()")
    return _as_rows(method(digits))


def gold_comparison_rows(records: Optional[Iterable[Any]]) -> Tuple[dict[str, Any], ...]:
    return _as_rows(records)


def gold_summary_rows(summary: Any) -> Tuple[dict[str, Any], ...]:
    if summary is None:
        return tuple()
    return (_as_dict(summary),)


def audit_rows(report: Any) -> Tuple[dict[str, Any], ...]:
    if report is None:
        return tuple()
    data = _as_dict(report)
    rows = []
    for violation in data.get("violations", []) or []:
        if isinstance(violation, Mapping):
            rows.append(dict(violation))
    return tuple(rows)


def audit_module_summary_rows(report: Any) -> Tuple[dict[str, Any], ...]:
    if report is None:
        return tuple()
    data = _as_dict(report)
    rows = []
    for module in data.get("module_results", []) or []:
        if isinstance(module, Mapping):
            rows.append(
                {
                    "module": module.get("module", ""),
                    "path": module.get("path", ""),
                    "status": module.get("status", ""),
                    "violation_count": len(module.get("violations", []) or []),
                }
            )
    return tuple(rows)


def wfc_ablation_config_rows(ablation_run: Any) -> Tuple[dict[str, Any], ...]:
    if ablation_run is None:
        return tuple()
    data = _as_dict(ablation_run)
    return tuple(dict(row) for row in data.get("branch_configs", []) or [])


def wfc_ablation_summary_rows(ablation_run: Any) -> Tuple[dict[str, Any], ...]:
    if ablation_run is None:
        return tuple()
    return _as_rows(getattr(ablation_run, "summary_records", tuple()))


def wfc_window_sensitivity_rows(ablation_run: Any) -> Tuple[dict[str, Any], ...]:
    if ablation_run is None:
        return tuple()
    return (
        {
            "token": getattr(ablation_run, "window_sensitivity_token", ""),
            "reference_branch": "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW",
            "compared_branches": "A3_FULL_WFC_SMALLER_WINDOW;A4_FULL_WFC_LARGER_WINDOW",
        },
    )


def wfc_tie_policy_ablation_rows(ablation_run: Any) -> Tuple[dict[str, Any], ...]:
    if ablation_run is None:
        return tuple()
    return (
        {
            "token": getattr(ablation_run, "policy_sensitivity_token", ""),
            "rn_zero_branch": "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW",
            "rn_even_branch": "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW",
        },
    )


def wfc_and_ucc_cross_summary_rows(
    *,
    noncertified_result: Optional[PolynomialResult] = None,
    certified_result: Optional[CertifiedPolynomialResult] = None,
    matched_result: Optional[MatchedDepthPolynomialResult] = None,
    ablation_run: Any = None,
) -> Tuple[dict[str, Any], ...]:
    results = tuple(item for item in (noncertified_result, certified_result, matched_result) if item is not None)
    wfc_status_counts: dict[str, int] = {}
    for result in results:
        for wfc_result in result.wfc_results:
            status = wfc_result.trace.wfc_status
            wfc_status_counts[status] = wfc_status_counts.get(status, 0) + 1
    rows = [{"category": "WFC_STATUS", "token": key, "count": value} for key, value in sorted(wfc_status_counts.items())]
    if certified_result is not None:
        token_counts: dict[str, int] = {}
        for decision in certified_result.certified_decision_chain:
            token = decision.certified_construction_token
            token_counts[token] = token_counts.get(token, 0) + 1
        rows.extend({"category": "CERTIFIED_TOKEN", "token": key, "count": value} for key, value in sorted(token_counts.items()))
    if matched_result is not None:
        matched_counts: dict[str, int] = {}
        for record in matched_result.matched_depth_records:
            token = record.matched_depth_comparison
            matched_counts[token] = matched_counts.get(token, 0) + 1
        rows.extend({"category": "MATCHED_DEPTH", "token": key, "count": value} for key, value in sorted(matched_counts.items()))
    if ablation_run is not None:
        rows.append({"category": "WFC_ABLATION", "token": "branch_count", "count": len(getattr(ablation_run, "summary_records", tuple()))})
    return tuple(rows)


def build_workbook_ready_tables(
    *,
    run_config: Optional[Mapping[str, Any]] = None,
    input_roots_all: Optional[Iterable[Any]] = None,
    input_roots_selected: Optional[Iterable[Any]] = None,
    ingress_results: Optional[Iterable[Any]] = None,
    arithmetic_self_tests: Optional[Iterable[Any]] = None,
    addition_tests: Optional[Iterable[Any]] = None,
    multiplication_tests: Optional[Iterable[Any]] = None,
    noncertified_result: Optional[PolynomialResult] = None,
    certified_result: Optional[CertifiedPolynomialResult] = None,
    matched_result: Optional[MatchedDepthPolynomialResult] = None,
    gold_reference: Any = None,
    gold_comparisons: Optional[Iterable[Any]] = None,
    gold_summary: Any = None,
    certified_path_comparisons: Optional[Iterable[Any]] = None,
    trace_audit_report: Any = None,
    forbidden_arithmetic_audit: Any = None,
    manifest: Optional[Mapping[str, Any]] = None,
    settings_signature: Optional[Mapping[str, Any]] = None,
    excel_completeness_check: Optional[Mapping[str, Any]] = None,
    campaign_summary: Optional[Iterable[Any]] = None,
    method_notes: Optional[Iterable[Any]] = None,
    certified_refinement_trace: Optional[Iterable[Any]] = None,
    ablation_run: Any = None,
    decimal_digits: int = 18,
) -> ReportingBundle:
    """Assemble v28 workbook-ready tables from already produced evidence."""

    results_for_traces = tuple(item for item in (noncertified_result, certified_result, matched_result) if item is not None)
    tables = (
        ReportingTable(SHEET_RUN_CONFIG, run_config_rows(run_config or {})),
        ReportingTable(SHEET_INPUT_ROOTS, _as_rows(input_roots_selected)),
        ReportingTable(SHEET_ROOT_INGRESS_BTNS, ingress_rows(ingress_results)),
        ReportingTable(SHEET_ARITHMETIC_SELF_TESTS, _as_rows(arithmetic_self_tests)),
        ReportingTable(SHEET_ADDITION_TESTS, _as_rows(addition_tests)),
        ReportingTable(SHEET_MULTIPLICATION_TESTS, _as_rows(multiplication_tests)),
        ReportingTable(SHEET_POLYNOMIAL_EXPANSION_TRACE, polynomial_trace_rows(*results_for_traces)),
        ReportingTable(SHEET_NONCERTIFIED_COEFFICIENTS, coefficient_rows(noncertified_result, digits=decimal_digits) if noncertified_result is not None else tuple()),
        ReportingTable(SHEET_CERTIFIED_COEFFICIENTS, coefficient_rows(certified_result, digits=decimal_digits) if certified_result is not None else tuple()),
        ReportingTable(SHEET_GOLD_COMPARISON, gold_comparison_rows(gold_comparisons)),
        ReportingTable(SHEET_GROUP_SUMMARY, gold_summary_rows(gold_summary)),
        ReportingTable(SHEET_ERROR_RANKING, gold_comparison_rows(gold_comparisons)),
        ReportingTable(SHEET_UCC_DECISION_SUMMARY, wfc_and_ucc_cross_summary_rows(noncertified_result=noncertified_result, certified_result=certified_result, matched_result=matched_result, ablation_run=ablation_run)),
        ReportingTable(SHEET_TRACE_AUDIT, audit_module_summary_rows(trace_audit_report)),
        ReportingTable(SHEET_FORBIDDEN_ARITHMETIC_AUDIT, audit_rows(forbidden_arithmetic_audit)),
        ReportingTable(SHEET_MANIFEST, manifest_rows(manifest or {})),
        ReportingTable(SHEET_SETTINGS_SIGNATURE, settings_signature_rows(settings_signature or {})),
        ReportingTable(SHEET_EXCEL_COMPLETENESS_CHECK, _scalar_rows(excel_completeness_check or {})),
        ReportingTable(SHEET_GOLD_COEFFICIENTS, gold_coefficient_rows(gold_reference)),
        ReportingTable(SHEET_NONCERTIFIED_ERROR, gold_comparison_rows(gold_comparisons)),
        ReportingTable(SHEET_CERTIFIED_ERROR, gold_comparison_rows(gold_comparisons)),
        ReportingTable(SHEET_INPUT_ROOTS_ALL, _as_rows(input_roots_all)),
        ReportingTable(SHEET_INPUT_ROOTS_SELECTED, _as_rows(input_roots_selected)),
        ReportingTable(SHEET_CAMPAIGN_SUMMARY, _as_rows(campaign_summary)),
        ReportingTable(SHEET_METHOD_NOTES, _as_rows(method_notes)),
        ReportingTable(SHEET_CERTIFIED_PATH_COMPARISON, path_comparison_rows(certified_path_comparisons)),
        ReportingTable(SHEET_CERTIFIED_DECISION_CHAIN, certified_decision_rows(certified_result)),
        ReportingTable(SHEET_CERTIFIED_REFINEMENT_TRACE, _as_rows(certified_refinement_trace)),
        ReportingTable(SHEET_CERTIFIED_CANDIDATE_SELECTION, certified_candidate_selection_rows(certified_result)),
        ReportingTable(SHEET_WFC_CONFIG, _scalar_rows((run_config or {}).get("wfc_config", {}) if isinstance((run_config or {}).get("wfc_config", {}), Mapping) else {})),
        ReportingTable(SHEET_WFC_OPERATION_TRACE, wfc_operation_trace_rows(*results_for_traces)),
        ReportingTable(SHEET_WFC_CANDIDATE_FAMILY, wfc_candidate_family_rows(*results_for_traces)),
        ReportingTable(SHEET_WFC_STRICT_ADMISSIBILITY, wfc_strict_admissibility_rows(*results_for_traces)),
        ReportingTable(SHEET_WFC_TIE_POLICY_SELECTION, wfc_tie_policy_selection_rows(*results_for_traces)),
        ReportingTable(SHEET_WFC_UNDEFINED_CASES, wfc_undefined_case_rows(*results_for_traces)),
        ReportingTable(SHEET_WFC_ABLATION_CONFIG, wfc_ablation_config_rows(ablation_run)),
        ReportingTable(SHEET_WFC_ABLATION_SUMMARY, wfc_ablation_summary_rows(ablation_run)),
        ReportingTable(SHEET_WFC_WINDOW_SENSITIVITY, wfc_window_sensitivity_rows(ablation_run)),
        ReportingTable(SHEET_WFC_TIE_POLICY_ABLATION, wfc_tie_policy_ablation_rows(ablation_run)),
        ReportingTable(SHEET_MATCHED_DEPTH_FAIRNESS, matched_depth_rows(matched_result)),
        ReportingTable(SHEET_ADAPTIVE_ADVANTAGE_CLASSIFICATION, wfc_ablation_summary_rows(ablation_run)),
        ReportingTable(SHEET_WFC_AND_UCC_CROSS_SUMMARY, wfc_and_ucc_cross_summary_rows(noncertified_result=noncertified_result, certified_result=certified_result, matched_result=matched_result, ablation_run=ablation_run)),
    )
    return ReportingBundle(tables=tables)


def write_table_csv(table: ReportingTable, output_dir: str | Path) -> str:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{table.name}.csv"
    _write_csv(path, table.rows, table.columns)
    return str(path)


def write_reporting_bundle_sidecars(bundle: ReportingBundle, output_dir: str | Path) -> SidecarWriteResult:
    """Write one CSV per table plus a reporting_bundle_manifest.json file."""

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {}
    for table in bundle.tables:
        files[f"{table.name}.csv"] = write_table_csv(table, out)
    manifest_path = out / "reporting_bundle_manifest.json"
    _write_json(manifest_path, bundle.as_dict())
    files[manifest_path.name] = str(manifest_path)
    return SidecarWriteResult(output_dir=str(out), files=files)


def write_selected_sidecars(tables: Sequence[ReportingTable], output_dir: str | Path) -> SidecarWriteResult:
    """Write selected tables as CSV sidecars."""

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {}
    for table in tables:
        files[f"{table.name}.csv"] = write_table_csv(table, out)
    return SidecarWriteResult(output_dir=str(out), files=files)


def workbook_payload(bundle: ReportingBundle) -> dict[str, list[dict[str, Any]]]:
    """Return a sheet-name -> rows mapping for a later workbook writer."""

    return {table.name: [dict(row) for row in table.rows] for table in bundle.tables}


def validate_required_sheet_names(bundle: ReportingBundle, required: Sequence[str] = DEFAULT_SHEET_ORDER) -> tuple[str, ...]:
    present = {table.name for table in bundle.tables}
    return tuple(name for name in required if name not in present)


__all__ = [
    "REPORTING_CONTRACT_VERSION",
    "REPORTING_PACKAGE_NAME",
    "REPORTING_REFERENCE_LABEL",
    "DEFAULT_SHEET_ORDER",
    "TABLE_COLUMN_SCHEMAS",
    "ReportingTable",
    "ReportingBundle",
    "SidecarWriteResult",
    "run_config_rows",
    "manifest_rows",
    "settings_signature_rows",
    "ingress_rows",
    "coefficient_rows",
    "polynomial_trace_rows",
    "wfc_operation_trace_rows",
    "wfc_candidate_family_rows",
    "wfc_strict_admissibility_rows",
    "wfc_tie_policy_selection_rows",
    "wfc_undefined_case_rows",
    "certified_decision_rows",
    "certified_candidate_selection_rows",
    "operation_certificate_rows",
    "matched_depth_rows",
    "path_comparison_rows",
    "gold_coefficient_rows",
    "gold_comparison_rows",
    "gold_summary_rows",
    "audit_rows",
    "audit_module_summary_rows",
    "wfc_ablation_config_rows",
    "wfc_ablation_summary_rows",
    "wfc_window_sensitivity_rows",
    "wfc_tie_policy_ablation_rows",
    "wfc_and_ucc_cross_summary_rows",
    "build_workbook_ready_tables",
    "write_table_csv",
    "write_reporting_bundle_sidecars",
    "write_selected_sidecars",
    "workbook_payload",
    "validate_required_sheet_names",
]


if __name__ == "__main__":
    from btns_core import SOURCE_TEST, add_btns, make_btns_number_from_digits
    from btns_poly import CampaignConfig, build_quadratic_coeffs_certified_independent, build_quadratic_coeffs_noncertified, build_quadratic_coeffs_noncertified_matched_depth
    from btns_wfc import RN_ZERO
    from gold_reference import build_gold_quadratic_from_root_strings, compare_coefficients_to_gold, summarize_gold_comparisons

    cfg = CampaignConfig(k_min=0, k_max=0, trace_prefix="REPORT_SELFTEST", wfc_window_width=0, wfc_policy=RN_ZERO)
    r1 = make_btns_number_from_digits({0: 1}, 0, 0, source_tag=SOURCE_TEST, trace_id="r1")
    r2 = add_btns(r1, r1)
    noncert = build_quadratic_coeffs_noncertified(r1, r2, cfg)
    cert = build_quadratic_coeffs_certified_independent(r1, r2, cfg)
    matched = build_quadratic_coeffs_noncertified_matched_depth(r1, r2, cfg.k_min, cfg, cert)
    gold_ref = build_gold_quadratic_from_root_strings("1", "2")
    comparisons = compare_coefficients_to_gold(noncert.coefficients, gold_ref.coefficients)
    summary = summarize_gold_comparisons(comparisons)
    bundle = build_workbook_ready_tables(
        run_config={"contract_version": "v28", "wfc_config": {"policy": "RN_ZERO", "window_width": 0}},
        noncertified_result=noncert,
        certified_result=cert,
        matched_result=matched,
        gold_reference=gold_ref,
        gold_comparisons=comparisons,
        gold_summary=summary,
        manifest={"reference_label": REPORTING_REFERENCE_LABEL},
        settings_signature={"m": 2},
    )
    assert validate_required_sheet_names(bundle) == tuple()
    assert bundle.table_by_name(SHEET_NONCERTIFIED_COEFFICIENTS).row_count == 3  # type: ignore[union-attr]
    assert bundle.table_by_name(SHEET_WFC_OPERATION_TRACE).row_count > 0  # type: ignore[union-attr]
    print("reporting.py self-check PASS")
