"""
audit.py

Static and lightweight semantic audit layer for PythonApplication157 under
Script Contract v28.

Purpose
-------
This module verifies that the BTNS-native m=2 implementation preserves the
construction boundary and the v28 WFC discipline:
    - full strict WFC exists and is not bypassed by canonize_btns();
    - construction modules do not import/report through gold, egress, Excel,
      Decimal, Fraction, NumPy, SymPy, or workbook tooling;
    - matched-depth recomputation is implemented and is not a copied Certified
      result;
    - gold_reference.py remains evaluation-only;
    - ingress.py and egress.py remain clean boundary modules.

The audit is intentionally static-first. It parses Python source with ast and
reports deterministic violation records. It does not execute construction,
read Excel, call gold selection, or generate manuscript evidence.
"""

from __future__ import annotations

from dataclasses import dataclass
import ast
from pathlib import Path
from typing import Iterable, Mapping, Optional, Sequence, Tuple


# ----------------------------
# Violation codes from v28 plan
# ----------------------------

WFC_OPERATOR_MISSING = "WFC_OPERATOR_MISSING"
WFC_CANDIDATE_ENUMERATION_MISSING = "WFC_CANDIDATE_ENUMERATION_MISSING"
WFC_STRICT_FILTER_MISSING = "WFC_STRICT_FILTER_MISSING"
WFC_NO_LEAKAGE_CHECK_MISSING = "WFC_NO_LEAKAGE_CHECK_MISSING"
WFC_VALUE_PRESERVATION_CHECK_MISSING = "WFC_VALUE_PRESERVATION_CHECK_MISSING"
WFC_POLICY_SELECTION_MISSING = "WFC_POLICY_SELECTION_MISSING"
WFC_TRACE_MISSING = "WFC_TRACE_MISSING"
WFC_BYPASS_DETECTED = "WFC_BYPASS_DETECTED"
CANONIZE_ONLY_REPORTED_AS_FULL_WFC = "CANONIZE_ONLY_REPORTED_AS_FULL_WFC"
MATCHED_DEPTH_NOT_IMPLEMENTED = "MATCHED_DEPTH_NOT_IMPLEMENTED"
MATCHED_DEPTH_COPIES_CERTIFIED_OUTPUT = "MATCHED_DEPTH_COPIES_CERTIFIED_OUTPUT"
WFC_ABLATION_NOT_GENERATED = "WFC_ABLATION_NOT_GENERATED"

# Additional deterministic audit codes.
FILE_MISSING = "FILE_MISSING"
PYTHON_PARSE_ERROR = "PYTHON_PARSE_ERROR"
REQUIRED_FUNCTION_MISSING = "REQUIRED_FUNCTION_MISSING"
REQUIRED_CLASS_MISSING = "REQUIRED_CLASS_MISSING"
FORBIDDEN_IMPORT_DETECTED = "FORBIDDEN_IMPORT_DETECTED"
FORBIDDEN_CALL_DETECTED = "FORBIDDEN_CALL_DETECTED"
FORBIDDEN_TEXT_DETECTED = "FORBIDDEN_TEXT_DETECTED"
INGRESS_POLICY_VIOLATION = "INGRESS_POLICY_VIOLATION"
EGRESS_POLICY_VIOLATION = "EGRESS_POLICY_VIOLATION"
GOLD_LEAKAGE_DETECTED = "GOLD_LEAKAGE_DETECTED"
CERTIFIED_POLICY_VIOLATION = "CERTIFIED_POLICY_VIOLATION"
TRACE_SCHEMA_WEAK = "TRACE_SCHEMA_WEAK"
RUNNER_REQUIRED_LATER = "RUNNER_REQUIRED_LATER"

STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_WARN = "WARN"

STAGE_CORE_STACK = "CORE_STACK"
STAGE_FINAL_PACKAGE = "FINAL_PACKAGE"
_ALLOWED_STAGES = {STAGE_CORE_STACK, STAGE_FINAL_PACKAGE}


@dataclass(frozen=True)
class AuditViolation:
    code: str
    module: str
    message: str
    severity: str = STATUS_FAIL
    lineno: Optional[int] = None

    def as_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "module": self.module,
            "message": self.message,
            "severity": self.severity,
            "lineno": self.lineno,
        }


@dataclass(frozen=True)
class ModuleAuditResult:
    module: str
    path: str
    status: str
    violations: Tuple[AuditViolation, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "module": self.module,
            "path": self.path,
            "status": self.status,
            "violations": [item.as_dict() for item in self.violations],
        }


@dataclass(frozen=True)
class AuditReport:
    root: str
    stage: str
    status: str
    module_results: Tuple[ModuleAuditResult, ...]
    violations: Tuple[AuditViolation, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "root": self.root,
            "stage": self.stage,
            "status": self.status,
            "module_results": [item.as_dict() for item in self.module_results],
            "violations": [item.as_dict() for item in self.violations],
            "violation_count": len(self.violations),
            "fail_count": sum(1 for item in self.violations if item.severity == STATUS_FAIL),
            "warn_count": sum(1 for item in self.violations if item.severity == STATUS_WARN),
        }


@dataclass(frozen=True)
class _ParsedModule:
    name: str
    path: Path
    source: str
    tree: ast.AST


# ----------------------------
# AST helpers
# ----------------------------


def _violation(code: str, module: str, message: str, severity: str = STATUS_FAIL, lineno: Optional[int] = None) -> AuditViolation:
    return AuditViolation(code=code, module=module, message=message, severity=severity, lineno=lineno)


def _read_parse(root: Path, module_filename: str) -> tuple[Optional[_ParsedModule], Tuple[AuditViolation, ...]]:
    path = root / module_filename
    module_name = path.stem
    if not path.exists():
        return None, (_violation(FILE_MISSING, module_filename, f"required file is missing: {module_filename}"),)
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        source = path.read_text(encoding="utf-8-sig")
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        return None, (_violation(PYTHON_PARSE_ERROR, module_filename, str(exc), lineno=exc.lineno),)
    return _ParsedModule(module_name, path, source, tree), tuple()


def _top_level_names(tree: ast.AST) -> set[str]:
    names: set[str] = set()
    for node in getattr(tree, "body", []):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


def _function_node(tree: ast.AST, name: str) -> Optional[ast.FunctionDef]:
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _called_names(tree: ast.AST) -> set[str]:
    calls: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name):
                calls.add(func.id)
            elif isinstance(func, ast.Attribute):
                calls.add(func.attr)
    return calls


def _imports(tree: ast.AST) -> set[str]:
    roots: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                roots.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            roots.add(module.split(".")[0] if module else "")
    return {item for item in roots if item}


def _import_details(tree: ast.AST) -> list[tuple[str, int]]:
    rows: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                rows.append((alias.name.split(".")[0], getattr(node, "lineno", 0)))
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            rows.append((module.split(".")[0] if module else "", getattr(node, "lineno", 0)))
    return rows


def _call_details(tree: ast.AST) -> list[tuple[str, int]]:
    rows: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name):
                rows.append((func.id, getattr(node, "lineno", 0)))
            elif isinstance(func, ast.Attribute):
                rows.append((func.attr, getattr(node, "lineno", 0)))
    return rows


def _require_names(module: _ParsedModule, required: Mapping[str, str]) -> list[AuditViolation]:
    names = _top_level_names(module.tree)
    violations: list[AuditViolation] = []
    for name, code in required.items():
        if name not in names:
            klass = REQUIRED_CLASS_MISSING if code == "class" else REQUIRED_FUNCTION_MISSING
            violations.append(_violation(klass, module.path.name, f"required {code} missing: {name}"))
    return violations


def _forbidden_imports(module: _ParsedModule, forbidden: set[str], *, code: str = FORBIDDEN_IMPORT_DETECTED) -> list[AuditViolation]:
    violations: list[AuditViolation] = []
    for root, lineno in _import_details(module.tree):
        if root in forbidden:
            violations.append(_violation(code, module.path.name, f"forbidden import root detected: {root}", lineno=lineno or None))
    return violations


def _forbidden_calls(module: _ParsedModule, forbidden: set[str], *, code: str = FORBIDDEN_CALL_DETECTED) -> list[AuditViolation]:
    violations: list[AuditViolation] = []
    for name, lineno in _call_details(module.tree):
        if name in forbidden:
            violations.append(_violation(code, module.path.name, f"forbidden call detected: {name}", lineno=lineno or None))
    return violations


def _contains_any(source: str, fragments: Iterable[str]) -> bool:
    return any(fragment in source for fragment in fragments)


# ----------------------------
# Module-specific audits
# ----------------------------


def audit_btns_wfc(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "btns_wfc.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("btns_wfc.py", str(root_path / "btns_wfc.py"), STATUS_FAIL, tuple(violations))

    required = {
        "WFCConfig": "class",
        "WFCCandidate": "class",
        "WFCTrace": "class",
        "WFCSelectionResult": "class",
        "WFCAblationRecord": "class",
        "enumerate_wfc_candidates": "function",
        "propagate_wfc_candidate": "function",
        "filter_wfc_strict_candidates": "function",
        "kappa_zero_key": "function",
        "kappa_even_key": "function",
        "select_wfc_candidate": "function",
        "strict_wfc": "function",
        "validate_wfc_trace": "function",
    }
    violations.extend(_require_names(module, required))

    if "strict_wfc" not in _called_names(module.tree) and "def strict_wfc" not in module.source:
        violations.append(_violation(WFC_OPERATOR_MISSING, module.path.name, "strict_wfc operator is missing"))
    if "enumerate_wfc_candidates" not in _top_level_names(module.tree):
        violations.append(_violation(WFC_CANDIDATE_ENUMERATION_MISSING, module.path.name, "WFC candidate enumeration missing"))
    if "filter_wfc_strict_candidates" not in _top_level_names(module.tree):
        violations.append(_violation(WFC_STRICT_FILTER_MISSING, module.path.name, "strict candidate filter missing"))
    if "q0 == 0" not in module.source and "q0_selected != 0" not in module.source:
        violations.append(_violation(WFC_NO_LEAKAGE_CHECK_MISSING, module.path.name, "q0 no-leakage check not detected"))
    if "VALUE_PRESERVED" not in module.source and "VALUE_PRESERVATION" not in module.source:
        violations.append(_violation(WFC_VALUE_PRESERVATION_CHECK_MISSING, module.path.name, "value-preservation status/check not detected"))
    if "RN_ZERO" not in module.source or "RN_EVEN" not in module.source or "select_wfc_candidate" not in module.source:
        violations.append(_violation(WFC_POLICY_SELECTION_MISSING, module.path.name, "WFC policy selection not detected"))
    if "WFCTrace" not in module.source or "wfc_trace_id" not in module.source:
        violations.append(_violation(WFC_TRACE_MISSING, module.path.name, "WFC trace schema not detected"))

    forbidden = {"decimal", "fractions", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "egress", "gold_reference", "reporting"}
    violations.extend(_forbidden_imports(module, forbidden))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_btns_core(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "btns_core.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("btns_core.py", str(root_path / "btns_core.py"), STATUS_FAIL, tuple(violations))

    required = {
        "BTNSNumber": "class",
        "TailBound": "class",
        "validate_digits": "function",
        "normalize_digits": "function",
        "add_btns": "function",
        "neg_btns": "function",
        "sub_btns": "function",
        "mul_btns": "function",
        "canonize_btns": "function",
        "btns_equal_digits": "function",
    }
    violations.extend(_require_names(module, required))

    canonize = _function_node(module.tree, "canonize_btns")
    if canonize is None:
        violations.append(_violation(WFC_BYPASS_DETECTED, module.path.name, "canonize_btns missing"))
    else:
        called = _called_names(canonize)
        if "strict_wfc" not in called:
            violations.append(_violation(WFC_BYPASS_DETECTED, module.path.name, "canonize_btns does not call strict_wfc()"))
        if "normalize_digits" in called and "strict_wfc" not in called:
            violations.append(_violation(CANONIZE_ONLY_REPORTED_AS_FULL_WFC, module.path.name, "canonize_btns appears to normalize without strict_wfc"))
    if "wfc_trace_id" not in module.source or "wfc_status" not in module.source:
        violations.append(_violation(WFC_TRACE_MISSING, module.path.name, "BTNSNumber lacks WFC trace/status fields"))

    forbidden = {"decimal", "fractions", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "egress", "gold_reference", "reporting"}
    violations.extend(_forbidden_imports(module, forbidden))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_btns_poly(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "btns_poly.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("btns_poly.py", str(root_path / "btns_poly.py"), STATUS_FAIL, tuple(violations))

    required = {
        "CampaignConfig": "class",
        "OperationCertificate": "class",
        "PolynomialStepTrace": "class",
        "PolynomialResult": "class",
        "CertifiedPolynomialResult": "class",
        "MatchedDepthPolynomialResult": "class",
        "build_polynomial_coeffs_noncertified": "function",
        "build_polynomial_coeffs_certified_independent": "function",
        "build_polynomial_coeffs_noncertified_matched_depth": "function",
    }
    violations.extend(_require_names(module, required))

    calls = _called_names(module.tree)
    if "canonize_btns" not in calls:
        violations.append(_violation(WFC_BYPASS_DETECTED, module.path.name, "polynomial layer does not call canonize_btns() for commitments"))
    if "build_polynomial_coeffs_noncertified_matched_depth" not in _top_level_names(module.tree):
        violations.append(_violation(MATCHED_DEPTH_NOT_IMPLEMENTED, module.path.name, "matched-depth Non-Certified recomputation function missing"))
    if "coefficients=certified_result.coefficients" in module.source or "base = certified_result" in module.source:
        violations.append(_violation(MATCHED_DEPTH_COPIES_CERTIFIED_OUTPUT, module.path.name, "matched-depth path appears to copy Certified outputs"))
    if "wfc_trace_id" not in module.source or "wfc_candidate_count" not in module.source:
        violations.append(_violation(WFC_TRACE_MISSING, module.path.name, "polynomial traces lack WFC fields"))

    forbidden_imports = {"decimal", "fractions", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "egress", "gold_reference", "reporting", "ingress"}
    forbidden_calls = {"Decimal", "Fraction", "read_excel", "load_workbook", "btns_to_decimal_string_for_report", "parse_decimal_string_to_btns", "build_gold_polynomial_coefficients", "build_gold_polynomial_from_root_strings"}
    violations.extend(_forbidden_imports(module, forbidden_imports))
    violations.extend(_forbidden_calls(module, forbidden_calls))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_btns_certified(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "btns_certified.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("btns_certified.py", str(root_path / "btns_certified.py"), STATUS_FAIL, tuple(violations))

    required = {
        "IntervalEnclosure": "class",
        "CoefficientCertificate": "class",
        "CertifiedRefinementRequest": "class",
        "WFCCandidateCertificate": "class",
        "WFCSelectionCertificate": "class",
        "PathComparisonRecord": "class",
        "MatchedDepthGovernanceRecord": "class",
        "compute_tail_bound": "function",
        "make_interval_enclosure": "function",
        "classify_true_tube_false": "function",
        "certify_operation": "function",
        "certify_coefficient": "function",
        "request_certified_refinement": "function",
        "certified_candidate_acceptance": "function",
        "compare_certified_path_to_noncertified_path": "function",
        "compare_certified_path_to_matched_depth_noncertified_path": "function",
        "certify_wfc_candidate": "function",
        "certify_wfc_selection": "function",
        "classify_wfc_status": "function",
    }
    violations.extend(_require_names(module, required))
    if "gold_reference" in module.source or "build_gold" in module.source:
        violations.append(_violation(GOLD_LEAKAGE_DETECTED, module.path.name, "Certified governance references gold construction/evaluation"))
    forbidden_imports = {"decimal", "fractions", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "egress", "gold_reference", "reporting", "ingress"}
    forbidden_calls = {"Decimal", "Fraction", "read_excel", "load_workbook", "build_gold_polynomial_coefficients", "parse_decimal_string_to_btns"}
    violations.extend(_forbidden_imports(module, forbidden_imports))
    violations.extend(_forbidden_calls(module, forbidden_calls))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_ingress(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "ingress.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("ingress.py", str(root_path / "ingress.py"), STATUS_FAIL, tuple(violations))

    required = {
        "RootInputRow": "class",
        "IngressTrace": "class",
        "IngressResult": "class",
        "parse_decimal_string_to_btns": "function",
        "parse_decimal_string_to_btns_with_trace": "function",
        "load_root_input_csv": "function",
        "select_roots_for_m": "function",
        "ingress_roots_for_m": "function",
        "ingress_numbers_for_m": "function",
    }
    violations.extend(_require_names(module, required))
    imports = _imports(module.tree)
    if "fractions" not in imports:
        violations.append(_violation(INGRESS_POLICY_VIOLATION, module.path.name, "ingress should use exact Fraction parsing at boundary", severity=STATUS_WARN))
    forbidden_imports = {"decimal", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "egress", "gold_reference", "reporting", "btns_poly", "btns_certified"}
    forbidden_calls = {"Decimal", "read_excel", "load_workbook", "build_polynomial_coeffs_noncertified", "build_polynomial_coeffs_certified_independent", "build_gold_polynomial_coefficients", "btns_to_decimal_string_for_report"}
    violations.extend(_forbidden_imports(module, forbidden_imports, code=INGRESS_POLICY_VIOLATION))
    violations.extend(_forbidden_calls(module, forbidden_calls, code=INGRESS_POLICY_VIOLATION))
    if "FORBIDDEN_EXCEL_INPUT" not in module.source or "FORBIDDEN_EXCEL_SUFFIXES" not in module.source:
        violations.append(_violation(INGRESS_POLICY_VIOLATION, module.path.name, "Excel input rejection not detected"))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_egress(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "egress.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("egress.py", str(root_path / "egress.py"), STATUS_FAIL, tuple(violations))

    required = {
        "RationalPower3": "class",
        "DecimalIntervalStrings": "class",
        "EgressRow": "class",
        "finite_value_as_power3_rational": "function",
        "interval_as_power3_rationals": "function",
        "power3_rational_to_decimal_string_for_report": "function",
        "btns_to_decimal_string_for_report": "function",
        "btns_to_decimal_interval_strings_for_report": "function",
        "btns_to_report_dict": "function",
        "coefficients_to_report_rows": "function",
    }
    violations.extend(_require_names(module, required))
    forbidden_imports = {"decimal", "fractions", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "ingress", "btns_poly", "btns_certified", "btns_wfc", "gold_reference", "reporting"}
    forbidden_calls = {"Decimal", "Fraction", "parse_decimal_string_to_btns", "strict_wfc", "select_wfc_candidate", "build_polynomial_coeffs_noncertified", "certify_operation", "certify_coefficient"}
    violations.extend(_forbidden_imports(module, forbidden_imports, code=EGRESS_POLICY_VIOLATION))
    violations.extend(_forbidden_calls(module, forbidden_calls, code=EGRESS_POLICY_VIOLATION))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_gold_reference(root: str | Path) -> ModuleAuditResult:
    root_path = Path(root)
    module, errors = _read_parse(root_path, "gold_reference.py")
    violations = list(errors)
    if module is None:
        return ModuleAuditResult("gold_reference.py", str(root_path / "gold_reference.py"), STATUS_FAIL, tuple(violations))

    required = {
        "GoldCoefficientRecord": "class",
        "GoldPolynomialReference": "class",
        "GoldComparisonRecord": "class",
        "GoldSummary": "class",
        "parse_root_decimal_string_to_fraction": "function",
        "build_gold_polynomial_coefficients": "function",
        "build_gold_polynomial_from_root_strings": "function",
        "build_gold_quadratic_from_root_strings": "function",
        "compare_coefficients_to_gold": "function",
        "summarize_gold_comparisons": "function",
    }
    violations.extend(_require_names(module, required))
    imports = _imports(module.tree)
    if "fractions" not in imports:
        violations.append(_violation(GOLD_LEAKAGE_DETECTED, module.path.name, "gold_reference should use exact Fraction for external references", severity=STATUS_WARN))
    forbidden_imports = {"decimal", "numpy", "sympy", "openpyxl", "pandas", "xlrd", "pyxlsb", "ingress", "egress", "btns_poly", "btns_certified", "btns_wfc", "reporting"}
    forbidden_calls = {"Decimal", "parse_decimal_string_to_btns", "load_root_input_csv", "btns_to_decimal_string_for_report", "strict_wfc", "select_wfc_candidate", "certify_operation", "certify_coefficient"}
    violations.extend(_forbidden_imports(module, forbidden_imports, code=GOLD_LEAKAGE_DETECTED))
    violations.extend(_forbidden_calls(module, forbidden_calls, code=GOLD_LEAKAGE_DETECTED))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult(module.path.name, str(module.path), status, tuple(violations))


def audit_wfc_ablation_presence(root: str | Path, *, stage: str) -> ModuleAuditResult:
    root_path = Path(root)
    path = root_path / "run_wfc_ablation.py"
    if stage == STAGE_CORE_STACK:
        violation = _violation(
            RUNNER_REQUIRED_LATER,
            "run_wfc_ablation.py",
            "run_wfc_ablation.py is required for final package evidence, but is not required at CORE_STACK stage",
            severity=STATUS_WARN,
        )
        status = STATUS_WARN
        if path.exists():
            status = STATUS_PASS
            return ModuleAuditResult("run_wfc_ablation.py", str(path), status, tuple())
        return ModuleAuditResult("run_wfc_ablation.py", str(path), status, (violation,))
    if not path.exists():
        violation = _violation(WFC_ABLATION_NOT_GENERATED, "run_wfc_ablation.py", "final package requires run_wfc_ablation.py")
        return ModuleAuditResult("run_wfc_ablation.py", str(path), STATUS_FAIL, (violation,))
    module, errors = _read_parse(root_path, "run_wfc_ablation.py")
    violations = list(errors)
    if module is not None:
        for fragment in (
            "A0_CANONIZE_ONLY_BASELINE",
            "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW",
            "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW",
            "A3_FULL_WFC_SMALLER_WINDOW",
            "A4_FULL_WFC_LARGER_WINDOW",
        ):
            if fragment not in module.source:
                violations.append(_violation(WFC_ABLATION_NOT_GENERATED, module.path.name, f"missing required ablation branch token: {fragment}"))
    status = STATUS_FAIL if any(v.severity == STATUS_FAIL for v in violations) else STATUS_PASS
    return ModuleAuditResult("run_wfc_ablation.py", str(path), status, tuple(violations))


# ----------------------------
# Project-level entry points
# ----------------------------


def audit_project(root: str | Path = ".", *, stage: str = STAGE_CORE_STACK) -> AuditReport:
    if stage not in _ALLOWED_STAGES:
        raise ValueError(f"stage must be one of {_ALLOWED_STAGES}")
    root_path = Path(root)
    results = (
        audit_btns_wfc(root_path),
        audit_btns_core(root_path),
        audit_btns_poly(root_path),
        audit_btns_certified(root_path),
        audit_ingress(root_path),
        audit_egress(root_path),
        audit_gold_reference(root_path),
        audit_wfc_ablation_presence(root_path, stage=stage),
    )
    violations = tuple(violation for result in results for violation in result.violations)
    status = STATUS_FAIL if any(item.severity == STATUS_FAIL for item in violations) else STATUS_PASS
    if status == STATUS_PASS and any(item.severity == STATUS_WARN for item in violations):
        status = STATUS_WARN
    return AuditReport(
        root=str(root_path.resolve()),
        stage=stage,
        status=status,
        module_results=results,
        violations=violations,
    )


def assert_audit_passes(root: str | Path = ".", *, stage: str = STAGE_CORE_STACK, allow_warnings: bool = True) -> AuditReport:
    report = audit_project(root, stage=stage)
    failing = [item for item in report.violations if item.severity == STATUS_FAIL]
    warnings = [item for item in report.violations if item.severity == STATUS_WARN]
    if failing:
        details = "; ".join(f"{item.module}:{item.code}:{item.message}" for item in failing)
        raise AssertionError(details)
    if warnings and not allow_warnings:
        details = "; ".join(f"{item.module}:{item.code}:{item.message}" for item in warnings)
        raise AssertionError(details)
    return report


def audit_summary_lines(report: AuditReport) -> tuple[str, ...]:
    lines = [f"audit_status={report.status}", f"stage={report.stage}", f"root={report.root}"]
    for result in report.module_results:
        lines.append(f"{result.module}: {result.status} ({len(result.violations)} issue(s))")
        for violation in result.violations:
            loc = "" if violation.lineno is None else f":L{violation.lineno}"
            lines.append(f"  - {violation.severity} {violation.code}{loc}: {violation.message}")
    return tuple(lines)


__all__ = [
    "WFC_OPERATOR_MISSING",
    "WFC_CANDIDATE_ENUMERATION_MISSING",
    "WFC_STRICT_FILTER_MISSING",
    "WFC_NO_LEAKAGE_CHECK_MISSING",
    "WFC_VALUE_PRESERVATION_CHECK_MISSING",
    "WFC_POLICY_SELECTION_MISSING",
    "WFC_TRACE_MISSING",
    "WFC_BYPASS_DETECTED",
    "CANONIZE_ONLY_REPORTED_AS_FULL_WFC",
    "MATCHED_DEPTH_NOT_IMPLEMENTED",
    "MATCHED_DEPTH_COPIES_CERTIFIED_OUTPUT",
    "WFC_ABLATION_NOT_GENERATED",
    "FILE_MISSING",
    "PYTHON_PARSE_ERROR",
    "REQUIRED_FUNCTION_MISSING",
    "REQUIRED_CLASS_MISSING",
    "FORBIDDEN_IMPORT_DETECTED",
    "FORBIDDEN_CALL_DETECTED",
    "INGRESS_POLICY_VIOLATION",
    "EGRESS_POLICY_VIOLATION",
    "GOLD_LEAKAGE_DETECTED",
    "CERTIFIED_POLICY_VIOLATION",
    "RUNNER_REQUIRED_LATER",
    "STATUS_PASS",
    "STATUS_FAIL",
    "STATUS_WARN",
    "STAGE_CORE_STACK",
    "STAGE_FINAL_PACKAGE",
    "AuditViolation",
    "ModuleAuditResult",
    "AuditReport",
    "audit_btns_wfc",
    "audit_btns_core",
    "audit_btns_poly",
    "audit_btns_certified",
    "audit_ingress",
    "audit_egress",
    "audit_gold_reference",
    "audit_project",
    "assert_audit_passes",
    "audit_summary_lines",
]


if __name__ == "__main__":
    report = audit_project(Path(__file__).resolve().parent, stage=STAGE_CORE_STACK)
    for line in audit_summary_lines(report):
        print(line)
    # At CORE_STACK stage, run_wfc_ablation.py may be a warning only.
    assert_audit_passes(Path(__file__).resolve().parent, stage=STAGE_CORE_STACK, allow_warnings=True)
    print("audit.py self-check PASS")
