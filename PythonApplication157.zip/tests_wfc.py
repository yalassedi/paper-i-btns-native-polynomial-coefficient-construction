"""
tests_wfc.py

Unit tests for btns_wfc.py, the full strict Windowed Fractional
Canonization (WFC) module used by PythonApplication157.

The tests are intentionally standalone and construction-boundary safe:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel / workbook / gold-reference / egress calls

They verify the v28 requirements for:
    W_w = {0, -1, ..., -w}
    C_in = {-1, 0, +1}
    q_{-w-1}^{(c_in)} = c_in
    propagation k = -w, ..., 0
    q0 no-leakage
    strict-empty handling
    boundary compensation / support rejection
    RN_ZERO and RN_EVEN deterministic selection
    idempotence
    trace completeness
    WFC_NOT_APPLICABLE behavior
"""

from __future__ import annotations

from dataclasses import dataclass
import unittest

import btns_wfc as wfc


@dataclass(frozen=True)
class TailBound:
    lower_exp: int
    abs_bound_num: int
    abs_bound_den_power3: int
    policy: str
    source: str


@dataclass(frozen=True)
class BTNSNumber:
    digits: dict[int, int]
    k_min: int
    k_max: int
    radix: int = 3
    digit_set: tuple[int, int, int] = (-1, 0, 1)
    tail_bound: TailBound | None = None
    canonicality_flag: str = "PENDING"
    source_tag: str = "TEST"
    precision_depth: int | None = None
    trace_id: str | None = None
    wfc_trace_id: str | None = None
    wfc_status: str | None = None


def make_number(digits: dict[int, int], *, k_min: int | None = None, k_max: int | None = None, trace_id: str = "X") -> BTNSNumber:
    if k_min is None:
        k_min = min(digits.keys()) if digits else 0
    if k_max is None:
        k_max = max(digits.keys()) if digits else 0
    # Ensure the canonical WFC window can include zero.
    k_max = max(k_max, 0)
    return BTNSNumber(digits=dict(digits), k_min=k_min, k_max=k_max, trace_id=trace_id)


class TestWFCConfig(unittest.TestCase):
    def test_config_accepts_exact_candidate_set_and_policy(self) -> None:
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)
        self.assertEqual(cfg.window_width, 2)
        self.assertEqual(cfg.policy, wfc.RN_ZERO)
        self.assertEqual(cfg.candidate_C_in_set, (-1, 0, 1))

    def test_config_rejects_wrong_candidate_set(self) -> None:
        with self.assertRaises(ValueError):
            wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO, candidate_C_in_set=(0, 1, -1))

    def test_config_rejects_unknown_policy(self) -> None:
        with self.assertRaises(ValueError):
            wfc.WFCConfig(window_width=2, policy="RN-BAD")


class TestCandidateEnumerationAndPropagation(unittest.TestCase):
    def test_candidate_enumeration_has_exact_three_carry_inputs(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)
        candidates = wfc.enumerate_wfc_candidates(x, cfg, "ENUM_TEST")

        self.assertEqual(len(candidates), 3)
        self.assertEqual({candidate.c_in for candidate in candidates}, {-1, 0, 1})

    def test_initial_carry_in_is_applied_at_lower_window_boundary(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        c_plus = wfc.propagate_wfc_candidate(x, cfg, 1, "QINIT_PLUS")
        c_zero = wfc.propagate_wfc_candidate(x, cfg, 0, "QINIT_ZERO")
        c_minus = wfc.propagate_wfc_candidate(x, cfg, -1, "QINIT_MINUS")

        # q_{-w-1}=c_in affects the first propagated position k=-w.
        self.assertEqual(c_plus.digits_after[-2], 1)
        self.assertEqual(c_zero.digits_after[-2], 0)
        self.assertEqual(c_minus.digits_after[-2], -1)

        # All three candidates leak no carry at q0 in this simple case.
        self.assertEqual(c_plus.q0, 0)
        self.assertEqual(c_zero.q0, 0)
        self.assertEqual(c_minus.q0, 0)

    def test_q0_no_leakage_failure_is_detected(self) -> None:
        x = make_number({0: 1}, k_min=0, k_max=0)
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)

        candidate = wfc.propagate_wfc_candidate(x, cfg, 1, "NO_LEAKAGE_FAIL_CASE")

        self.assertEqual(candidate.q0, 1)
        self.assertEqual(candidate.no_leakage_status, wfc.WFC_NO_LEAKAGE_FAIL)
        self.assertEqual(candidate.strict_status, wfc.STRICT_FAIL)

    def test_strict_empty_family_is_reported_without_candidate_selection(self) -> None:
        # Deliberately malformed raw boundary digit. This test verifies the
        # strict-empty path and does not claim that this is a valid BTNS input.
        x = make_number({0: 2}, k_min=0, k_max=0)
        cfg = wfc.WFCConfig(
            window_width=0,
            policy=wfc.RN_ZERO,
            boundary_mode=wfc.REJECT_NONZERO_C_IN,
        )

        result = wfc.strict_wfc(x, cfg, {"operation_id": "STRICT_EMPTY"})

        self.assertIsNone(result.canonical_object)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_UNDEFINED_STRICT_EMPTY)
        self.assertEqual(result.trace.strict_candidate_count, 0)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))


class TestBoundaryAndSupportRules(unittest.TestCase):
    def test_lower_boundary_compensation_allows_recorded_value_preservation(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(
            window_width=2,
            policy=wfc.RN_ZERO,
            boundary_mode=wfc.LOWER_BOUNDARY_COMPENSATED,
        )

        candidate = wfc.propagate_wfc_candidate(x, cfg, 1, "COMPENSATED")

        self.assertEqual(candidate.value_preservation_status, wfc.VALUE_PRESERVED_COMPENSATED)
        self.assertEqual(candidate.support_status, wfc.SUPPORT_COMPENSATED_LOWER_BOUNDARY)
        self.assertEqual(candidate.strict_status, wfc.STRICT_PASS)

    def test_extended_support_boundary_is_conservative_without_explicit_extension(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(
            window_width=2,
            policy=wfc.RN_ZERO,
            boundary_mode=wfc.EXTENDED_SUPPORT_BOUNDARY,
        )

        candidate = wfc.propagate_wfc_candidate(x, cfg, 1, "EXTENDED_SUPPORT")

        self.assertEqual(candidate.support_status, wfc.SUPPORT_REQUIRES_EXTENSION)
        self.assertEqual(candidate.value_preservation_status, wfc.WFC_VALUE_PRESERVATION_FAIL)
        self.assertEqual(candidate.strict_status, wfc.STRICT_FAIL)

    def test_window_outside_declared_support_fails_support_check(self) -> None:
        x = make_number({0: 0}, k_min=0, k_max=0)
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        candidate = wfc.propagate_wfc_candidate(x, cfg, 0, "SUPPORT_OUTSIDE")

        self.assertEqual(candidate.support_status, wfc.WFC_SUPPORT_FAIL)
        self.assertEqual(candidate.strict_status, wfc.STRICT_FAIL)


class TestSelectionPolicies(unittest.TestCase):
    def test_rn_zero_is_deterministic_and_prefers_zero_carry_when_available(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        result1 = wfc.strict_wfc(x, cfg, {"operation_id": "RN_ZERO_DET"})
        result2 = wfc.strict_wfc(x, cfg, {"operation_id": "RN_ZERO_DET"})

        self.assertIsNotNone(result1.canonical_object)
        self.assertEqual(result1.trace.selected_c_in, 0)
        self.assertEqual(result1.trace.wfc_status, wfc.WFC_TIE_RESOLVED_RN_ZERO)
        self.assertEqual(result1.trace.selected_candidate_id, result2.trace.selected_candidate_id)
        self.assertTrue(wfc.validate_wfc_trace(result1.trace, result1.candidates))

    def test_rn_even_can_prefer_even_boundary_digit_over_zero_carry(self) -> None:
        # c_in = 0 preserves z_0 = -1, while c_in = +1 yields z_0 = 0.
        # RN_EVEN must prefer the even boundary digit z_0 = 0.
        x = make_number({-1: 1, 0: -1}, k_min=-1, k_max=0)
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_EVEN)

        result = wfc.strict_wfc(x, cfg, {"operation_id": "RN_EVEN_SELECTS_Z0_ZERO"})

        self.assertIsNotNone(result.canonical_object)
        self.assertEqual(result.trace.selected_c_in, 1)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_TIE_RESOLVED_RN_EVEN)
        self.assertEqual(result.canonical_object.digits[0], 0)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))

    def test_select_candidate_rejects_empty_strict_family(self) -> None:
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_ZERO)
        with self.assertRaises(wfc.WFCError):
            wfc.select_wfc_candidate(tuple(), cfg)


class TestTraceAndIdempotence(unittest.TestCase):
    def test_strict_wfc_result_has_complete_trace_and_updated_object_fields(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0, trace_id="TRACE_INPUT")
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        result = wfc.strict_wfc(x, cfg, {"operation_id": "TRACE_COMPLETE"})

        self.assertIsNotNone(result.canonical_object)
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))
        self.assertEqual(result.canonical_object.wfc_trace_id, result.trace.wfc_trace_id)
        self.assertEqual(result.canonical_object.wfc_status, result.trace.wfc_status)
        self.assertEqual(result.canonical_object.canonicality_flag, "LEGAL")

    def test_strict_wfc_is_idempotent_on_digits_for_zero_policy_selected_zero_carry(self) -> None:
        x = make_number({-2: 0, -1: 0, 0: 0}, k_min=-2, k_max=0)
        cfg = wfc.WFCConfig(window_width=2, policy=wfc.RN_ZERO)

        first = wfc.strict_wfc(x, cfg, {"operation_id": "IDEMPOTENT_1"})
        self.assertIsNotNone(first.canonical_object)
        second = wfc.strict_wfc(first.canonical_object, cfg, {"operation_id": "IDEMPOTENT_2"})
        self.assertIsNotNone(second.canonical_object)

        self.assertEqual(first.canonical_object.digits, second.canonical_object.digits)

    def test_wfc_not_applicable_trace_has_reason_and_no_candidates(self) -> None:
        x = make_number({0: 1}, k_min=0, k_max=0)
        cfg = wfc.WFCConfig(window_width=0, policy=wfc.RN_ZERO)

        result = wfc.strict_wfc(
            x,
            cfg,
            {
                "operation_id": "LEADING_COEFFICIENT",
                "wfc_applicable": False,
                "not_applicable_reason": "EXACT_LEADING_COEFFICIENT",
            },
        )

        self.assertIsNotNone(result.canonical_object)
        self.assertEqual(result.trace.wfc_status, wfc.WFC_NOT_APPLICABLE)
        self.assertEqual(result.trace.candidate_count, 0)
        self.assertEqual(len(result.candidates), 0)
        self.assertEqual(result.trace.wfc_not_applicable_reason, "EXACT_LEADING_COEFFICIENT")
        self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))

    def test_validate_wfc_trace_reports_errors_for_corrupted_trace(self) -> None:
        x = make_number({-1: 0, 0: 0}, k_min=-1, k_max=0)
        cfg = wfc.WFCConfig(window_width=1, policy=wfc.RN_ZERO)
        result = wfc.strict_wfc(x, cfg, {"operation_id": "VALIDATE_ERRORS"})

        bad_trace = wfc.WFCTrace(
            wfc_trace_id=result.trace.wfc_trace_id,
            operation_id=result.trace.operation_id,
            input_trace_id=result.trace.input_trace_id,
            output_trace_id=result.trace.output_trace_id,
            window_width=result.trace.window_width,
            policy=result.trace.policy,
            candidate_count=999,
            strict_candidate_count=result.trace.strict_candidate_count,
            selected_candidate_id=result.trace.selected_candidate_id,
            selected_c_in=result.trace.selected_c_in,
            q0_selected=result.trace.q0_selected,
            wfc_status=result.trace.wfc_status,
            wfc_boundary_mode=result.trace.wfc_boundary_mode,
            wfc_not_applicable_reason=result.trace.wfc_not_applicable_reason,
        )

        errors = wfc.validate_wfc_trace_errors(bad_trace, result.candidates)
        self.assertIn("candidate_count does not match candidate list length", errors)


if __name__ == "__main__":
    unittest.main(verbosity=2)
