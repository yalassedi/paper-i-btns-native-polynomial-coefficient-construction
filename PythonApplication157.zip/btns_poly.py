"""
btns_poly.py

BTNS-native polynomial coefficient construction layer for PythonApplication157
under Script Contract v28.

This module preserves the strong P129/v22 polynomial-construction structure,
but upgrades coefficient commitment to the v28 WFC discipline:

    - coefficients are built only from BTNSNumber objects;
    - low-level arithmetic is delegated to btns_core.py;
    - every committed coefficient passes through canonize_btns(), which calls
      btns_wfc.strict_wfc();
    - exact leading coefficients are explicitly marked WFC_NOT_APPLICABLE;
    - Certified and Non-Certified paths use distinct construction controllers;
    - matched-depth Non-Certified recomputation is provided as a separate path.

This module is construction-boundary safe:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel / workbook / gold-reference / egress / reporting calls

Coefficient order:
    [c_0, c_1, ..., c_m] represents
    c_0*x^m + c_1*x^(m-1) + ... + c_m.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
from typing import Iterable, List, Optional, Sequence, Tuple

from btns_core import (
    CANONICAL_LEGAL,
    SOURCE_CERTIFIED,
    SOURCE_COEFFICIENT,
    SOURCE_TEST,
    TAIL_NONE,
    BTNSNumber,
    WFCConfig,
    add_btns,
    canonize_btns,
    canonize_btns_not_applicable,
    digit_string_kmax_to_kmin,
    make_btns_number_from_digits,
    mul_btns,
    neg_btns,
    btns_equal_digits,
    sub_btns,
    validate_digits,
)
from btns_wfc import (
    RN_ZERO,
    RN_EVEN,
    LOWER_BOUNDARY_COMPENSATED,
    WFCSelectionResult,
    WFC_NOT_APPLICABLE,
    WFC_UNDEFINED_STRICT_EMPTY,
    STRICT_PASS,
    validate_wfc_trace,
)


MODE_NONCERTIFIED = "BTNS_NONCERTIFIED_NATIVE_RECURRENCE"
MODE_CERTIFIED = "BTNS_CERTIFIED_INDEPENDENT_CONTROLLER"
MODE_NONCERTIFIED_MATCHED_DEPTH = "BTNS_NONCERTIFIED_MATCHED_DEPTH_CONTROL"
STATUS_OK = "OK"
STATUS_FAILED = "FAILED"

CERT_ACCEPT = "CERT_ACCEPT"
CERT_REFINE = "CERT_REFINE"
CERT_REFINE_REQUEST = "CERT_REFINE_REQUEST"
CERT_REBUILD = "CERT_REBUILD"
CERT_TUBE_HOLD = "CERT_TUBE_HOLD"
CERT_REJECT = "CERT_REJECT"

MATCHED_DEPTH_EQUAL = "MATCHED_DEPTH_EQUAL"
MATCHED_DEPTH_DIFFERENT = "MATCHED_DEPTH_DIFFERENT"
MATCHED_DEPTH_NOT_RUN_INVALID = "MATCHED_DEPTH_NOT_RUN_INVALID"

PACKAGE_NAME = "PythonApplication157"
REFERENCE_LABEL = "PythonApplication_BTNS_Native_v28_FULL_STRICT_WFC_MATCHED_DEPTH"
CONTRACT_VERSION = "v28"


@dataclass(frozen=True)
class CampaignConfig:
    """Construction config for the m=2-first BTNS polynomial campaign."""

    k_min: int
    k_max: Optional[int] = None
    canonize_each_stage: bool = True
    trace_prefix: str = "POLY"
    package_name: str = PACKAGE_NAME
    reference_label: str = REFERENCE_LABEL
    contract_version: str = CONTRACT_VERSION
    accepted_width_num: int = 1
    accepted_width_den_power3: int = 30
    max_refinement_steps: int = 1
    refinement_step: int = 10
    tail_policy: str = "TAIL_REFINEMENT"
    wfc_window_width: int = 0
    wfc_policy: str = RN_ZERO
    wfc_boundary_mode: str = LOWER_BOUNDARY_COMPENSATED

    def __post_init__(self) -> None:
        if not isinstance(self.k_min, int):
            raise TypeError("k_min must be int")
        if self.k_max is not None and not isinstance(self.k_max, int):
            raise TypeError("k_max must be int or None")
        if self.k_max is not None and self.k_min > self.k_max:
            raise ValueError("k_min must be <= k_max when k_max is provided")
        if not isinstance(self.canonize_each_stage, bool):
            raise TypeError("canonize_each_stage must be bool")
        if not isinstance(self.trace_prefix, str) or not self.trace_prefix:
            raise ValueError("trace_prefix must be a non-empty string")
        for name in (
            "accepted_width_num",
            "accepted_width_den_power3",
            "max_refinement_steps",
            "refinement_step",
        ):
            value = getattr(self, name)
            if not isinstance(value, int):
                raise TypeError(f"{name} must be int")
            if value < 0:
                raise ValueError(f"{name} must be non-negative")
        if not isinstance(self.wfc_window_width, int):
            raise TypeError("wfc_window_width must be int")
        if self.wfc_window_width < 0:
            raise ValueError("wfc_window_width must be non-negative")
        if self.wfc_policy not in (RN_ZERO, RN_EVEN):
            raise ValueError("wfc_policy must be RN_ZERO or RN_EVEN")
        if not isinstance(self.wfc_boundary_mode, str) or not self.wfc_boundary_mode:
            raise ValueError("wfc_boundary_mode must be a non-empty string")

    def make_wfc_config(self) -> WFCConfig:
        return WFCConfig(
            window_width=self.wfc_window_width,
            policy=self.wfc_policy,
            boundary_mode=self.wfc_boundary_mode,
            strict_value_preservation_required=True,
            no_leakage_required=True,
            secondary_ordering="LEXICOGRAPHIC_STABLE",
        )


@dataclass(frozen=True)
class OperationCertificate:
    """Minimal v28 operation-level certificate with WFC-aware fields."""

    operation_id: str
    operation_name: str
    input_trace_ids: Tuple[str, ...]
    output_trace_id: str
    k_min: int
    k_max: int
    tail_bound: object | None
    canonicality_status: str
    wfc_trace_id: str | None
    wfc_status: str | None
    wfc_window_width: int | None
    wfc_policy: str | None
    wfc_candidate_count: int | None
    wfc_strict_candidate_count: int | None
    wfc_selected_c_in: int | None
    wfc_selected_candidate_id: str | None
    decision_token: str
    refinement_status: str
    certified_construction_token: str

    def as_dict(self) -> dict[str, object]:
        return {
            "operation_id": self.operation_id,
            "operation_name": self.operation_name,
            "input_trace_ids": list(self.input_trace_ids),
            "output_trace_id": self.output_trace_id,
            "k_min": self.k_min,
            "k_max": self.k_max,
            "tail_bound": str(self.tail_bound),
            "canonicality_status": self.canonicality_status,
            "wfc_trace_id": self.wfc_trace_id,
            "wfc_status": self.wfc_status,
            "wfc_window_width": self.wfc_window_width,
            "wfc_policy": self.wfc_policy,
            "wfc_candidate_count": self.wfc_candidate_count,
            "wfc_strict_candidate_count": self.wfc_strict_candidate_count,
            "wfc_selected_c_in": self.wfc_selected_c_in,
            "wfc_selected_candidate_id": self.wfc_selected_candidate_id,
            "decision_token": self.decision_token,
            "refinement_status": self.refinement_status,
            "certified_construction_token": self.certified_construction_token,
        }


@dataclass(frozen=True)
class CertifiedCandidateSelection:
    operation_id: str
    operation_name: str
    candidate_count: int
    accepted_candidate_id: str
    construction_token: str
    selection_reason: str

    def as_dict(self) -> dict[str, object]:
        return {
            "operation_id": self.operation_id,
            "operation_name": self.operation_name,
            "candidate_count": self.candidate_count,
            "accepted_candidate_id": self.accepted_candidate_id,
            "construction_token": self.construction_token,
            "selection_reason": self.selection_reason,
        }


@dataclass(frozen=True)
class PolynomialStepTrace:
    """Trace record for one polynomial construction step."""

    operation_id: str
    mode: str
    degree_stage: int
    root_position: int
    coefficient_index: int
    operation_type: str
    input_trace_ids: Tuple[str, ...]
    output_trace_id: str
    k_min: int
    k_max: int
    canonicality_flag: str
    tail_policy: str
    tail_abs_bound_num: int
    tail_abs_bound_den_power3: int
    digit_string_kmax_to_kmin: str
    wfc_trace_id: str = ""
    wfc_status: str = ""
    wfc_window_width: Optional[int] = None
    wfc_policy: str = ""
    wfc_candidate_count: int = 0
    wfc_strict_candidate_count: int = 0
    wfc_selected_c_in: Optional[int] = None
    wfc_selected_candidate_id: str = ""
    certified_path_id: str = ""
    certified_stage_id: str = ""
    certified_construction_token: str = ""
    operation_certificate_ids: Tuple[str, ...] = tuple()
    candidate_count: int = 0
    accepted_candidate_id: str = ""
    refinement_depth_used: int = 0

    def as_dict(self) -> dict[str, object]:
        return {
            "operation_id": self.operation_id,
            "mode": self.mode,
            "degree_stage": self.degree_stage,
            "root_position": self.root_position,
            "coefficient_index": self.coefficient_index,
            "operation_type": self.operation_type,
            "input_trace_ids": list(self.input_trace_ids),
            "output_trace_id": self.output_trace_id,
            "k_min": self.k_min,
            "k_max": self.k_max,
            "canonicality_flag": self.canonicality_flag,
            "tail_policy": self.tail_policy,
            "tail_abs_bound_num": self.tail_abs_bound_num,
            "tail_abs_bound_den_power3": self.tail_abs_bound_den_power3,
            "digit_string_kmax_to_kmin": self.digit_string_kmax_to_kmin,
            "wfc_trace_id": self.wfc_trace_id,
            "wfc_status": self.wfc_status,
            "wfc_window_width": self.wfc_window_width,
            "wfc_policy": self.wfc_policy,
            "wfc_candidate_count": self.wfc_candidate_count,
            "wfc_strict_candidate_count": self.wfc_strict_candidate_count,
            "wfc_selected_c_in": self.wfc_selected_c_in,
            "wfc_selected_candidate_id": self.wfc_selected_candidate_id,
            "certified_path_id": self.certified_path_id,
            "certified_stage_id": self.certified_stage_id,
            "certified_construction_token": self.certified_construction_token,
            "operation_certificate_ids": list(self.operation_certificate_ids),
            "candidate_count": self.candidate_count,
            "accepted_candidate_id": self.accepted_candidate_id,
            "refinement_depth_used": self.refinement_depth_used,
        }


@dataclass(frozen=True)
class CertifiedDecisionRecord:
    certified_path_id: str
    certified_stage_id: str
    coefficient_index: int
    operation_type: str
    output_trace_id: str
    certified_construction_token: str
    operation_certificate_ids: Tuple[str, ...]
    candidate_count: int
    accepted_candidate_id: str
    refinement_depth_used: int
    wfc_trace_id: str = ""
    wfc_status: str = ""

    def as_dict(self) -> dict[str, object]:
        return {
            "certified_path_id": self.certified_path_id,
            "certified_stage_id": self.certified_stage_id,
            "coefficient_index": self.coefficient_index,
            "operation_type": self.operation_type,
            "output_trace_id": self.output_trace_id,
            "certified_construction_token": self.certified_construction_token,
            "operation_certificate_ids": list(self.operation_certificate_ids),
            "candidate_count": self.candidate_count,
            "accepted_candidate_id": self.accepted_candidate_id,
            "refinement_depth_used": self.refinement_depth_used,
            "wfc_trace_id": self.wfc_trace_id,
            "wfc_status": self.wfc_status,
        }


@dataclass(frozen=True)
class MatchedDepthComparisonRecord:
    coefficient_index: int
    certified_final_k_min: int
    noncert_matched_k_min: int
    certified_trace_id: str
    matched_trace_id: str
    matched_depth_comparison: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "certified_final_k_min": self.certified_final_k_min,
            "noncert_matched_k_min": self.noncert_matched_k_min,
            "certified_trace_id": self.certified_trace_id,
            "matched_trace_id": self.matched_trace_id,
            "matched_depth_comparison": self.matched_depth_comparison,
        }


@dataclass(frozen=True)
class PolynomialResult:
    mode: str
    m: int
    coefficients: Tuple[BTNSNumber, ...]
    traces: Tuple[PolynomialStepTrace, ...]
    status: str
    message: str
    wfc_results: Tuple[WFCSelectionResult, ...] = tuple()

    @property
    def leading_coefficient(self) -> BTNSNumber:
        return self.coefficients[0]

    @property
    def nonleading_coefficients(self) -> Tuple[BTNSNumber, ...]:
        return self.coefficients[1:]


@dataclass(frozen=True)
class CertifiedPolynomialResult(PolynomialResult):
    certified_path_id: str = ""
    certified_decision_chain: Tuple[CertifiedDecisionRecord, ...] = tuple()
    candidate_selections: Tuple[CertifiedCandidateSelection, ...] = tuple()
    operation_certificates: Tuple[OperationCertificate, ...] = tuple()
    certified_stage: str = "CERTIFIED_INDEPENDENT_CONSTRUCTION_CONTROLLER"


@dataclass(frozen=True)
class MatchedDepthPolynomialResult(PolynomialResult):
    certified_final_k_min: int = 0
    matched_depth_records: Tuple[MatchedDepthComparisonRecord, ...] = tuple()


@dataclass(frozen=True)
class _CommitOutput:
    value: BTNSNumber
    wfc_result: WFCSelectionResult
    trace: PolynomialStepTrace


@dataclass(frozen=True)
class _CertifiedStepOutput:
    value: BTNSNumber
    traces: Tuple[PolynomialStepTrace, ...]
    wfc_results: Tuple[WFCSelectionResult, ...]
    decisions: Tuple[CertifiedDecisionRecord, ...]
    selections: Tuple[CertifiedCandidateSelection, ...]
    certificates: Tuple[OperationCertificate, ...]


def _stable_trace_id(parts: Iterable[object]) -> str:
    text = "|".join(str(part) for part in parts)
    return sha256(text.encode("utf-8")).hexdigest()[:32]


def _trace_of(x: BTNSNumber) -> str:
    return x.trace_id or "NO_TRACE"


def _require_roots(roots: Sequence[BTNSNumber]) -> Tuple[BTNSNumber, ...]:
    if not roots:
        raise ValueError("at least one BTNSNumber root is required")
    checked: List[BTNSNumber] = []
    for idx, root in enumerate(roots, start=1):
        if not isinstance(root, BTNSNumber) or not validate_digits(root):
            raise ValueError(f"root at position {idx} is not a legal BTNSNumber")
        checked.append(root)
    return tuple(checked)


def _tail_policy(x: BTNSNumber) -> str:
    return TAIL_NONE if x.tail_bound is None else x.tail_bound.policy


def _tail_num(x: BTNSNumber) -> int:
    return 0 if x.tail_bound is None else x.tail_bound.abs_bound_num


def _tail_den(x: BTNSNumber) -> int:
    return 0 if x.tail_bound is None else x.tail_bound.abs_bound_den_power3


def _operation_id(
    mode: str,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    operation_type: str,
    input_trace_ids: Sequence[str],
    certified_path_id: str = "",
) -> str:
    return _stable_trace_id(
        (
            "poly-step-v28",
            mode,
            degree_stage,
            root_position,
            coefficient_index,
            operation_type,
            tuple(input_trace_ids),
            certified_path_id,
        )
    )


def _wfc_fields(result: Optional[WFCSelectionResult]) -> dict[str, object]:
    if result is None:
        return {
            "wfc_trace_id": "",
            "wfc_status": "",
            "wfc_window_width": None,
            "wfc_policy": "",
            "wfc_candidate_count": 0,
            "wfc_strict_candidate_count": 0,
            "wfc_selected_c_in": None,
            "wfc_selected_candidate_id": "",
        }
    return {
        "wfc_trace_id": result.trace.wfc_trace_id,
        "wfc_status": result.trace.wfc_status,
        "wfc_window_width": result.trace.window_width,
        "wfc_policy": result.trace.policy,
        "wfc_candidate_count": result.trace.candidate_count,
        "wfc_strict_candidate_count": result.trace.strict_candidate_count,
        "wfc_selected_c_in": result.trace.selected_c_in,
        "wfc_selected_candidate_id": result.trace.selected_candidate_id or "",
    }


def _make_step_trace(
    *,
    mode: str,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    operation_type: str,
    inputs: Sequence[BTNSNumber],
    output: BTNSNumber,
    wfc_result: Optional[WFCSelectionResult] = None,
    certified_path_id: str = "",
    certified_stage_id: str = "",
    certified_construction_token: str = "",
    operation_certificate_ids: Sequence[str] = tuple(),
    candidate_count: int = 0,
    accepted_candidate_id: str = "",
    refinement_depth_used: int = 0,
) -> PolynomialStepTrace:
    input_trace_ids = tuple(_trace_of(x) for x in inputs)
    operation_id = _operation_id(
        mode,
        degree_stage,
        root_position,
        coefficient_index,
        operation_type,
        input_trace_ids,
        certified_path_id,
    )
    fields = _wfc_fields(wfc_result)
    return PolynomialStepTrace(
        operation_id=operation_id,
        mode=mode,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type=operation_type,
        input_trace_ids=input_trace_ids,
        output_trace_id=output.trace_id or "NO_TRACE",
        k_min=output.k_min,
        k_max=output.k_max,
        canonicality_flag=output.canonicality_flag,
        tail_policy=_tail_policy(output),
        tail_abs_bound_num=_tail_num(output),
        tail_abs_bound_den_power3=_tail_den(output),
        digit_string_kmax_to_kmin=digit_string_kmax_to_kmin(output),
        certified_path_id=certified_path_id,
        certified_stage_id=certified_stage_id,
        certified_construction_token=certified_construction_token,
        operation_certificate_ids=tuple(operation_certificate_ids),
        candidate_count=candidate_count,
        accepted_candidate_id=accepted_candidate_id,
        refinement_depth_used=refinement_depth_used,
        **fields,
    )


def _with_source(x: BTNSNumber, *, certified: bool) -> BTNSNumber:
    source = SOURCE_CERTIFIED if certified else SOURCE_COEFFICIENT
    return replace(x, source_tag=source, canonicality_flag=CANONICAL_LEGAL)


def _commit_coefficient(
    x: BTNSNumber,
    *,
    config: CampaignConfig,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    operation_type: str,
    mode: str,
    inputs: Sequence[BTNSNumber],
    certified: bool = False,
    certified_path_id: str = "",
) -> _CommitOutput:
    wfc_config = config.make_wfc_config()
    input_ids = tuple(_trace_of(item) for item in inputs)
    op_id = _operation_id(mode, degree_stage, root_position, coefficient_index, operation_type, input_ids, certified_path_id)

    if not config.canonize_each_stage:
        result = canonize_btns_not_applicable(
            x,
            wfc_config,
            reason="CANONIZATION_DISABLED_BY_CAMPAIGN_CONFIG",
            operation_id=op_id,
            return_result=True,
        )
    else:
        result = canonize_btns(
            x,
            wfc_config,
            {"operation_id": op_id, "wfc_applicable": True},
            return_result=True,
        )

    if not isinstance(result, WFCSelectionResult):
        raise TypeError("canonize_btns(return_result=True) must return WFCSelectionResult")
    if not validate_wfc_trace(result.trace, result.candidates):
        raise ArithmeticError("invalid WFC trace emitted during coefficient commitment")
    if result.canonical_object is None:
        raise ArithmeticError(
            "cannot commit coefficient because strict WFC returned no canonical object: "
            f"{result.trace.wfc_status}"
        )
    if not isinstance(result.canonical_object, BTNSNumber):
        raise TypeError("canonical WFC object must be BTNSNumber")

    value = _with_source(result.canonical_object, certified=certified)
    trace = _make_step_trace(
        mode=mode,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type=operation_type,
        inputs=inputs,
        output=value,
        wfc_result=result,
        certified_path_id=certified_path_id,
    )
    return _CommitOutput(value=value, wfc_result=result, trace=trace)


def _commit_leading_one(
    x: BTNSNumber,
    *,
    config: CampaignConfig,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    mode: str,
    certified: bool = False,
    certified_path_id: str = "",
) -> _CommitOutput:
    wfc_config = config.make_wfc_config()
    operation_type = "CERT_COPY_LEADING_COEFFICIENT" if certified else "NC_COPY_LEADING_COEFFICIENT"
    input_ids = (_trace_of(x),)
    op_id = _operation_id(mode, degree_stage, root_position, coefficient_index, operation_type, input_ids, certified_path_id)
    result = canonize_btns_not_applicable(
        x,
        wfc_config,
        reason="EXACT_LEADING_COEFFICIENT",
        operation_id=op_id,
        return_result=True,
    )
    if not isinstance(result, WFCSelectionResult):
        raise TypeError("canonize_btns_not_applicable(return_result=True) must return WFCSelectionResult")
    if not isinstance(result.canonical_object, BTNSNumber):
        raise TypeError("leading coefficient WFC_NOT_APPLICABLE result must contain BTNSNumber")
    value = _with_source(result.canonical_object, certified=certified)
    trace = _make_step_trace(
        mode=mode,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type=operation_type,
        inputs=(x,),
        output=value,
        wfc_result=result,
        certified_path_id=certified_path_id,
    )
    return _CommitOutput(value=value, wfc_result=result, trace=trace)


def _coefficient_one(config: CampaignConfig, *, certified: bool = False, certified_path_id: str = "") -> BTNSNumber:
    k_min = config.k_min if config.k_min < 0 else 0
    k_max = config.k_max if config.k_max is not None and config.k_max > 0 else 0
    source = SOURCE_CERTIFIED if certified else SOURCE_COEFFICIENT
    label = "CERT_ONE" if certified else "NONCERT_ONE"
    return make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=source,
        trace_id=_stable_trace_id((config.trace_prefix, label, k_min, k_max, certified_path_id)),
    )


# ----------------------------
# Non-Certified controller
# ----------------------------

def _noncert_copy_leading(
    x: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
) -> _CommitOutput:
    return _commit_leading_one(
        x,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        mode=MODE_NONCERTIFIED,
        certified=False,
    )


def _noncert_middle(
    old_current: BTNSNumber,
    root: BTNSNumber,
    old_previous: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
) -> Tuple[BTNSNumber, Tuple[PolynomialStepTrace, ...], Tuple[WFCSelectionResult, ...]]:
    product = mul_btns(root, old_previous)
    product_trace = _make_step_trace(
        mode=MODE_NONCERTIFIED,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="NC_MUL_ROOT_PREVIOUS_COEFF",
        inputs=(root, old_previous),
        output=product,
    )
    difference = sub_btns(old_current, product)
    commit = _commit_coefficient(
        difference,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="NC_SUB_CURRENT_MINUS_PRODUCT_COMMIT",
        mode=MODE_NONCERTIFIED,
        inputs=(old_current, product),
        certified=False,
    )
    return commit.value, (product_trace, commit.trace), (commit.wfc_result,)


def _noncert_constant(
    root: BTNSNumber,
    old_last: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
) -> Tuple[BTNSNumber, Tuple[PolynomialStepTrace, ...], Tuple[WFCSelectionResult, ...]]:
    product = mul_btns(root, old_last)
    product_trace = _make_step_trace(
        mode=MODE_NONCERTIFIED,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="NC_MUL_ROOT_LAST_COEFF",
        inputs=(root, old_last),
        output=product,
    )
    negative = neg_btns(product)
    commit = _commit_coefficient(
        negative,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="NC_NEG_PRODUCT_FOR_CONSTANT_TERM_COMMIT",
        mode=MODE_NONCERTIFIED,
        inputs=(product,),
        certified=False,
    )
    return commit.value, (product_trace, commit.trace), (commit.wfc_result,)


def build_polynomial_coeffs_noncertified(
    roots: Sequence[BTNSNumber],
    config: CampaignConfig,
) -> PolynomialResult:
    checked_roots = _require_roots(roots)
    coefficients: Tuple[BTNSNumber, ...] = (_coefficient_one(config, certified=False),)
    traces: List[PolynomialStepTrace] = []
    wfc_results: List[WFCSelectionResult] = []

    for j, root in enumerate(checked_roots, start=1):
        old = coefficients
        new_coeffs: List[BTNSNumber] = []
        leading = _noncert_copy_leading(old[0], degree_stage=j, root_position=j, coefficient_index=0, config=config)
        new_coeffs.append(leading.value)
        traces.append(leading.trace)
        wfc_results.append(leading.wfc_result)
        for k in range(1, j):
            coeff, step_traces, step_wfc = _noncert_middle(
                old[k],
                root,
                old[k - 1],
                degree_stage=j,
                root_position=j,
                coefficient_index=k,
                config=config,
            )
            new_coeffs.append(coeff)
            traces.extend(step_traces)
            wfc_results.extend(step_wfc)
        constant, step_traces, step_wfc = _noncert_constant(
            root,
            old[-1],
            degree_stage=j,
            root_position=j,
            coefficient_index=j,
            config=config,
        )
        new_coeffs.append(constant)
        traces.extend(step_traces)
        wfc_results.extend(step_wfc)
        coefficients = tuple(new_coeffs)

    return PolynomialResult(
        mode=MODE_NONCERTIFIED,
        m=len(checked_roots),
        coefficients=coefficients,
        traces=tuple(traces),
        status=STATUS_OK,
        message="BTNS Non-Certified construction completed",
        wfc_results=tuple(wfc_results),
    )


# ----------------------------
# Certified independent controller
# ----------------------------

def _certified_stage_id(certified_path_id: str, degree_stage: int, coefficient_index: int, operation_type: str) -> str:
    return _stable_trace_id((certified_path_id, degree_stage, coefficient_index, operation_type))


def _operation_certificate(
    *,
    operation_name: str,
    output: BTNSNumber,
    inputs: Sequence[BTNSNumber],
    wfc_result: Optional[WFCSelectionResult],
    token: str,
) -> OperationCertificate:
    input_ids = tuple(_trace_of(x) for x in inputs)
    operation_id = _stable_trace_id(("v28-operation-certificate", operation_name, input_ids, output.trace_id, token))
    if wfc_result is None:
        wfc_trace_id = None
        wfc_status = None
        wfc_window_width = None
        wfc_policy = None
        wfc_candidate_count = None
        wfc_strict_candidate_count = None
        wfc_selected_c_in = None
        wfc_selected_candidate_id = None
    else:
        wfc_trace_id = wfc_result.trace.wfc_trace_id
        wfc_status = wfc_result.trace.wfc_status
        wfc_window_width = wfc_result.trace.window_width
        wfc_policy = wfc_result.trace.policy
        wfc_candidate_count = wfc_result.trace.candidate_count
        wfc_strict_candidate_count = wfc_result.trace.strict_candidate_count
        wfc_selected_c_in = wfc_result.trace.selected_c_in
        wfc_selected_candidate_id = wfc_result.trace.selected_candidate_id
    return OperationCertificate(
        operation_id=operation_id,
        operation_name=operation_name,
        input_trace_ids=input_ids,
        output_trace_id=output.trace_id or "NO_TRACE",
        k_min=output.k_min,
        k_max=output.k_max,
        tail_bound=output.tail_bound,
        canonicality_status=output.canonicality_flag,
        wfc_trace_id=wfc_trace_id,
        wfc_status=wfc_status,
        wfc_window_width=wfc_window_width,
        wfc_policy=wfc_policy,
        wfc_candidate_count=wfc_candidate_count,
        wfc_strict_candidate_count=wfc_strict_candidate_count,
        wfc_selected_c_in=wfc_selected_c_in,
        wfc_selected_candidate_id=wfc_selected_candidate_id,
        decision_token=token,
        refinement_status="REFINEMENT_NOT_REQUESTED",
        certified_construction_token=token,
    )


def _certified_selection(
    operation_name: str,
    output: BTNSNumber,
    wfc_result: Optional[WFCSelectionResult],
    token: str,
) -> CertifiedCandidateSelection:
    operation_id = _stable_trace_id(("v28-certified-selection", operation_name, output.trace_id, token))
    if wfc_result is None:
        candidate_count = 1
        accepted_candidate_id = output.trace_id or "NO_TRACE"
        reason = "DIRECT_BTNS_OPERATION_OUTPUT"
    elif wfc_result.trace.wfc_status == WFC_NOT_APPLICABLE:
        candidate_count = 1
        accepted_candidate_id = output.trace_id or "NO_TRACE"
        reason = "WFC_NOT_APPLICABLE_EXPLICIT_TRACE"
    else:
        candidate_count = wfc_result.trace.candidate_count
        accepted_candidate_id = wfc_result.trace.selected_candidate_id or output.trace_id or "NO_TRACE"
        reason = "FULL_STRICT_WFC_SELECTED_CANDIDATE"
    return CertifiedCandidateSelection(
        operation_id=operation_id,
        operation_name=operation_name,
        candidate_count=candidate_count,
        accepted_candidate_id=accepted_candidate_id,
        construction_token=token,
        selection_reason=reason,
    )


def _certified_decision(
    *,
    operation_type: str,
    coefficient_index: int,
    output: BTNSNumber,
    inputs: Sequence[BTNSNumber],
    wfc_result: Optional[WFCSelectionResult],
    degree_stage: int,
    root_position: int,
    config: CampaignConfig,
    certified_path_id: str,
    op_name: str,
) -> _CertifiedStepOutput:
    token = CERT_ACCEPT
    if wfc_result is not None and wfc_result.trace.wfc_status == WFC_UNDEFINED_STRICT_EMPTY:
        token = CERT_TUBE_HOLD

    certificate = _operation_certificate(
        operation_name=op_name,
        output=output,
        inputs=inputs,
        wfc_result=wfc_result,
        token=token,
    )
    selection = _certified_selection(op_name, output, wfc_result, token)
    stage_id = _certified_stage_id(certified_path_id, degree_stage, coefficient_index, operation_type)
    decision = CertifiedDecisionRecord(
        certified_path_id=certified_path_id,
        certified_stage_id=stage_id,
        coefficient_index=coefficient_index,
        operation_type=operation_type,
        output_trace_id=output.trace_id or "NO_TRACE",
        certified_construction_token=token,
        operation_certificate_ids=(certificate.operation_id,),
        candidate_count=selection.candidate_count,
        accepted_candidate_id=selection.accepted_candidate_id,
        refinement_depth_used=0,
        wfc_trace_id=output.wfc_trace_id or "",
        wfc_status=output.wfc_status or "",
    )
    trace = _make_step_trace(
        mode=MODE_CERTIFIED,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type=operation_type,
        inputs=inputs,
        output=output,
        wfc_result=wfc_result,
        certified_path_id=certified_path_id,
        certified_stage_id=stage_id,
        certified_construction_token=token,
        operation_certificate_ids=(certificate.operation_id,),
        candidate_count=selection.candidate_count,
        accepted_candidate_id=selection.accepted_candidate_id,
        refinement_depth_used=0,
    )
    return _CertifiedStepOutput(
        value=output,
        traces=(trace,),
        wfc_results=tuple() if wfc_result is None else (wfc_result,),
        decisions=(decision,),
        selections=(selection,),
        certificates=(certificate,),
    )


def _certified_copy_leading(
    x: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
    certified_path_id: str,
) -> _CertifiedStepOutput:
    commit = _commit_leading_one(
        x,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        mode=MODE_CERTIFIED,
        certified=True,
        certified_path_id=certified_path_id,
    )
    return _certified_decision(
        operation_type="CERT_COPY_LEADING_COEFFICIENT",
        coefficient_index=coefficient_index,
        output=commit.value,
        inputs=(x,),
        wfc_result=commit.wfc_result,
        degree_stage=degree_stage,
        root_position=root_position,
        config=config,
        certified_path_id=certified_path_id,
        op_name="CERT_COPY",
    )


def _certified_middle(
    old_current: BTNSNumber,
    root: BTNSNumber,
    old_previous: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
    certified_path_id: str,
) -> _CertifiedStepOutput:
    product = mul_btns(root, old_previous)
    product_cert = _certified_decision(
        operation_type="CERT_MUL_ROOT_PREVIOUS_COEFF",
        coefficient_index=coefficient_index,
        output=_with_source(product, certified=True),
        inputs=(root, old_previous),
        wfc_result=None,
        degree_stage=degree_stage,
        root_position=root_position,
        config=config,
        certified_path_id=certified_path_id,
        op_name="CERT_MUL",
    )
    difference = sub_btns(old_current, product_cert.value)
    commit = _commit_coefficient(
        difference,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="CERT_SUB_CURRENT_MINUS_PRODUCT_COMMIT",
        mode=MODE_CERTIFIED,
        inputs=(old_current, product_cert.value),
        certified=True,
        certified_path_id=certified_path_id,
    )
    diff_cert = _certified_decision(
        operation_type="CERT_SUB_CURRENT_MINUS_PRODUCT_COMMIT",
        coefficient_index=coefficient_index,
        output=commit.value,
        inputs=(old_current, product_cert.value),
        wfc_result=commit.wfc_result,
        degree_stage=degree_stage,
        root_position=root_position,
        config=config,
        certified_path_id=certified_path_id,
        op_name="CERT_SUB_COMMIT",
    )
    return _CertifiedStepOutput(
        value=diff_cert.value,
        traces=product_cert.traces + diff_cert.traces,
        wfc_results=product_cert.wfc_results + diff_cert.wfc_results,
        decisions=product_cert.decisions + diff_cert.decisions,
        selections=product_cert.selections + diff_cert.selections,
        certificates=product_cert.certificates + diff_cert.certificates,
    )


def _certified_constant(
    root: BTNSNumber,
    old_last: BTNSNumber,
    *,
    degree_stage: int,
    root_position: int,
    coefficient_index: int,
    config: CampaignConfig,
    certified_path_id: str,
) -> _CertifiedStepOutput:
    product = mul_btns(root, old_last)
    product_cert = _certified_decision(
        operation_type="CERT_MUL_ROOT_LAST_COEFF",
        coefficient_index=coefficient_index,
        output=_with_source(product, certified=True),
        inputs=(root, old_last),
        wfc_result=None,
        degree_stage=degree_stage,
        root_position=root_position,
        config=config,
        certified_path_id=certified_path_id,
        op_name="CERT_MUL_LAST",
    )
    negative = neg_btns(product_cert.value)
    commit = _commit_coefficient(
        negative,
        config=config,
        degree_stage=degree_stage,
        root_position=root_position,
        coefficient_index=coefficient_index,
        operation_type="CERT_NEG_PRODUCT_FOR_CONSTANT_TERM_COMMIT",
        mode=MODE_CERTIFIED,
        inputs=(product_cert.value,),
        certified=True,
        certified_path_id=certified_path_id,
    )
    neg_cert = _certified_decision(
        operation_type="CERT_NEG_PRODUCT_FOR_CONSTANT_TERM_COMMIT",
        coefficient_index=coefficient_index,
        output=commit.value,
        inputs=(product_cert.value,),
        wfc_result=commit.wfc_result,
        degree_stage=degree_stage,
        root_position=root_position,
        config=config,
        certified_path_id=certified_path_id,
        op_name="CERT_NEG_COMMIT",
    )
    return _CertifiedStepOutput(
        value=neg_cert.value,
        traces=product_cert.traces + neg_cert.traces,
        wfc_results=product_cert.wfc_results + neg_cert.wfc_results,
        decisions=product_cert.decisions + neg_cert.decisions,
        selections=product_cert.selections + neg_cert.selections,
        certificates=product_cert.certificates + neg_cert.certificates,
    )


def build_polynomial_coeffs_certified_independent(
    roots: Sequence[BTNSNumber],
    config: CampaignConfig,
) -> CertifiedPolynomialResult:
    checked_roots = _require_roots(roots)
    certified_path_id = _stable_trace_id(
        (
            "v28-certified-path",
            config.trace_prefix,
            len(checked_roots),
            tuple(root.trace_id for root in checked_roots),
            config.k_min,
            config.k_max,
            config.wfc_window_width,
            config.wfc_policy,
        )
    )
    coefficients: Tuple[BTNSNumber, ...] = (_coefficient_one(config, certified=True, certified_path_id=certified_path_id),)
    traces: List[PolynomialStepTrace] = []
    wfc_results: List[WFCSelectionResult] = []
    decisions: List[CertifiedDecisionRecord] = []
    selections: List[CertifiedCandidateSelection] = []
    certificates: List[OperationCertificate] = []

    for j, root in enumerate(checked_roots, start=1):
        old = coefficients
        new_coeffs: List[BTNSNumber] = []
        leading_step = _certified_copy_leading(
            old[0],
            degree_stage=j,
            root_position=j,
            coefficient_index=0,
            config=config,
            certified_path_id=certified_path_id,
        )
        new_coeffs.append(leading_step.value)
        traces.extend(leading_step.traces)
        wfc_results.extend(leading_step.wfc_results)
        decisions.extend(leading_step.decisions)
        selections.extend(leading_step.selections)
        certificates.extend(leading_step.certificates)
        for k in range(1, j):
            step = _certified_middle(
                old[k],
                root,
                old[k - 1],
                degree_stage=j,
                root_position=j,
                coefficient_index=k,
                config=config,
                certified_path_id=certified_path_id,
            )
            new_coeffs.append(step.value)
            traces.extend(step.traces)
            wfc_results.extend(step.wfc_results)
            decisions.extend(step.decisions)
            selections.extend(step.selections)
            certificates.extend(step.certificates)
        const_step = _certified_constant(
            root,
            old[-1],
            degree_stage=j,
            root_position=j,
            coefficient_index=j,
            config=config,
            certified_path_id=certified_path_id,
        )
        new_coeffs.append(const_step.value)
        traces.extend(const_step.traces)
        wfc_results.extend(const_step.wfc_results)
        decisions.extend(const_step.decisions)
        selections.extend(const_step.selections)
        certificates.extend(const_step.certificates)
        coefficients = tuple(new_coeffs)

    return CertifiedPolynomialResult(
        mode=MODE_CERTIFIED,
        m=len(checked_roots),
        coefficients=coefficients,
        traces=tuple(traces),
        status=STATUS_OK,
        message="BTNS Certified independent construction completed",
        wfc_results=tuple(wfc_results),
        certified_path_id=certified_path_id,
        certified_decision_chain=tuple(decisions),
        candidate_selections=tuple(selections),
        operation_certificates=tuple(certificates),
    )


def build_polynomial_coeffs_certified(
    roots: Sequence[BTNSNumber],
    config: CampaignConfig,
) -> CertifiedPolynomialResult:
    """Compatibility entry point for the v28 independent Certified controller."""

    return build_polynomial_coeffs_certified_independent(roots, config)


# ----------------------------
# Matched-depth Non-Certified controller
# ----------------------------

def _config_for_matched_depth(config: CampaignConfig, certified_final_k_min: int) -> CampaignConfig:
    if not isinstance(certified_final_k_min, int):
        raise TypeError("certified_final_k_min must be int")
    return replace(config, k_min=certified_final_k_min, trace_prefix=config.trace_prefix + ":MATCHED")


def build_polynomial_coeffs_noncertified_matched_depth(
    roots: Sequence[BTNSNumber],
    certified_final_k_min: int,
    config: CampaignConfig,
    certified_result: Optional[CertifiedPolynomialResult] = None,
) -> MatchedDepthPolynomialResult:
    """Recompute Non-Certified coefficients at Certified final k_min.

    This function deliberately runs the Non-Certified controller again. It does
    not copy Certified outputs, Certified traces, Certified UCC decisions, or
    Certified candidate choices.
    """

    checked_roots = _require_roots(roots)
    for idx, root in enumerate(checked_roots, start=1):
        if root.k_min > certified_final_k_min:
            raise ValueError(
                "matched-depth recomputation requires roots already projected "
                f"to k_min <= certified_final_k_min; root {idx} has {root.k_min}"
            )
    matched_config = _config_for_matched_depth(config, certified_final_k_min)
    base = build_polynomial_coeffs_noncertified(checked_roots, matched_config)

    records: List[MatchedDepthComparisonRecord] = []
    if certified_result is not None:
        for idx, matched_coeff in enumerate(base.coefficients):
            if idx < len(certified_result.coefficients):
                cert_coeff = certified_result.coefficients[idx]
                token = MATCHED_DEPTH_EQUAL if btns_equal_digits(cert_coeff, matched_coeff) else MATCHED_DEPTH_DIFFERENT
                cert_trace = cert_coeff.trace_id or "NO_TRACE"
            else:
                token = MATCHED_DEPTH_NOT_RUN_INVALID
                cert_trace = "MISSING_CERTIFIED_COEFFICIENT"
            records.append(
                MatchedDepthComparisonRecord(
                    coefficient_index=idx,
                    certified_final_k_min=certified_final_k_min,
                    noncert_matched_k_min=matched_config.k_min,
                    certified_trace_id=cert_trace,
                    matched_trace_id=matched_coeff.trace_id or "NO_TRACE",
                    matched_depth_comparison=token,
                )
            )

    return MatchedDepthPolynomialResult(
        mode=MODE_NONCERTIFIED_MATCHED_DEPTH,
        m=base.m,
        coefficients=base.coefficients,
        traces=base.traces,
        status=base.status,
        message="BTNS Non-Certified matched-depth recomputation completed",
        wfc_results=base.wfc_results,
        certified_final_k_min=certified_final_k_min,
        matched_depth_records=tuple(records),
    )


# ----------------------------
# Quadratic convenience wrappers
# ----------------------------

def build_quadratic_coeffs_noncertified(
    r1: BTNSNumber,
    r2: BTNSNumber,
    config: CampaignConfig,
) -> PolynomialResult:
    return build_polynomial_coeffs_noncertified([r1, r2], config)


def build_quadratic_coeffs_certified_independent(
    r1: BTNSNumber,
    r2: BTNSNumber,
    config: CampaignConfig,
) -> CertifiedPolynomialResult:
    return build_polynomial_coeffs_certified_independent([r1, r2], config)


def build_quadratic_coeffs_certified(
    r1: BTNSNumber,
    r2: BTNSNumber,
    config: CampaignConfig,
) -> CertifiedPolynomialResult:
    return build_quadratic_coeffs_certified_independent(r1, r2, config)


def build_quadratic_coeffs_noncertified_matched_depth(
    r1: BTNSNumber,
    r2: BTNSNumber,
    certified_final_k_min: int,
    config: CampaignConfig,
    certified_result: Optional[CertifiedPolynomialResult] = None,
) -> MatchedDepthPolynomialResult:
    return build_polynomial_coeffs_noncertified_matched_depth([r1, r2], certified_final_k_min, config, certified_result)


def coefficient_digit_table(result: PolynomialResult) -> Tuple[Tuple[int, str, str, str], ...]:
    rows = []
    for idx, coeff in enumerate(result.coefficients):
        rows.append((idx, coeff.trace_id or "NO_TRACE", coeff.wfc_status or "", digit_string_kmax_to_kmin(coeff)))
    return tuple(rows)


__all__ = [
    "MODE_NONCERTIFIED",
    "MODE_CERTIFIED",
    "MODE_NONCERTIFIED_MATCHED_DEPTH",
    "STATUS_OK",
    "STATUS_FAILED",
    "CERT_ACCEPT",
    "CERT_REFINE",
    "CERT_REFINE_REQUEST",
    "CERT_REBUILD",
    "CERT_TUBE_HOLD",
    "CERT_REJECT",
    "MATCHED_DEPTH_EQUAL",
    "MATCHED_DEPTH_DIFFERENT",
    "MATCHED_DEPTH_NOT_RUN_INVALID",
    "CampaignConfig",
    "OperationCertificate",
    "CertifiedCandidateSelection",
    "PolynomialStepTrace",
    "CertifiedDecisionRecord",
    "MatchedDepthComparisonRecord",
    "PolynomialResult",
    "CertifiedPolynomialResult",
    "MatchedDepthPolynomialResult",
    "build_polynomial_coeffs_noncertified",
    "build_polynomial_coeffs_certified_independent",
    "build_polynomial_coeffs_certified",
    "build_polynomial_coeffs_noncertified_matched_depth",
    "build_quadratic_coeffs_noncertified",
    "build_quadratic_coeffs_certified_independent",
    "build_quadratic_coeffs_certified",
    "build_quadratic_coeffs_noncertified_matched_depth",
    "coefficient_digit_table",
]


if __name__ == "__main__":
    cfg = CampaignConfig(k_min=0, k_max=0, trace_prefix="SELFTEST_V28", wfc_window_width=0, wfc_policy=RN_ZERO)
    one = make_btns_number_from_digits({0: 1}, 0, 0, source_tag=SOURCE_TEST, trace_id="r1")
    two = add_btns(one, one)

    noncert = build_quadratic_coeffs_noncertified(one, two, cfg)
    cert = build_quadratic_coeffs_certified_independent(one, two, cfg)
    matched = build_quadratic_coeffs_noncertified_matched_depth(one, two, cfg.k_min, cfg, cert)

    assert noncert.m == 2
    assert cert.m == 2
    assert matched.m == 2
    assert len(cert.certified_decision_chain) > 0
    assert noncert.coefficients[1].trace_id != cert.coefficients[1].trace_id

    expected_a1 = make_btns_number_from_digits({1: -1}, 0, 1, source_tag=SOURCE_TEST, trace_id="expected_a1")
    expected_a2 = make_btns_number_from_digits({0: -1, 1: 1}, 0, 1, source_tag=SOURCE_TEST, trace_id="expected_a2")
    assert btns_equal_digits(noncert.coefficients[1], expected_a1)
    assert btns_equal_digits(noncert.coefficients[2], expected_a2)
    assert btns_equal_digits(cert.coefficients[1], expected_a1)
    assert btns_equal_digits(cert.coefficients[2], expected_a2)
    assert all(coeff.wfc_status is not None for coeff in noncert.coefficients)
    assert all(coeff.wfc_status is not None for coeff in cert.coefficients)
    print("btns_poly.py self-check PASS")
