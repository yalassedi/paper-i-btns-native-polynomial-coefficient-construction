"""
run_wfc_ablation.py

WFC ablation runner for PythonApplication157 under Script Contract v28.

This module executes the required WFC ablation branches for the first-stage
m = 2 BTNS polynomial package.  It is a campaign/evidence runner, not a core
arithmetic module:

    - it does not implement BTNS arithmetic;
    - it does not select WFC candidates directly;
    - it delegates coefficient construction to btns_poly.py;
    - it delegates WFC execution to canonize_btns() -> strict_wfc();
    - it may use gold_reference.py only after construction for evaluation;
    - it may write JSON/CSV evidence sidecars for reporting.

Required v28 branch tokens:

    A0_CANONIZE_ONLY_BASELINE
    A1_FULL_WFC_RN_ZERO_MAIN_WINDOW
    A2_FULL_WFC_RN_EVEN_MAIN_WINDOW
    A3_FULL_WFC_SMALLER_WINDOW
    A4_FULL_WFC_LARGER_WINDOW
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import csv
import json
from pathlib import Path
from typing import Iterable, Mapping, Optional, Sequence, Tuple

from btns_core import BTNSNumber, btns_equal_digits, validate_digits
from btns_poly import (
    CampaignConfig,
    PolynomialResult,
    CertifiedPolynomialResult,
    MatchedDepthPolynomialResult,
    MATCHED_DEPTH_EQUAL,
    MATCHED_DEPTH_DIFFERENT,
    MATCHED_DEPTH_NOT_RUN_INVALID,
    build_polynomial_coeffs_noncertified,
    build_polynomial_coeffs_certified_independent,
    build_polynomial_coeffs_noncertified_matched_depth,
)
from btns_wfc import (
    RN_ZERO,
    RN_EVEN,
    WFC_NOT_APPLICABLE,
    WFC_TIE_RESOLVED_RN_ZERO,
    WFC_TIE_RESOLVED_RN_EVEN,
    WFC_UNDEFINED_STRICT_EMPTY,
    validate_wfc_trace,
)
from gold_reference import (
    GoldPolynomialReference,
    build_gold_polynomial_from_root_strings,
    compare_coefficients_to_gold,
)
from ingress import DEFAULT_ROUNDING_POLICY, parse_decimal_string_to_btns_with_trace


# Required v28 branch IDs.
A0_CANONIZE_ONLY_BASELINE = "A0_CANONIZE_ONLY_BASELINE"
A1_FULL_WFC_RN_ZERO_MAIN_WINDOW = "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW"
A2_FULL_WFC_RN_EVEN_MAIN_WINDOW = "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW"
A3_FULL_WFC_SMALLER_WINDOW = "A3_FULL_WFC_SMALLER_WINDOW"
A4_FULL_WFC_LARGER_WINDOW = "A4_FULL_WFC_LARGER_WINDOW"

REQUIRED_WFC_ABLATION_BRANCHES = (
    A0_CANONIZE_ONLY_BASELINE,
    A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
    A2_FULL_WFC_RN_EVEN_MAIN_WINDOW,
    A3_FULL_WFC_SMALLER_WINDOW,
    A4_FULL_WFC_LARGER_WINDOW,
)

TRUE = "TRUE"
TUBE = "TUBE"
FALSE = "FALSE"

IMPROVED = "IMPROVED"
EQUAL = "EQUAL"
WORSE = "WORSE"

WFC_ABLATION_BRANCH_COMPLETE = "WFC_ABLATION_BRANCH_COMPLETE"
WFC_ABLATION_BRANCH_FAILED = "WFC_ABLATION_BRANCH_FAILED"
WFC_NO_OBSERVED_EFFECT = "WFC_NO_OBSERVED_EFFECT"
WFC_WINDOW_SENSITIVITY_DETECTED = "WFC_WINDOW_SENSITIVITY_DETECTED"
WFC_POLICY_SENSITIVITY_DETECTED = "WFC_POLICY_SENSITIVITY_DETECTED"


@dataclass(frozen=True)
class WFCAblationBranchConfig:
    branch_id: str
    wfc_enabled: bool
    window_width: Optional[int]
    policy: Optional[str]
    canonize_each_stage: bool
    notes: str = ""

    def __post_init__(self) -> None:
        if self.branch_id not in REQUIRED_WFC_ABLATION_BRANCHES:
            raise ValueError(f"unregistered WFC ablation branch_id: {self.branch_id}")
        if not isinstance(self.wfc_enabled, bool):
            raise TypeError("wfc_enabled must be bool")
        if self.window_width is not None:
            if not isinstance(self.window_width, int):
                raise TypeError("window_width must be int or None")
            if self.window_width < 0:
                raise ValueError("window_width must be non-negative")
        if self.policy is not None and self.policy not in (RN_ZERO, RN_EVEN):
            raise ValueError("policy must be RN_ZERO, RN_EVEN, or None")
        if not isinstance(self.canonize_each_stage, bool):
            raise TypeError("canonize_each_stage must be bool")
        if not isinstance(self.notes, str):
            raise TypeError("notes must be str")

    def as_dict(self) -> dict[str, object]:
        return {
            "branch_id": self.branch_id,
            "wfc_enabled": self.wfc_enabled,
            "window_width": self.window_width,
            "policy": self.policy,
            "canonize_each_stage": self.canonize_each_stage,
            "notes": self.notes,
        }


@dataclass(frozen=True)
class WFCAblationBranchResult:
    branch_config: WFCAblationBranchConfig
    noncertified_result: Optional[PolynomialResult]
    certified_result: Optional[CertifiedPolynomialResult]
    matched_result: Optional[MatchedDepthPolynomialResult]
    status: str
    message: str


@dataclass(frozen=True)
class WFCAblationSummaryRecord:
    branch_id: str
    wfc_enabled: bool
    window_width: Optional[int]
    policy: Optional[str]
    candidate_count_total: int
    strict_candidate_count_total: int
    strict_empty_count: int
    tie_resolved_count: int
    undefined_count: int
    # Backward-compatible v28 column names are kept, but these counts are
    # exact-gold diagnostics, not UCC decision-state counts.  The explicit
    # semantic columns below are emitted to prevent reviewer confusion with
    # TRUE/TUBE/FALSE used by the UCC layer.
    TRUE_count: int
    TUBE_count: int
    FALSE_count: int
    gold_count_semantics: str
    exact_gold_zero_error_count: int
    exact_gold_unavailable_count: int
    exact_gold_nonzero_error_count: int
    IMPROVED_count: int
    EQUAL_count: int
    WORSE_count: int
    matched_depth_EQUAL_count: int
    matched_depth_DIFFERENT_count: int
    matched_depth_NOT_RUN_INVALID_count: int
    final_depth_distribution: str
    branch_status: str
    branch_message: str

    def as_dict(self) -> dict[str, object]:
        return {
            "branch_id": self.branch_id,
            "wfc_enabled": self.wfc_enabled,
            "window_width": self.window_width,
            "policy": self.policy,
            "candidate_count_total": self.candidate_count_total,
            "strict_candidate_count_total": self.strict_candidate_count_total,
            "strict_empty_count": self.strict_empty_count,
            "tie_resolved_count": self.tie_resolved_count,
            "undefined_count": self.undefined_count,
            "gold_count_semantics": self.gold_count_semantics,
            "exact_gold_zero_error_count": self.exact_gold_zero_error_count,
            "exact_gold_unavailable_count": self.exact_gold_unavailable_count,
            "exact_gold_nonzero_error_count": self.exact_gold_nonzero_error_count,
            # Legacy v28 field names retained as exact-gold aliases only.
            "TRUE_count": self.TRUE_count,
            "TUBE_count": self.TUBE_count,
            "FALSE_count": self.FALSE_count,
            "IMPROVED_count": self.IMPROVED_count,
            "EQUAL_count": self.EQUAL_count,
            "WORSE_count": self.WORSE_count,
            "matched_depth_EQUAL_count": self.matched_depth_EQUAL_count,
            "matched_depth_DIFFERENT_count": self.matched_depth_DIFFERENT_count,
            "matched_depth_NOT_RUN_INVALID_count": self.matched_depth_NOT_RUN_INVALID_count,
            "final_depth_distribution": self.final_depth_distribution,
            "branch_status": self.branch_status,
            "branch_message": self.branch_message,
        }


@dataclass(frozen=True)
class WFCAblationRunResult:
    m: int
    base_config: CampaignConfig
    branch_results: Tuple[WFCAblationBranchResult, ...]
    summary_records: Tuple[WFCAblationSummaryRecord, ...]
    window_sensitivity_token: str
    policy_sensitivity_token: str

    def as_dict(self) -> dict[str, object]:
        return {
            "m": self.m,
            "base_config": {
                "k_min": self.base_config.k_min,
                "k_max": self.base_config.k_max,
                "trace_prefix": self.base_config.trace_prefix,
                "wfc_window_width": self.base_config.wfc_window_width,
                "wfc_policy": self.base_config.wfc_policy,
                "wfc_boundary_mode": self.base_config.wfc_boundary_mode,
            },
            "branch_configs": [item.branch_config.as_dict() for item in self.branch_results],
            "summary_records": [item.as_dict() for item in self.summary_records],
            "window_sensitivity_token": self.window_sensitivity_token,
            "policy_sensitivity_token": self.policy_sensitivity_token,
        }


def _max_supported_window_from_config(config: CampaignConfig) -> int:
    if config.k_min < 0:
        return -config.k_min
    return 0


def _clamp_window(width: int, config: CampaignConfig) -> int:
    if width < 0:
        return 0
    max_supported = _max_supported_window_from_config(config)
    return min(width, max_supported)


def make_default_ablation_branch_configs(base_config: CampaignConfig) -> Tuple[WFCAblationBranchConfig, ...]:
    """Return the five v28-required WFC ablation branches."""

    if not isinstance(base_config, CampaignConfig):
        raise TypeError("base_config must be CampaignConfig")

    main_width = _clamp_window(base_config.wfc_window_width, base_config)
    smaller_width = _clamp_window(max(0, main_width // 2), base_config)
    larger_request = main_width + 1 if main_width == 0 else 2 * main_width
    larger_width = _clamp_window(larger_request, base_config)

    return (
        WFCAblationBranchConfig(
            branch_id=A0_CANONIZE_ONLY_BASELINE,
            wfc_enabled=False,
            window_width=None,
            policy=None,
            canonize_each_stage=False,
            notes="Canonize-only baseline: WFC disabled and explicitly reported as not applicable.",
        ),
        WFCAblationBranchConfig(
            branch_id=A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
            wfc_enabled=True,
            window_width=main_width,
            policy=RN_ZERO,
            canonize_each_stage=True,
            notes="Full strict WFC with RN_ZERO at the main window.",
        ),
        WFCAblationBranchConfig(
            branch_id=A2_FULL_WFC_RN_EVEN_MAIN_WINDOW,
            wfc_enabled=True,
            window_width=main_width,
            policy=RN_EVEN,
            canonize_each_stage=True,
            notes="Full strict WFC with RN_EVEN at the main window.",
        ),
        WFCAblationBranchConfig(
            branch_id=A3_FULL_WFC_SMALLER_WINDOW,
            wfc_enabled=True,
            window_width=smaller_width,
            policy=base_config.wfc_policy,
            canonize_each_stage=True,
            notes="Full strict WFC with a smaller/clamped window.",
        ),
        WFCAblationBranchConfig(
            branch_id=A4_FULL_WFC_LARGER_WINDOW,
            wfc_enabled=True,
            window_width=larger_width,
            policy=base_config.wfc_policy,
            canonize_each_stage=True,
            notes="Full strict WFC with a larger/clamped window.",
        ),
    )


def _config_for_branch(base_config: CampaignConfig, branch: WFCAblationBranchConfig) -> CampaignConfig:
    return replace(
        base_config,
        canonize_each_stage=branch.canonize_each_stage,
        trace_prefix=f"{base_config.trace_prefix}:{branch.branch_id}",
        wfc_window_width=0 if branch.window_width is None else branch.window_width,
        wfc_policy=base_config.wfc_policy if branch.policy is None else branch.policy,
    )


def _require_roots(roots: Sequence[BTNSNumber]) -> Tuple[BTNSNumber, ...]:
    if not roots:
        raise ValueError("roots must not be empty")
    checked = []
    for idx, root in enumerate(roots, start=1):
        if not isinstance(root, BTNSNumber) or not validate_digits(root):
            raise ValueError(f"root {idx} is not a legal BTNSNumber")
        checked.append(root)
    return tuple(checked)


def _all_wfc_results(branch_result: WFCAblationBranchResult):
    for result in (branch_result.noncertified_result, branch_result.certified_result, branch_result.matched_result):
        if result is None:
            continue
        for wfc_result in result.wfc_results:
            yield wfc_result


def _count_wfc_metrics(branch_result: WFCAblationBranchResult) -> tuple[int, int, int, int, int]:
    candidate_total = 0
    strict_total = 0
    strict_empty = 0
    tie_resolved = 0
    undefined = 0
    for wfc_result in _all_wfc_results(branch_result):
        if not validate_wfc_trace(wfc_result.trace, wfc_result.candidates):
            undefined += 1
        candidate_total += wfc_result.trace.candidate_count
        strict_total += wfc_result.trace.strict_candidate_count
        if wfc_result.trace.wfc_status == WFC_UNDEFINED_STRICT_EMPTY:
            strict_empty += 1
            undefined += 1
        if wfc_result.trace.wfc_status in (WFC_TIE_RESOLVED_RN_ZERO, WFC_TIE_RESOLVED_RN_EVEN):
            tie_resolved += 1
    return candidate_total, strict_total, strict_empty, tie_resolved, undefined


def _gold_counts(coefficients: Sequence[BTNSNumber], gold_reference: Optional[GoldPolynomialReference]) -> tuple[int, int, int]:
    if gold_reference is None:
        return 0, len(coefficients), 0
    rows = compare_coefficients_to_gold(coefficients, gold_reference.coefficients)
    true_count = sum(1 for row in rows if row.abs_error_numerator == 0)
    false_count = sum(1 for row in rows if row.abs_error_numerator != 0)
    return true_count, 0, false_count


def _absolute_errors(coefficients: Sequence[BTNSNumber], gold_reference: Optional[GoldPolynomialReference]):
    if gold_reference is None:
        return None
    rows = compare_coefficients_to_gold(coefficients, gold_reference.coefficients)
    from fractions import Fraction

    return tuple(Fraction(row.abs_error_numerator, row.abs_error_denominator) for row in rows)


def _advantage_counts(
    coefficients: Sequence[BTNSNumber],
    reference_coefficients: Sequence[BTNSNumber],
    gold_reference: Optional[GoldPolynomialReference],
) -> tuple[int, int, int]:
    if gold_reference is not None:
        branch_errors = _absolute_errors(coefficients, gold_reference)
        ref_errors = _absolute_errors(reference_coefficients, gold_reference)
        if branch_errors is None or ref_errors is None:
            return 0, 0, 0
        improved = equal = worse = 0
        for current, ref in zip(branch_errors, ref_errors):
            if current < ref:
                improved += 1
            elif current == ref:
                equal += 1
            else:
                worse += 1
        return improved, equal, worse

    equal = sum(1 for a, b in zip(coefficients, reference_coefficients) if btns_equal_digits(a, b))
    return 0, equal, 0


def _matched_counts(matched: Optional[MatchedDepthPolynomialResult]) -> tuple[int, int, int]:
    if matched is None:
        return 0, 0, 0
    equal = sum(1 for row in matched.matched_depth_records if row.matched_depth_comparison == MATCHED_DEPTH_EQUAL)
    different = sum(1 for row in matched.matched_depth_records if row.matched_depth_comparison == MATCHED_DEPTH_DIFFERENT)
    invalid = sum(1 for row in matched.matched_depth_records if row.matched_depth_comparison == MATCHED_DEPTH_NOT_RUN_INVALID)
    return equal, different, invalid


def _depth_distribution(result: Optional[PolynomialResult]) -> str:
    if result is None:
        return "NONE"
    counts: dict[int, int] = {}
    for coeff in result.coefficients:
        counts[coeff.k_min] = counts.get(coeff.k_min, 0) + 1
    return ";".join(f"{k}:{counts[k]}" for k in sorted(counts))


def _run_branch(
    roots: Tuple[BTNSNumber, ...],
    base_config: CampaignConfig,
    branch: WFCAblationBranchConfig,
) -> WFCAblationBranchResult:
    branch_config = _config_for_branch(base_config, branch)
    try:
        noncertified = build_polynomial_coeffs_noncertified(roots, branch_config)
        certified = build_polynomial_coeffs_certified_independent(roots, branch_config)
        # In the present m=2 package there is no adaptive rebuild yet, so the
        # final certified depth is the branch config k_min.  Future adaptive
        # logic can replace this one line with the certified final depth.
        certified_final_k_min = branch_config.k_min
        matched = build_polynomial_coeffs_noncertified_matched_depth(
            roots,
            certified_final_k_min=certified_final_k_min,
            config=branch_config,
            certified_result=certified,
        )
        return WFCAblationBranchResult(
            branch_config=branch,
            noncertified_result=noncertified,
            certified_result=certified,
            matched_result=matched,
            status=WFC_ABLATION_BRANCH_COMPLETE,
            message="branch completed",
        )
    except Exception as exc:  # pragma: no cover - defensive branch failure path
        return WFCAblationBranchResult(
            branch_config=branch,
            noncertified_result=None,
            certified_result=None,
            matched_result=None,
            status=WFC_ABLATION_BRANCH_FAILED,
            message=f"{type(exc).__name__}: {exc}",
        )


def _summary_for_branch(
    branch_result: WFCAblationBranchResult,
    reference_coefficients: Sequence[BTNSNumber],
    gold_reference: Optional[GoldPolynomialReference],
) -> WFCAblationSummaryRecord:
    candidate_total, strict_total, strict_empty, tie_resolved, undefined = _count_wfc_metrics(branch_result)
    coeffs = tuple() if branch_result.noncertified_result is None else branch_result.noncertified_result.coefficients
    true_count, tube_count, false_count = _gold_counts(coeffs, gold_reference)
    improved, equal, worse = _advantage_counts(coeffs, reference_coefficients, gold_reference)
    matched_equal, matched_diff, matched_invalid = _matched_counts(branch_result.matched_result)
    return WFCAblationSummaryRecord(
        branch_id=branch_result.branch_config.branch_id,
        wfc_enabled=branch_result.branch_config.wfc_enabled,
        window_width=branch_result.branch_config.window_width,
        policy=branch_result.branch_config.policy,
        candidate_count_total=candidate_total,
        strict_candidate_count_total=strict_total,
        strict_empty_count=strict_empty,
        tie_resolved_count=tie_resolved,
        undefined_count=undefined,
        TRUE_count=true_count,
        TUBE_count=tube_count,
        FALSE_count=false_count,
        gold_count_semantics="EXACT_GOLD_DIAGNOSTIC_NOT_UCC_DECISION",
        exact_gold_zero_error_count=true_count,
        exact_gold_unavailable_count=tube_count,
        exact_gold_nonzero_error_count=false_count,
        IMPROVED_count=improved,
        EQUAL_count=equal,
        WORSE_count=worse,
        matched_depth_EQUAL_count=matched_equal,
        matched_depth_DIFFERENT_count=matched_diff,
        matched_depth_NOT_RUN_INVALID_count=matched_invalid,
        final_depth_distribution=_depth_distribution(branch_result.certified_result),
        branch_status=branch_result.status,
        branch_message=branch_result.message,
    )


def _branch_by_id(results: Sequence[WFCAblationBranchResult], branch_id: str) -> Optional[WFCAblationBranchResult]:
    for item in results:
        if item.branch_config.branch_id == branch_id:
            return item
    return None


def _coefficients_of(result: Optional[WFCAblationBranchResult]) -> Tuple[BTNSNumber, ...]:
    if result is None or result.noncertified_result is None:
        return tuple()
    return result.noncertified_result.coefficients


def _sensitivity_tokens(results: Sequence[WFCAblationBranchResult]) -> tuple[str, str]:
    main = _coefficients_of(_branch_by_id(results, A1_FULL_WFC_RN_ZERO_MAIN_WINDOW))
    even = _coefficients_of(_branch_by_id(results, A2_FULL_WFC_RN_EVEN_MAIN_WINDOW))
    small = _coefficients_of(_branch_by_id(results, A3_FULL_WFC_SMALLER_WINDOW))
    large = _coefficients_of(_branch_by_id(results, A4_FULL_WFC_LARGER_WINDOW))

    policy_sensitive = False
    if main and even and len(main) == len(even):
        policy_sensitive = any(not btns_equal_digits(a, b) for a, b in zip(main, even))

    window_sensitive = False
    for other in (small, large):
        if main and other and len(main) == len(other):
            if any(not btns_equal_digits(a, b) for a, b in zip(main, other)):
                window_sensitive = True

    return (
        WFC_WINDOW_SENSITIVITY_DETECTED if window_sensitive else WFC_NO_OBSERVED_EFFECT,
        WFC_POLICY_SENSITIVITY_DETECTED if policy_sensitive else WFC_NO_OBSERVED_EFFECT,
    )


def run_wfc_ablation(
    roots: Sequence[BTNSNumber],
    base_config: CampaignConfig,
    *,
    branch_configs: Optional[Sequence[WFCAblationBranchConfig]] = None,
    gold_reference: Optional[GoldPolynomialReference] = None,
) -> WFCAblationRunResult:
    """Execute the v28-required WFC ablation branches for one root set."""

    checked_roots = _require_roots(roots)
    configs = tuple(branch_configs) if branch_configs is not None else make_default_ablation_branch_configs(base_config)
    branch_ids = {cfg.branch_id for cfg in configs}
    missing = [item for item in REQUIRED_WFC_ABLATION_BRANCHES if item not in branch_ids]
    if missing:
        raise ValueError(f"missing required WFC ablation branches: {missing}")

    branch_results = tuple(_run_branch(checked_roots, base_config, cfg) for cfg in configs)
    main_branch = _branch_by_id(branch_results, A1_FULL_WFC_RN_ZERO_MAIN_WINDOW)
    baseline_coefficients = _coefficients_of(main_branch)
    if not baseline_coefficients:
        # Fallback to the first successful branch, if the main branch failed.
        for branch in branch_results:
            baseline_coefficients = _coefficients_of(branch)
            if baseline_coefficients:
                break
    summary_records = tuple(
        _summary_for_branch(branch_result, baseline_coefficients, gold_reference) for branch_result in branch_results
    )
    window_token, policy_token = _sensitivity_tokens(branch_results)
    return WFCAblationRunResult(
        m=len(checked_roots),
        base_config=base_config,
        branch_results=branch_results,
        summary_records=summary_records,
        window_sensitivity_token=window_token,
        policy_sensitivity_token=policy_token,
    )


def run_wfc_ablation_from_root_strings(
    root_strings: Sequence[str],
    *,
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str = DEFAULT_ROUNDING_POLICY,
    trace_prefix: str = "WFC_ABLATION_INGRESS",
    base_config: Optional[CampaignConfig] = None,
    build_gold: bool = True,
) -> WFCAblationRunResult:
    """Ingress root strings, then execute WFC ablation.

    Decimal strings are used only at the ingress/gold boundaries.  The actual
    coefficient construction receives BTNSNumber roots only.
    """

    roots = []
    for idx, root_string in enumerate(root_strings, start=1):
        result = parse_decimal_string_to_btns_with_trace(
            root_string,
            k_min=k_min,
            k_max=k_max,
            rounding_policy=rounding_policy,
            trace_id=f"{trace_prefix}:{idx}",
            group_id="ABLATION",
            root_index=idx,
        )
        roots.append(result.number)
    if base_config is None:
        base_config = CampaignConfig(
            k_min=k_min,
            k_max=k_max,
            trace_prefix="WFC_ABLATION",
            wfc_window_width=_clamp_window(1, CampaignConfig(k_min=k_min, k_max=k_max)),
            wfc_policy=RN_ZERO,
        )
    gold_ref = build_gold_polynomial_from_root_strings(root_strings, m=len(root_strings)) if build_gold else None
    return run_wfc_ablation(tuple(roots), base_config, gold_reference=gold_ref)


def write_wfc_ablation_outputs(run: WFCAblationRunResult, output_dir: str | Path) -> Mapping[str, str]:
    """Write required v28 WFC ablation sidecars."""

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    config_path = out / "wfc_ablation_config.json"
    summary_path = out / "wfc_ablation_summary.csv"
    window_path = out / "wfc_window_sensitivity.csv"
    policy_path = out / "wfc_tie_policy_ablation.csv"

    config_payload = {
        "m": run.m,
        "base_config": run.as_dict()["base_config"],
        "branches": [item.branch_config.as_dict() for item in run.branch_results],
        "required_branches": list(REQUIRED_WFC_ABLATION_BRANCHES),
    }
    config_path.write_text(json.dumps(config_payload, indent=2, sort_keys=True), encoding="utf-8")

    rows = [record.as_dict() for record in run.summary_records]
    if rows:
        with summary_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    else:
        summary_path.write_text("", encoding="utf-8")

    with window_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["token", "reference_branch", "compared_branches"])
        writer.writeheader()
        writer.writerow(
            {
                "token": run.window_sensitivity_token,
                "reference_branch": A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
                "compared_branches": f"{A3_FULL_WFC_SMALLER_WINDOW};{A4_FULL_WFC_LARGER_WINDOW}",
            }
        )

    with policy_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["token", "rn_zero_branch", "rn_even_branch"])
        writer.writeheader()
        writer.writerow(
            {
                "token": run.policy_sensitivity_token,
                "rn_zero_branch": A1_FULL_WFC_RN_ZERO_MAIN_WINDOW,
                "rn_even_branch": A2_FULL_WFC_RN_EVEN_MAIN_WINDOW,
            }
        )

    return {
        "wfc_ablation_config.json": str(config_path),
        "wfc_ablation_summary.csv": str(summary_path),
        "wfc_window_sensitivity.csv": str(window_path),
        "wfc_tie_policy_ablation.csv": str(policy_path),
    }


def summary_records_as_dicts(run: WFCAblationRunResult) -> Tuple[dict[str, object], ...]:
    return tuple(record.as_dict() for record in run.summary_records)


__all__ = [
    "A0_CANONIZE_ONLY_BASELINE",
    "A1_FULL_WFC_RN_ZERO_MAIN_WINDOW",
    "A2_FULL_WFC_RN_EVEN_MAIN_WINDOW",
    "A3_FULL_WFC_SMALLER_WINDOW",
    "A4_FULL_WFC_LARGER_WINDOW",
    "REQUIRED_WFC_ABLATION_BRANCHES",
    "TRUE",
    "TUBE",
    "FALSE",
    "IMPROVED",
    "EQUAL",
    "WORSE",
    "WFC_ABLATION_BRANCH_COMPLETE",
    "WFC_ABLATION_BRANCH_FAILED",
    "WFC_NO_OBSERVED_EFFECT",
    "WFC_WINDOW_SENSITIVITY_DETECTED",
    "WFC_POLICY_SENSITIVITY_DETECTED",
    "WFCAblationBranchConfig",
    "WFCAblationBranchResult",
    "WFCAblationSummaryRecord",
    "WFCAblationRunResult",
    "make_default_ablation_branch_configs",
    "run_wfc_ablation",
    "run_wfc_ablation_from_root_strings",
    "write_wfc_ablation_outputs",
    "summary_records_as_dicts",
]


if __name__ == "__main__":
    result = run_wfc_ablation_from_root_strings(
        ("1", "2"),
        k_min=-1,
        k_max=1,
        rounding_policy=DEFAULT_ROUNDING_POLICY,
        build_gold=True,
    )
    assert len(result.summary_records) == 5
    assert {row.branch_id for row in result.summary_records} == set(REQUIRED_WFC_ABLATION_BRANCHES)
    assert all(row.branch_status == WFC_ABLATION_BRANCH_COMPLETE for row in result.summary_records)
    print("run_wfc_ablation.py self-check PASS")
