"""
run_m10_campaign.py

Ninth-stage m = 10 campaign runner for PythonApplication157 under Script
Contract v28.

This runner coordinates already validated boundary and construction modules. It
is an evidence/campaign layer, not a new arithmetic implementation:
    - roots enter through ingress.py only;
    - coefficient construction is delegated to btns_poly.py;
    - WFC execution is delegated to canonize_btns() -> strict_wfc();
    - Certified governance/comparison is delegated to btns_certified.py;
    - external gold is used only after construction;
    - reporting.py writes workbook-ready tables and sidecars;
    - audit.py verifies the construction boundary and WFC discipline.

The runner produces the v28 m = 10 evidence package.

Consolidation note: in this cleaned package, this file is the single production
campaign runner for the current degree stage. Earlier degree-specific campaign
runners were removed from the distributable package; sample_roots_m10.csv is a
superset root file whose first m rows per group can still support lower-degree
smoke checks through ingress.select_roots_for_m(...).
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, is_dataclass
from datetime import datetime, timezone
from hashlib import sha256
import argparse
import csv
import json
import platform
from pathlib import Path
import sys
import tempfile
from time import perf_counter
import zipfile
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple
from xml.sax.saxutils import escape

import audit
import btns_certified as certified
from btns_core import BTNSNumber, btns_equal_digits, validate_digits
from btns_poly import (
    CampaignConfig,
    PolynomialResult,
    CertifiedPolynomialResult,
    MatchedDepthPolynomialResult,
    MATCHED_DEPTH_EQUAL,
    MATCHED_DEPTH_NOT_RUN_INVALID,
    build_polynomial_coeffs_noncertified,
    build_polynomial_coeffs_certified_independent,
    build_polynomial_coeffs_noncertified_matched_depth,
)
from btns_wfc import RN_ZERO
import gold_reference as gold
import ingress
import reporting
import run_wfc_ablation


CONTRACT_VERSION = "v28"
PACKAGE_NAME = "PythonApplication157"
REFERENCE_LABEL = "PythonApplication_BTNS_Native_v28_FULL_STRICT_WFC_MATCHED_DEPTH"
RUNNER_NAME = "run_m10_campaign.py"
M = 10
DEFAULT_K_MIN_GRID = (-20, -30, -40, -50)
DEFAULT_SMOKE_K_MIN_GRID = (-20,)
DEFAULT_WFC_WINDOW_WIDTH = 8
DEFAULT_REPORT_DECIMAL_DIGITS = 18
VALID_RUN = "VALID_RUN"
INVALID_RUN = "INVALID_RUN"
PROMOTABLE_RUN = "PROMOTABLE_RUN"
NON_PROMOTABLE_RUN = "NON_PROMOTABLE_RUN"


@dataclass(frozen=True)
class CaseResult:
    group_id: str
    k_min: int
    k_max: int
    root_rows: Tuple[ingress.RootInputRow, ...]
    ingress_results: Tuple[ingress.IngressResult, ...]
    root_strings: Tuple[str, ...]
    config: CampaignConfig
    noncertified_result: PolynomialResult
    certified_result: CertifiedPolynomialResult
    matched_result: MatchedDepthPolynomialResult
    gold_reference: gold.GoldPolynomialReference
    gold_comparisons_noncertified: Tuple[gold.GoldComparisonRecord, ...]
    gold_comparisons_certified: Tuple[gold.GoldComparisonRecord, ...]
    gold_comparisons_matched: Tuple[gold.GoldComparisonRecord, ...]
    gold_summary_noncertified: gold.GoldSummary
    gold_summary_certified: gold.GoldSummary
    certified_path_comparisons: Tuple[certified.PathComparisonRecord, ...]
    matched_governance_records: Tuple[certified.MatchedDepthGovernanceRecord, ...]
    ablation_run: run_wfc_ablation.WFCAblationRunResult
    runtime_seconds: float = 0.0


@dataclass(frozen=True)
class CampaignRunResult:
    cases: Tuple[CaseResult, ...]
    audit_report: audit.AuditReport
    run_status: str
    promotion_status: str
    manifest: Mapping[str, Any]
    settings_signature: Mapping[str, Any]
    workbook_bundle: reporting.ReportingBundle
    output_dir: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_count": len(self.cases),
            "run_status": self.run_status,
            "promotion_status": self.promotion_status,
            "manifest": dict(self.manifest),
            "settings_signature": dict(self.settings_signature),
            "output_dir": self.output_dir,
        }


# ---------------------------------------------------------------------------
# General helpers
# ---------------------------------------------------------------------------


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _write_json(path: str | Path, payload: Any) -> None:
    Path(path).write_text(json.dumps(_json_safe(payload), indent=2, sort_keys=True), encoding="utf-8")


def _write_csv(path: str | Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    columns: list[str] = []
    for row in rows:
        for key in row.keys():
            text = str(key)
            if text not in columns:
                columns.append(text)
    with path.open("w", encoding="utf-8", newline="") as handle:
        if not columns:
            handle.write("")
            return
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _json_safe(row.get(key, "")) for key in columns})


def _write_csv_with_header(path: str | Path, fieldnames: Sequence[str]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames))
        writer.writeheader()


def _sha256_bytes(data: bytes) -> str:
    return sha256(data).hexdigest()


def _sha256_text(text: str) -> str:
    return _sha256_bytes(text.encode("utf-8"))


def _hash_file(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return "MISSING"
    h = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _hash_mapping(payload: Any) -> str:
    return _sha256_text(json.dumps(_json_safe(payload), sort_keys=True, separators=(",", ":")))


def _script_hashes(root: Path) -> dict[str, str]:
    filenames = (
        "btns_wfc.py",
        "btns_core.py",
        "btns_poly.py",
        "btns_certified.py",
        "ingress.py",
        "egress.py",
        "gold_reference.py",
        "audit.py",
        "reporting.py",
        "run_wfc_ablation.py",
        "run_m10_campaign.py",
    )
    return {name: _hash_file(root / name) for name in filenames}


def _path_or_default(path: str | Path | None, default: str | Path) -> Path:
    return Path(default if path is None else path)


def _as_dict(item: Any) -> dict[str, Any]:
    if isinstance(item, Mapping):
        return dict(item)
    method = getattr(item, "as_dict", None)
    if callable(method):
        value = method()
        if not isinstance(value, Mapping):
            raise TypeError("as_dict() did not return a mapping")
        return dict(value)
    if is_dataclass(item):
        value = asdict(item)
        if not isinstance(value, Mapping):
            raise TypeError("asdict() did not return a mapping")
        return dict(value)
    raise TypeError(f"object is not reportable as dict: {type(item).__name__}")


def _with_context(row: Mapping[str, Any], *, group_id: str, k_min: int, path_label: str = "") -> dict[str, Any]:
    out = {"group_id": group_id, "k_min_case": k_min}
    if path_label:
        out["path_label_case"] = path_label
    out.update(dict(row))
    return out


def _group_rows(rows: Sequence[ingress.RootInputRow]) -> dict[str, Tuple[ingress.RootInputRow, ...]]:
    grouped: dict[str, list[ingress.RootInputRow]] = {}
    for row in rows:
        grouped.setdefault(row.group_id, []).append(row)
    return {gid: tuple(sorted(items, key=lambda item: item.root_index)) for gid, items in sorted(grouped.items())}


def _effective_wfc_window(k_min: int, requested: int) -> int:
    if k_min >= 0:
        return 0
    return min(max(0, requested), -k_min)


def _effective_k_max(root_rows: Sequence[ingress.RootInputRow], requested: Optional[int]) -> Optional[int]:
    if requested is not None:
        return requested
    inferred = 0
    for row in root_rows:
        inferred = max(inferred, ingress.infer_k_max_from_root_string(row.root_decimal_string))
    return inferred


def _coefficient_values_equal(a: Sequence[BTNSNumber], b: Sequence[BTNSNumber]) -> bool:
    if len(a) != len(b):
        return False
    return all(btns_equal_digits(x, y) for x, y in zip(a, b))


# ---------------------------------------------------------------------------
# Default sample input
# ---------------------------------------------------------------------------


def write_default_sample_roots(path: str | Path) -> str:
    """Write a small m=10-compatible CSV when no sample file is available."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [
        {"group_id": "G01", "root_index": 1, "root_decimal_string": "1", "active_for_m": "TRUE", "notes": "m=10 self-check root 1"},
        {"group_id": "G01", "root_index": 2, "root_decimal_string": "2", "active_for_m": "TRUE", "notes": "m=10 self-check root 2"},
        {"group_id": "G01", "root_index": 3, "root_decimal_string": "3", "active_for_m": "TRUE", "notes": "m=10 self-check root 3"},
        {"group_id": "G01", "root_index": 4, "root_decimal_string": "4", "active_for_m": "TRUE", "notes": "m=10 self-check root 4"},
        {"group_id": "G01", "root_index": 5, "root_decimal_string": "5", "active_for_m": "TRUE", "notes": "m=10 self-check root 5"},
        {"group_id": "G01", "root_index": 6, "root_decimal_string": "6", "active_for_m": "TRUE", "notes": "m=10 self-check root 6"},
        {"group_id": "G01", "root_index": 7, "root_decimal_string": "7", "active_for_m": "TRUE", "notes": "m=10 self-check root 7"},
        {"group_id": "G01", "root_index": 8, "root_decimal_string": "8", "active_for_m": "TRUE", "notes": "m=10 self-check root 8"},
        {"group_id": "G01", "root_index": 9, "root_decimal_string": "9", "active_for_m": "TRUE", "notes": "m=10 self-check root 9"},
        {"group_id": "G01", "root_index": 10, "root_decimal_string": "10", "active_for_m": "TRUE", "notes": "m=10 self-check root 10"},
        {"group_id": "G02", "root_index": 1, "root_decimal_string": "-1", "active_for_m": "TRUE", "notes": "m=10 self-check root 1"},
        {"group_id": "G02", "root_index": 2, "root_decimal_string": "0.5", "active_for_m": "TRUE", "notes": "m=10 self-check root 2"},
        {"group_id": "G02", "root_index": 3, "root_decimal_string": "1.25", "active_for_m": "TRUE", "notes": "m=10 self-check root 3"},
        {"group_id": "G02", "root_index": 4, "root_decimal_string": "-2.5", "active_for_m": "TRUE", "notes": "m=10 self-check root 4"},
        {"group_id": "G02", "root_index": 5, "root_decimal_string": "0.75", "active_for_m": "TRUE", "notes": "m=10 self-check root 5"},
        {"group_id": "G02", "root_index": 6, "root_decimal_string": "-0.125", "active_for_m": "TRUE", "notes": "m=10 self-check root 6"},
        {"group_id": "G02", "root_index": 7, "root_decimal_string": "0.375", "active_for_m": "TRUE", "notes": "m=10 self-check root 7"},
        {"group_id": "G02", "root_index": 8, "root_decimal_string": "-0.0625", "active_for_m": "TRUE", "notes": "m=10 self-check root 8"},
        {"group_id": "G02", "root_index": 9, "root_decimal_string": "0.03125", "active_for_m": "TRUE", "notes": "m=10 self-check root 9"},
        {"group_id": "G02", "root_index": 10, "root_decimal_string": "-0.015625", "active_for_m": "TRUE", "notes": "m=10 self-check root 10"},
    ]
    _write_csv(path, rows)
    return str(path)


# ---------------------------------------------------------------------------
# Case execution
# ---------------------------------------------------------------------------


def run_case(
    *,
    group_id: str,
    group_rows: Sequence[ingress.RootInputRow],
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str,
    wfc_policy: str,
    wfc_window_width: int,
    report_decimal_digits: int,
) -> CaseResult:
    started_at = perf_counter()
    selected = ingress.select_roots_for_m(group_rows, m=M)
    selected_for_group = tuple(row for row in selected if row.group_id == group_id)
    if len(selected_for_group) != M:
        # select_roots_for_m is normally called with a single-group list here.
        selected_for_group = tuple(selected[:M])
    effective_k_max = _effective_k_max(selected_for_group, k_max)
    effective_window = _effective_wfc_window(k_min, wfc_window_width)

    ingress_results = ingress.ingress_roots_for_m(
        selected_for_group,
        m=M,
        k_min=k_min,
        k_max=effective_k_max,
        rounding_policy=rounding_policy,
        trace_prefix=f"M10:{group_id}:k{k_min}",
    )
    roots = tuple(item.number for item in ingress_results)
    root_strings = tuple(row.root_decimal_string for row in selected_for_group)

    config = CampaignConfig(
        k_min=k_min,
        k_max=effective_k_max,
        canonize_each_stage=True,
        trace_prefix=f"BTNS_M10:{group_id}:k{k_min}",
        wfc_window_width=effective_window,
        wfc_policy=wfc_policy,
    )

    noncert = build_polynomial_coeffs_noncertified(roots, config)
    cert = build_polynomial_coeffs_certified_independent(roots, config)
    # PythonApplication157 m=10 currently has no actual adaptive rebuild depth
    # escalation.  The certified final depth is therefore the current k_min.
    certified_final_k_min = config.k_min
    matched = build_polynomial_coeffs_noncertified_matched_depth(
        roots,
        certified_final_k_min=certified_final_k_min,
        config=config,
        certified_result=cert,
    )

    gold_ref = gold.build_gold_polynomial_from_root_strings(root_strings, m=M)
    gold_nc = gold.compare_coefficients_to_gold(noncert.coefficients, gold_ref.coefficients, digits=report_decimal_digits)
    gold_cert = gold.compare_coefficients_to_gold(cert.coefficients, gold_ref.coefficients, digits=report_decimal_digits)
    gold_matched = gold.compare_coefficients_to_gold(matched.coefficients, gold_ref.coefficients, digits=report_decimal_digits)
    summary_nc = gold.summarize_gold_comparisons(gold_nc)
    summary_cert = gold.summarize_gold_comparisons(gold_cert)

    path_records = certified.compare_certified_path_to_noncertified_path(cert, noncert)
    matched_governance = certified.compare_certified_path_to_matched_depth_noncertified_path(cert, matched)
    ablation_run = run_wfc_ablation.run_wfc_ablation(roots, config, gold_reference=gold_ref)

    return CaseResult(
        group_id=group_id,
        k_min=k_min,
        k_max=effective_k_max if effective_k_max is not None else 0,
        root_rows=selected_for_group,
        ingress_results=ingress_results,
        root_strings=root_strings,
        config=config,
        noncertified_result=noncert,
        certified_result=cert,
        matched_result=matched,
        gold_reference=gold_ref,
        gold_comparisons_noncertified=gold_nc,
        gold_comparisons_certified=gold_cert,
        gold_comparisons_matched=gold_matched,
        gold_summary_noncertified=summary_nc,
        gold_summary_certified=summary_cert,
        certified_path_comparisons=path_records,
        matched_governance_records=matched_governance,
        ablation_run=ablation_run,
        runtime_seconds=perf_counter() - started_at,
    )


# ---------------------------------------------------------------------------
# Evidence aggregation
# ---------------------------------------------------------------------------


def _case_summary_row(case: CaseResult) -> dict[str, Any]:
    noncert_equal_cert = _coefficient_values_equal(case.noncertified_result.coefficients, case.certified_result.coefficients)
    cert_equal_matched = _coefficient_values_equal(case.certified_result.coefficients, case.matched_result.coefficients)
    distinct_count = sum(
        1
        for row in case.certified_path_comparisons
        if row.path_comparison_token == certified.CERT_PATH_DISTINCT_FROM_NONCERT
    )
    matched_equal = sum(1 for row in case.matched_governance_records if row.matched_depth_comparison == MATCHED_DEPTH_EQUAL)
    matched_invalid = sum(1 for row in case.matched_governance_records if row.matched_depth_comparison == MATCHED_DEPTH_NOT_RUN_INVALID)
    return {
        "group_id": case.group_id,
        "k_min": case.k_min,
        "k_max": case.k_max,
        "m": M,
        "root_strings": ";".join(case.root_strings),
        "noncert_status": case.noncertified_result.status,
        "certified_status": case.certified_result.status,
        "matched_status": case.matched_result.status,
        "noncert_equal_certified_values": noncert_equal_cert,
        "certified_equal_matched_values": cert_equal_matched,
        "certified_path_distinct_count": distinct_count,
        "matched_depth_equal_count": matched_equal,
        "matched_depth_invalid_count": matched_invalid,
        "noncert_zero_error_count": case.gold_summary_noncertified.zero_error_count,
        "certified_zero_error_count": case.gold_summary_certified.zero_error_count,
        "wfc_trace_count": len(case.noncertified_result.wfc_results) + len(case.certified_result.wfc_results) + len(case.matched_result.wfc_results),
        "ablation_branch_count": len(case.ablation_run.summary_records),
    }


def _operation_cost_row(case: CaseResult) -> dict[str, Any]:
    """Return per-case operation/cost accounting for academic comparison.

    These are deterministic trace-derived counts, not wall-clock performance
    benchmarks. They are intended to expose construction complexity: polynomial
    traces, BTNS multiplication/subtraction/negation events, WFC candidates,
    strict candidates, Certified decisions, ablation branches, and runtime.
    """

    all_results = (case.noncertified_result, case.certified_result, case.matched_result)
    traces = tuple(trace for result in all_results for trace in result.traces)
    wfc_results = tuple(wfc_result for result in all_results for wfc_result in result.wfc_results)
    operation_types = [trace.operation_type for trace in traces]
    return {
        "group_id": case.group_id,
        "k_min": case.k_min,
        "k_max": case.k_max,
        "m": M,
        "runtime_seconds": f"{case.runtime_seconds:.9f}",
        "polynomial_trace_count": len(traces),
        "btns_multiplication_trace_count": sum(1 for op in operation_types if "MUL" in op),
        "btns_subtraction_trace_count": sum(1 for op in operation_types if "SUB" in op),
        "btns_negation_trace_count": sum(1 for op in operation_types if "NEG" in op),
        "coefficient_commit_trace_count": sum(1 for op in operation_types if "COMMIT" in op or "COPY_LEADING" in op),
        "wfc_operation_count": len(wfc_results),
        "wfc_candidate_count": sum(item.trace.candidate_count for item in wfc_results),
        "wfc_strict_candidate_count": sum(item.trace.strict_candidate_count for item in wfc_results),
        "certified_decision_count": len(case.certified_result.certified_decision_chain),
        "certified_certificate_count": len(case.certified_result.operation_certificates),
        "matched_depth_record_count": len(case.matched_result.matched_depth_records),
        "ablation_branch_count": len(case.ablation_run.summary_records),
        "ablation_wfc_candidate_count": sum(row.candidate_count_total for row in case.ablation_run.summary_records),
        "ablation_wfc_strict_candidate_count": sum(row.strict_candidate_count_total for row in case.ablation_run.summary_records),
    }


def _aggregate_by_k_min(case_rows: Sequence[dict[str, Any]]) -> Tuple[dict[str, Any], ...]:
    grouped: dict[int, list[dict[str, Any]]] = {}
    for row in case_rows:
        grouped.setdefault(int(row["k_min"]), []).append(row)
    out = []
    for k_min, rows in sorted(grouped.items(), reverse=True):
        out.append(
            {
                "k_min": k_min,
                "group_count": len(rows),
                "case_count": len(rows),
                "all_noncert_equal_certified_values": all(bool(r["noncert_equal_certified_values"]) for r in rows),
                "all_certified_equal_matched_values": all(bool(r["certified_equal_matched_values"]) for r in rows),
                "matched_depth_invalid_total": sum(int(r["matched_depth_invalid_count"]) for r in rows),
                "wfc_trace_count_total": sum(int(r["wfc_trace_count"]) for r in rows),
                "ablation_branch_count_total": sum(int(r["ablation_branch_count"]) for r in rows),
            }
        )
    return tuple(out)


def _collect_rows(
    *,
    cases: Sequence[CaseResult],
    input_rows_all: Sequence[ingress.RootInputRow],
    audit_report: audit.AuditReport,
    run_config: Mapping[str, Any],
    manifest: Mapping[str, Any],
    settings_signature: Mapping[str, Any],
    excel_check: Mapping[str, Any],
) -> dict[str, Tuple[Mapping[str, Any], ...]]:
    rows: dict[str, list[Mapping[str, Any]]] = {name: [] for name in reporting.DEFAULT_SHEET_ORDER}

    rows[reporting.SHEET_RUN_CONFIG].extend(reporting.run_config_rows(run_config))
    rows[reporting.SHEET_INPUT_ROOTS].extend(_as_dict(row) for row in input_rows_all)
    rows[reporting.SHEET_INPUT_ROOTS_ALL].extend(_as_dict(row) for row in input_rows_all)
    rows[reporting.SHEET_TRACE_AUDIT].extend(reporting.audit_module_summary_rows(audit_report))
    rows[reporting.SHEET_FORBIDDEN_ARITHMETIC_AUDIT].extend(reporting.audit_rows(audit_report))
    rows[reporting.SHEET_MANIFEST].extend(reporting.manifest_rows(manifest))
    rows[reporting.SHEET_SETTINGS_SIGNATURE].extend(reporting.settings_signature_rows(settings_signature))
    rows[reporting.SHEET_EXCEL_COMPLETENESS_CHECK].extend(reporting._scalar_rows(excel_check))  # type: ignore[attr-defined]
    rows[reporting.SHEET_METHOD_NOTES].extend(
        (
            {"note_id": "N1", "text": "run_m10_campaign.py is a campaign/evidence runner, not a construction arithmetic module."},
            {"note_id": "N2", "text": "Gold values are computed only after construction for evaluation/reporting."},
            {"note_id": "N3", "text": "Matched-depth Non-Certified recomputation is executed separately from Certified output traces."},
        )
    )

    case_summary_rows: list[dict[str, Any]] = []
    for case in cases:
        context = {"group_id": case.group_id, "k_min": case.k_min}
        case_summary_rows.append(_case_summary_row(case))

        rows[reporting.SHEET_ROOT_INGRESS_BTNS].extend(_with_context(row, group_id=case.group_id, k_min=case.k_min) for row in reporting.ingress_rows(case.ingress_results))
        rows[reporting.SHEET_INPUT_ROOTS_SELECTED].extend(_with_context(_as_dict(row), group_id=case.group_id, k_min=case.k_min) for row in case.root_rows)

        rows[reporting.SHEET_POLYNOMIAL_EXPANSION_TRACE].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.polynomial_trace_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_NONCERTIFIED_COEFFICIENTS].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="NONCERTIFIED")
            for row in reporting.coefficient_rows(case.noncertified_result, digits=DEFAULT_REPORT_DECIMAL_DIGITS, path_label="NONCERTIFIED")
        )
        rows[reporting.SHEET_CERTIFIED_COEFFICIENTS].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="CERTIFIED")
            for row in reporting.coefficient_rows(case.certified_result, digits=DEFAULT_REPORT_DECIMAL_DIGITS, path_label="CERTIFIED")
        )
        rows[reporting.SHEET_GOLD_COEFFICIENTS].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.gold_coefficient_rows(case.gold_reference, digits=DEFAULT_REPORT_DECIMAL_DIGITS)
        )
        rows[reporting.SHEET_GOLD_COMPARISON].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="NONCERTIFIED")
            for row in reporting.gold_comparison_rows(case.gold_comparisons_noncertified)
        )
        rows[reporting.SHEET_NONCERTIFIED_ERROR].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="NONCERTIFIED")
            for row in reporting.gold_comparison_rows(case.gold_comparisons_noncertified)
        )
        rows[reporting.SHEET_CERTIFIED_ERROR].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="CERTIFIED")
            for row in reporting.gold_comparison_rows(case.gold_comparisons_certified)
        )
        rows[reporting.SHEET_ERROR_RANKING].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min, path_label="CERTIFIED")
            for row in reporting.gold_comparison_rows(case.gold_comparisons_certified)
        )
        rows[reporting.SHEET_GROUP_SUMMARY].append(_with_context(case.gold_summary_certified.as_dict(), group_id=case.group_id, k_min=case.k_min, path_label="CERTIFIED"))
        rows[reporting.SHEET_UCC_DECISION_SUMMARY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_and_ucc_cross_summary_rows(
                noncertified_result=case.noncertified_result,
                certified_result=case.certified_result,
                matched_result=case.matched_result,
                ablation_run=case.ablation_run,
            )
        )
        rows[reporting.SHEET_CERTIFIED_PATH_COMPARISON].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.path_comparison_rows(case.certified_path_comparisons)
        )
        rows[reporting.SHEET_CERTIFIED_DECISION_CHAIN].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.certified_decision_rows(case.certified_result)
        )
        rows[reporting.SHEET_CERTIFIED_REFINEMENT_TRACE].extend(tuple())
        rows[reporting.SHEET_CERTIFIED_CANDIDATE_SELECTION].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.certified_candidate_selection_rows(case.certified_result)
        )
        rows[reporting.SHEET_WFC_CONFIG].extend(
            reporting._scalar_rows(  # type: ignore[attr-defined]
                {
                    **context,
                    "window_width": case.config.wfc_window_width,
                    "policy": case.config.wfc_policy,
                    "boundary_mode": case.config.wfc_boundary_mode,
                }
            )
        )
        rows[reporting.SHEET_WFC_OPERATION_TRACE].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_operation_trace_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_WFC_CANDIDATE_FAMILY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_candidate_family_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_WFC_STRICT_ADMISSIBILITY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_strict_admissibility_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_WFC_TIE_POLICY_SELECTION].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_tie_policy_selection_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_WFC_UNDEFINED_CASES].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_undefined_case_rows(case.noncertified_result, case.certified_result, case.matched_result)
        )
        rows[reporting.SHEET_WFC_ABLATION_CONFIG].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_ablation_config_rows(case.ablation_run)
        )
        rows[reporting.SHEET_WFC_ABLATION_SUMMARY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_ablation_summary_rows(case.ablation_run)
        )
        rows[reporting.SHEET_WFC_WINDOW_SENSITIVITY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_window_sensitivity_rows(case.ablation_run)
        )
        rows[reporting.SHEET_WFC_TIE_POLICY_ABLATION].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_tie_policy_ablation_rows(case.ablation_run)
        )
        rows[reporting.SHEET_MATCHED_DEPTH_FAIRNESS].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.matched_depth_rows(case.matched_result)
        )
        rows[reporting.SHEET_ADAPTIVE_ADVANTAGE_CLASSIFICATION].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_ablation_summary_rows(case.ablation_run)
        )
        rows[reporting.SHEET_WFC_AND_UCC_CROSS_SUMMARY].extend(
            _with_context(row, group_id=case.group_id, k_min=case.k_min)
            for row in reporting.wfc_and_ucc_cross_summary_rows(
                noncertified_result=case.noncertified_result,
                certified_result=case.certified_result,
                matched_result=case.matched_result,
                ablation_run=case.ablation_run,
            )
        )

    rows[reporting.SHEET_CAMPAIGN_SUMMARY].extend(case_summary_rows)
    rows[reporting.SHEET_GROUP_SUMMARY].extend(case_summary_rows)
    rows["campaign_summary_by_k_min"] = list(_aggregate_by_k_min(case_summary_rows))
    rows["operation_cost_accounting"] = [_operation_cost_row(case) for case in cases]
    rows["final_run_summary"] = []

    return {key: tuple(value) for key, value in rows.items()}


def _make_bundle_from_rows(rows: Mapping[str, Sequence[Mapping[str, Any]]]) -> reporting.ReportingBundle:
    tables = tuple(reporting.ReportingTable(name, tuple(rows.get(name, tuple()))) for name in reporting.DEFAULT_SHEET_ORDER)
    return reporting.ReportingBundle(tables=tables, package_name=PACKAGE_NAME)


# ---------------------------------------------------------------------------
# XLSX writer using only the standard library
# ---------------------------------------------------------------------------


def _col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def _safe_sheet_name(name: str, used: set[str]) -> str:
    invalid = set('[]:*?/\\')
    base = "".join("_" if ch in invalid else ch for ch in name).strip() or "Sheet"
    base = base[:31]
    candidate = base
    i = 1
    while candidate in used:
        suffix = f"_{i}"
        candidate = (base[: 31 - len(suffix)] + suffix)[:31]
        i += 1
    used.add(candidate)
    return candidate


def _xml_text(value: Any) -> str:
    text = "" if value is None else str(value)
    # XML 1.0 compatible light sanitization.
    text = "".join(ch if ch in "\t\n\r" or ord(ch) >= 32 else " " for ch in text)
    return escape(text)


def _worksheet_xml(rows: Sequence[Mapping[str, Any]], columns: Optional[Sequence[str]] = None) -> str:
    sheet_columns: list[str] = list(columns or tuple())
    for row in rows:
        for key in row.keys():
            text = str(key)
            if text not in sheet_columns:
                sheet_columns.append(text)
    sheet_rows: list[list[Any]] = []
    if sheet_columns:
        sheet_rows.append(sheet_columns)
        for row in rows:
            sheet_rows.append([row.get(col, "") for col in sheet_columns])
    xml_rows = []
    for r_idx, values in enumerate(sheet_rows, start=1):
        cells = []
        for c_idx, value in enumerate(values, start=1):
            ref = f"{_col_name(c_idx)}{r_idx}"
            cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{_xml_text(value)}</t></is></c>')
        xml_rows.append(f'<row r="{r_idx}">{"".join(cells)}</row>')
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheetData>' + "".join(xml_rows) + '</sheetData></worksheet>'
    )


def write_xlsx_workbook(bundle: reporting.ReportingBundle, output_path: str | Path) -> str:
    """Write a simple evidence workbook without external spreadsheet libraries."""

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    used: set[str] = set()
    sheet_names = [_safe_sheet_name(table.name, used) for table in bundle.tables]

    content_types = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
    ]
    for idx in range(1, len(bundle.tables) + 1):
        content_types.append(f'<Override PartName="/xl/worksheets/sheet{idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
    content_types.append('</Types>')

    workbook_sheets = []
    workbook_rels = []
    for idx, sheet_name in enumerate(sheet_names, start=1):
        workbook_sheets.append(f'<sheet name="{_xml_text(sheet_name)}" sheetId="{idx}" r:id="rId{idx}"/>')
        workbook_rels.append(
            f'<Relationship Id="rId{idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>'
        )
    workbook_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets>' + "".join(workbook_sheets) + '</sheets></workbook>'
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>'
    )
    workbook_rels_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join(workbook_rels)
        + '</Relationships>'
    )
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", "".join(content_types))
        zf.writestr("_rels/.rels", root_rels)
        zf.writestr("xl/workbook.xml", workbook_xml)
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml)
        for idx, table in enumerate(bundle.tables, start=1):
            zf.writestr(f"xl/worksheets/sheet{idx}.xml", _worksheet_xml(table.rows, table.columns))
    return str(output)


# ---------------------------------------------------------------------------
# Manifest, status, and output writing
# ---------------------------------------------------------------------------


def _output_hashes(output_dir: Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for path in sorted(output_dir.iterdir()):
        if path.is_file():
            hashes[path.name] = _hash_file(path)
    return hashes


def _trace_hash(cases: Sequence[CaseResult]) -> str:
    trace_ids: list[str] = []
    for case in cases:
        for result in (case.noncertified_result, case.certified_result, case.matched_result):
            trace_ids.extend(trace.output_trace_id for trace in result.traces)
            trace_ids.extend(wfc_result.trace.wfc_trace_id for wfc_result in result.wfc_results)
    return _hash_mapping(trace_ids)


def _candidate_family_hash(cases: Sequence[CaseResult]) -> str:
    candidate_ids: list[str] = []
    for case in cases:
        for result in (case.noncertified_result, case.certified_result, case.matched_result):
            for wfc_result in result.wfc_results:
                candidate_ids.extend(candidate.candidate_id for candidate in wfc_result.candidates)
    return _hash_mapping(candidate_ids)


def _ablation_hash(cases: Sequence[CaseResult]) -> str:
    return _hash_mapping([case.ablation_run.as_dict() for case in cases])


def _matched_depth_hash(cases: Sequence[CaseResult]) -> str:
    rows = []
    for case in cases:
        for record in case.matched_governance_records:
            rows.append(record.as_dict())
    return _hash_mapping(rows)


def _settings_signature(
    *,
    k_min_grid: Sequence[int],
    rounding_policy: str,
    wfc_policy: str,
    wfc_window_width: int,
    root_group_count: int,
) -> dict[str, Any]:
    window_grid = sorted({_effective_wfc_window(k, wfc_window_width) for k in k_min_grid})
    return {
        "m": M,
        "k_min_grid": list(k_min_grid),
        "rounding_policy": rounding_policy,
        "wfc_policy": wfc_policy,
        "wfc_window_width": wfc_window_width,
        "wfc_window_grid": window_grid,
        "wfc_boundary_mode": "LOWER_BOUNDARY_COMPENSATED",
        "certified_policy": "INDEPENDENT_CERTIFIED_CONTROLLER",
        "tail_bound_policy": "TAIL_REFINEMENT",
        "root_group_count": root_group_count,
        "operation_mode": "BTNS_M10_NINTH_STAGE",
        "audit_mode": "FINAL_PACKAGE",
        "excel_input_policy": "FORBIDDEN_EXCEL_INPUT",
        "construction_boundary_policy": "BTNS_ONLY_AFTER_INGRESS",
        "certified_path_independence_policy": "REQUIRED",
        "matched_depth_fairness_policy": "REQUIRED",
        "wfc_ablation_policy": "REQUIRED",
    }


def _manifest(
    *,
    root: Path,
    input_path: Path,
    output_dir: Path,
    k_min_grid: Sequence[int],
    settings_signature: Mapping[str, Any],
    cases: Sequence[CaseResult],
) -> dict[str, Any]:
    now = _now_utc_iso()
    output_hashes = _output_hashes(output_dir) if output_dir.exists() else {}
    return {
        "contract_version": CONTRACT_VERSION,
        "package_name": PACKAGE_NAME,
        "reference_label": REFERENCE_LABEL,
        "package_version": "m10_v28_pythonapplication157",
        "run_id": "M10_" + _sha256_text(now + str(k_min_grid))[:16],
        "script_hashes": _script_hashes(root),
        "input_hashes": {input_path.name: _hash_file(input_path)},
        "config_hash": _hash_mapping(settings_signature),
        "output_hashes": output_hashes,
        "python_version": sys.version.split()[0],
        "platform_summary": platform.platform(),
        "timestamp_utc": now,
        "certified_path_policy": "INDEPENDENT_CONTROLLER_REQUIRED",
        "certified_candidate_policy": "CONSTRUCTION_TIME_DECISIONS_REQUIRED",
        "certified_refinement_policy": "DECLARED_INGRESS_REFINEMENT_BOUNDARY",
        "wfc_execution_policy": "FULL_STRICT_WFC_REQUIRED",
        "wfc_window_width": settings_signature.get("wfc_window_width"),
        "wfc_window_grid": settings_signature.get("wfc_window_grid"),
        "wfc_policy": settings_signature.get("wfc_policy"),
        "wfc_boundary_mode": settings_signature.get("wfc_boundary_mode"),
        "wfc_ablation_policy": "REQUIRED",
        "wfc_ablation_branch_count": 5,
        "matched_depth_fairness_policy": "REQUIRED",
        "matched_depth_completion_hash": _matched_depth_hash(cases),
        "wfc_trace_hash": _trace_hash(cases),
        "wfc_candidate_family_hash": _candidate_family_hash(cases),
        "wfc_ablation_hash": _ablation_hash(cases),
    }


def _status_from_gates(cases: Sequence[CaseResult], audit_report: audit.AuditReport) -> tuple[str, str, dict[str, Any]]:
    audit_fail_count = sum(1 for item in audit_report.violations if item.severity == audit.STATUS_FAIL)
    matched_invalid_count = 0
    copied_trace_invalid_count = 0
    non_distinct_count = 0
    wfc_trace_count = 0
    wfc_invalid_trace_count = 0
    ablation_incomplete_count = 0
    certified_decision_count = 0
    worse_count = 0

    for case in cases:
        certified_decision_count += len(case.certified_result.certified_decision_chain)
        for record in case.matched_governance_records:
            if record.matched_depth_comparison == MATCHED_DEPTH_NOT_RUN_INVALID:
                matched_invalid_count += 1
            if record.copied_trace_invalid:
                copied_trace_invalid_count += 1
        for record in case.certified_path_comparisons:
            if record.path_comparison_token != certified.CERT_PATH_DISTINCT_FROM_NONCERT:
                non_distinct_count += 1
        for result in (case.noncertified_result, case.certified_result, case.matched_result):
            for wfc_result in result.wfc_results:
                wfc_trace_count += 1
                from btns_wfc import validate_wfc_trace

                if not validate_wfc_trace(wfc_result.trace, wfc_result.candidates):
                    wfc_invalid_trace_count += 1
        for row in case.ablation_run.summary_records:
            if row.branch_status != run_wfc_ablation.WFC_ABLATION_BRANCH_COMPLETE:
                ablation_incomplete_count += 1
            worse_count += row.WORSE_count

    gates = {
        "audit_fail_count": audit_fail_count,
        "matched_depth_not_run_invalid_count": matched_invalid_count,
        "matched_depth_copied_trace_invalid_count": copied_trace_invalid_count,
        "certified_path_not_distinct_count": non_distinct_count,
        "certified_construction_decision_count": certified_decision_count,
        "wfc_trace_count": wfc_trace_count,
        "wfc_invalid_trace_count": wfc_invalid_trace_count,
        "wfc_ablation_incomplete_count": ablation_incomplete_count,
        "worse_count": worse_count,
        "FALSE_count": 0,
        "unresolved_final_TUBE_count": 0,
        "wfc_bypass_count": 0,
    }
    valid = (
        audit_fail_count == 0
        and matched_invalid_count == 0
        and copied_trace_invalid_count == 0
        and non_distinct_count == 0
        and certified_decision_count > 0
        and wfc_trace_count > 0
        and wfc_invalid_trace_count == 0
        and ablation_incomplete_count == 0
    )
    promotable = valid and worse_count == 0
    return (VALID_RUN if valid else INVALID_RUN, PROMOTABLE_RUN if promotable else NON_PROMOTABLE_RUN, gates)


def _build_excel_check(bundle: reporting.ReportingBundle) -> dict[str, Any]:
    missing = reporting.validate_required_sheet_names(bundle)
    return {
        "status": "PASS" if not missing else "FAIL",
        "required_sheet_count": len(reporting.DEFAULT_SHEET_ORDER),
        "present_sheet_count": len(bundle.tables),
        "missing_sheets": list(missing),
        "workbook_writer": "STANDARD_LIBRARY_MINIMAL_XLSX",
    }


def write_campaign_outputs(
    *,
    output_dir: str | Path,
    rows_by_sheet: Mapping[str, Sequence[Mapping[str, Any]]],
    bundle: reporting.ReportingBundle,
    run_config: Mapping[str, Any],
    manifest: Mapping[str, Any],
    settings_signature: Mapping[str, Any],
    final_summary: Mapping[str, Any],
) -> dict[str, str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {}

    key_sidecars = {
        "run_config.json": dict(run_config),
        "manifest.json": dict(manifest),
        "settings_signature.json": dict(settings_signature),
        "excel_completeness_check.json": dict(final_summary.get("excel_completeness_check", {})) if isinstance(final_summary.get("excel_completeness_check", {}), Mapping) else {},
        "final_run_summary.json": dict(final_summary),
    }
    for name, payload in key_sidecars.items():
        path = out / name
        _write_json(path, payload)
        files[name] = str(path)

    # Required and useful CSV sidecars.
    sidecar_map = {
        "input_roots_all.csv": reporting.SHEET_INPUT_ROOTS_ALL,
        "input_roots_selected.csv": reporting.SHEET_INPUT_ROOTS_SELECTED,
        "root_ingress_btns.csv": reporting.SHEET_ROOT_INGRESS_BTNS,
        "polynomial_expansion_trace.csv": reporting.SHEET_POLYNOMIAL_EXPANSION_TRACE,
        "noncertified_coefficients.csv": reporting.SHEET_NONCERTIFIED_COEFFICIENTS,
        "certified_coefficients.csv": reporting.SHEET_CERTIFIED_COEFFICIENTS,
        "gold_coefficients.csv": reporting.SHEET_GOLD_COEFFICIENTS,
        "gold_comparison.csv": reporting.SHEET_GOLD_COMPARISON,
        "noncertified_error.csv": reporting.SHEET_NONCERTIFIED_ERROR,
        "certified_error.csv": reporting.SHEET_CERTIFIED_ERROR,
        "group_summary.csv": reporting.SHEET_GROUP_SUMMARY,
        "campaign_summary_by_k_min.csv": "campaign_summary_by_k_min",
        "campaign_summary.csv": reporting.SHEET_CAMPAIGN_SUMMARY,
        "ucc_decision_summary.csv": reporting.SHEET_UCC_DECISION_SUMMARY,
        "certified_path_comparison.csv": reporting.SHEET_CERTIFIED_PATH_COMPARISON,
        "certified_decision_chain.csv": reporting.SHEET_CERTIFIED_DECISION_CHAIN,
        "certified_refinement_trace.csv": reporting.SHEET_CERTIFIED_REFINEMENT_TRACE,
        "certified_candidate_selection.csv": reporting.SHEET_CERTIFIED_CANDIDATE_SELECTION,
        "wfc_config.csv": reporting.SHEET_WFC_CONFIG,
        "wfc_operation_trace.csv": reporting.SHEET_WFC_OPERATION_TRACE,
        "wfc_candidate_family.csv": reporting.SHEET_WFC_CANDIDATE_FAMILY,
        "wfc_strict_admissibility.csv": reporting.SHEET_WFC_STRICT_ADMISSIBILITY,
        "wfc_tie_policy_selection.csv": reporting.SHEET_WFC_TIE_POLICY_SELECTION,
        "wfc_undefined_cases.csv": reporting.SHEET_WFC_UNDEFINED_CASES,
        "wfc_ablation_config.csv": reporting.SHEET_WFC_ABLATION_CONFIG,
        "wfc_ablation_summary.csv": reporting.SHEET_WFC_ABLATION_SUMMARY,
        "wfc_window_sensitivity.csv": reporting.SHEET_WFC_WINDOW_SENSITIVITY,
        "wfc_tie_policy_ablation.csv": reporting.SHEET_WFC_TIE_POLICY_ABLATION,
        "matched_depth_fairness.csv": reporting.SHEET_MATCHED_DEPTH_FAIRNESS,
        "adaptive_advantage_classification.csv": reporting.SHEET_ADAPTIVE_ADVANTAGE_CLASSIFICATION,
        "wfc_ucc_cross_summary.csv": reporting.SHEET_WFC_AND_UCC_CROSS_SUMMARY,
        "forbidden_arithmetic_audit.csv": reporting.SHEET_FORBIDDEN_ARITHMETIC_AUDIT,
        "trace_audit.csv": reporting.SHEET_TRACE_AUDIT,
        "method_notes.csv": reporting.SHEET_METHOD_NOTES,
        "operation_cost_accounting.csv": "operation_cost_accounting",
    }
    empty_sidecar_headers = {
        "wfc_undefined_cases.csv": (
            "group_id", "k_min_case", "wfc_trace_id", "operation_id",
            "input_trace_id", "output_trace_id", "window_width", "policy",
            "candidate_count", "strict_candidate_count", "selected_candidate_id",
            "selected_c_in", "q0_selected", "wfc_status",
            "wfc_boundary_mode", "wfc_not_applicable_reason",
        ),
        "certified_refinement_trace.csv": (
            "group_id", "k_min_case", "certified_path_id", "certified_stage_id",
            "refinement_depth_requested", "refinement_reason", "status",
        ),
        "forbidden_arithmetic_audit.csv": (
            "code", "module", "message", "severity", "lineno",
        ),
    }
    for filename, sheet_name in sidecar_map.items():
        path = out / filename
        sidecar_rows = tuple(rows_by_sheet.get(sheet_name, tuple()))
        if not sidecar_rows and filename in empty_sidecar_headers:
            _write_csv_with_header(path, empty_sidecar_headers[filename])
        else:
            _write_csv(path, sidecar_rows)
        files[filename] = str(path)

    payload_path = out / "BTNS_m10_results_v28_workbook_payload.json"
    _write_json(payload_path, reporting.workbook_payload(bundle))
    files[payload_path.name] = str(payload_path)

    xlsx_path = out / "BTNS_m10_results_v28.xlsx"
    write_xlsx_workbook(bundle, xlsx_path)
    files[xlsx_path.name] = str(xlsx_path)

    reporting_result = reporting.write_reporting_bundle_sidecars(bundle, out / "workbook_ready_tables")
    files["workbook_ready_tables"] = reporting_result.output_dir
    return files


# ---------------------------------------------------------------------------
# Main campaign API
# ---------------------------------------------------------------------------


def run_m10_campaign(
    *,
    input_csv: str | Path,
    output_dir: str | Path,
    k_min_grid: Sequence[int] = DEFAULT_K_MIN_GRID,
    k_max: Optional[int] = None,
    rounding_policy: str = ingress.DEFAULT_ROUNDING_POLICY,
    wfc_policy: str = RN_ZERO,
    wfc_window_width: int = DEFAULT_WFC_WINDOW_WIDTH,
    report_decimal_digits: int = DEFAULT_REPORT_DECIMAL_DIGITS,
    max_groups: Optional[int] = None,
) -> CampaignRunResult:
    root = Path(__file__).resolve().parent
    input_path = Path(input_csv)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    input_rows_all = ingress.load_root_input_csv(input_path)
    grouped = _group_rows(input_rows_all)
    group_items = list(grouped.items())
    if max_groups is not None:
        group_items = group_items[:max_groups]
    if not group_items:
        raise ValueError("no root groups available for m=10 campaign")

    cases: list[CaseResult] = []
    for k in k_min_grid:
        for group_id, rows in group_items:
            cases.append(
                run_case(
                    group_id=group_id,
                    group_rows=rows,
                    k_min=int(k),
                    k_max=k_max,
                    rounding_policy=rounding_policy,
                    wfc_policy=wfc_policy,
                    wfc_window_width=wfc_window_width,
                    report_decimal_digits=report_decimal_digits,
                )
            )

    settings = _settings_signature(
        k_min_grid=k_min_grid,
        rounding_policy=rounding_policy,
        wfc_policy=wfc_policy,
        wfc_window_width=wfc_window_width,
        root_group_count=len(group_items),
    )
    audit_report = audit.audit_project(root, stage=audit.STAGE_FINAL_PACKAGE)
    run_status, promotion_status, gates = _status_from_gates(cases, audit_report)

    # First pass manifest/check before output hashes exist.
    preliminary_manifest = _manifest(
        root=root,
        input_path=input_path,
        output_dir=out,
        k_min_grid=k_min_grid,
        settings_signature=settings,
        cases=cases,
    )
    preliminary_excel_check = {"status": "PENDING", "required_sheet_count": len(reporting.DEFAULT_SHEET_ORDER)}
    run_config = {
        "contract_version": CONTRACT_VERSION,
        "package_name": PACKAGE_NAME,
        "reference_label": REFERENCE_LABEL,
        "runner": RUNNER_NAME,
        "m": M,
        "k_min_grid": list(k_min_grid),
        "k_max": k_max,
        "rounding_policy": rounding_policy,
        "wfc_config": {
            "policy": wfc_policy,
            "window_width": wfc_window_width,
            "boundary_mode": "LOWER_BOUNDARY_COMPENSATED",
        },
        "input_csv": str(input_path),
        "output_dir": str(out),
        "max_groups": max_groups,
    }
    rows_by_sheet = _collect_rows(
        cases=cases,
        input_rows_all=input_rows_all,
        audit_report=audit_report,
        run_config=run_config,
        manifest=preliminary_manifest,
        settings_signature=settings,
        excel_check=preliminary_excel_check,
    )
    bundle = _make_bundle_from_rows(rows_by_sheet)
    excel_check = _build_excel_check(bundle)
    final_summary = {
        "run_status": run_status,
        "promotion_status": promotion_status,
        "case_count": len(cases),
        "group_count": len(group_items),
        "k_min_grid": list(k_min_grid),
        "gates": gates,
        "excel_completeness_check": excel_check,
    }

    # Rebuild rows with final excel check.
    rows_by_sheet = _collect_rows(
        cases=cases,
        input_rows_all=input_rows_all,
        audit_report=audit_report,
        run_config=run_config,
        manifest=preliminary_manifest,
        settings_signature=settings,
        excel_check=excel_check,
    )
    bundle = _make_bundle_from_rows(rows_by_sheet)
    written = write_campaign_outputs(
        output_dir=out,
        rows_by_sheet=rows_by_sheet,
        bundle=bundle,
        run_config=run_config,
        manifest=preliminary_manifest,
        settings_signature=settings,
        final_summary=final_summary,
    )

    # Final manifest includes output hashes after files have been written.
    final_manifest = dict(preliminary_manifest)
    final_manifest["output_hashes"] = _output_hashes(out)
    _write_json(out / "manifest.json", final_manifest)
    # Update workbook-ready manifest sheet one last time for consistency in JSON/CSV outputs.
    rows_by_sheet = dict(rows_by_sheet)
    rows_by_sheet[reporting.SHEET_MANIFEST] = reporting.manifest_rows(final_manifest)
    bundle = _make_bundle_from_rows(rows_by_sheet)
    write_xlsx_workbook(bundle, out / "BTNS_m10_results_v28.xlsx")
    _write_json(out / "BTNS_m10_results_v28_workbook_payload.json", reporting.workbook_payload(bundle))

    return CampaignRunResult(
        cases=tuple(cases),
        audit_report=audit_report,
        run_status=run_status,
        promotion_status=promotion_status,
        manifest=final_manifest,
        settings_signature=settings,
        workbook_bundle=bundle,
        output_dir=str(out),
    )


# ---------------------------------------------------------------------------
# CLI and self-check
# ---------------------------------------------------------------------------


def _parse_k_min_grid(text: str) -> Tuple[int, ...]:
    values = tuple(int(part.strip()) for part in text.split(",") if part.strip())
    if not values:
        raise argparse.ArgumentTypeError("k-min-grid must contain at least one integer")
    return values


def self_check() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        input_csv = tmp_path / "sample_roots_m10.csv"
        output_dir = tmp_path / "out"
        write_default_sample_roots(input_csv)
        result = run_m10_campaign(
            input_csv=input_csv,
            output_dir=output_dir,
            k_min_grid=(-1,),
            k_max=1,
            wfc_window_width=1,
            max_groups=1,
            report_decimal_digits=6,
        )
        assert result.run_status == VALID_RUN, result.as_dict()
        assert result.promotion_status == PROMOTABLE_RUN, result.as_dict()
        assert (output_dir / "manifest.json").exists()
        assert (output_dir / "settings_signature.json").exists()
        assert (output_dir / "wfc_operation_trace.csv").exists()
        assert (output_dir / "matched_depth_fairness.csv").exists()
        assert (output_dir / "wfc_ablation_summary.csv").exists()
        assert (output_dir / "BTNS_m10_results_v28.xlsx").exists()
    print("run_m10_campaign.py self-check PASS")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Run PythonApplication157 v28 m=10 BTNS/WFC campaign.")
    parser.add_argument("--input", "--roots_csv", dest="input", default="sample_roots_m10.csv", help="CSV root input file.")
    parser.add_argument("--output", "--output_dir", dest="output", default="btns_m10_output_157", help="Output directory.")
    parser.add_argument("--k-min-grid", "--k_min_grid", dest="k_min_grid", type=_parse_k_min_grid, default=DEFAULT_K_MIN_GRID, help="Comma-separated k_min grid, e.g. -20,-30,-40,-50.")
    parser.add_argument("--k-max", "--k_max", dest="k_max", type=int, default=None, help="Optional k_max override.")
    parser.add_argument("--rounding-policy", "--rounding_policy", dest="rounding_policy", default=ingress.DEFAULT_ROUNDING_POLICY, help="Ingress rounding policy.")
    parser.add_argument("--wfc-policy", "--wfc_policy", dest="wfc_policy", default=RN_ZERO, help="WFC policy token, RN_ZERO or RN_EVEN.")
    parser.add_argument("--wfc-window-width", "--wfc_window_width", dest="wfc_window_width", type=int, default=DEFAULT_WFC_WINDOW_WIDTH, help="Requested WFC window width.")
    parser.add_argument("--decimal-digits", "--decimal_digits", dest="decimal_digits", type=int, default=DEFAULT_REPORT_DECIMAL_DIGITS, help="Decimal digits for report-only gold/egress strings.")
    parser.add_argument("--max-groups", "--max_groups", dest="max_groups", type=int, default=None, help="Optional group limit for smoke runs.")
    parser.add_argument("--package-root", "--package_root", dest="package_root", default=None, help="Optional package root for legacy command compatibility.")
    parser.add_argument("--self-check", action="store_true", help="Run internal smoke self-check in a temporary directory.")
    args = parser.parse_args(argv)

    if args.self_check:
        self_check()
        return 0

    package_root = Path(args.package_root).resolve() if args.package_root is not None else None
    input_path = Path(args.input)
    output_path = Path(args.output)
    if package_root is not None:
        if not input_path.is_absolute():
            input_path = package_root / input_path
        if not output_path.is_absolute():
            output_path = package_root / output_path

    if not input_path.exists():
        write_default_sample_roots(input_path)
        print(f"sample input was missing; wrote default sample to {input_path}")

    result = run_m10_campaign(
        input_csv=input_path,
        output_dir=output_path,
        k_min_grid=args.k_min_grid,
        k_max=args.k_max,
        rounding_policy=args.rounding_policy,
        wfc_policy=args.wfc_policy,
        wfc_window_width=args.wfc_window_width,
        report_decimal_digits=args.decimal_digits,
        max_groups=args.max_groups,
    )
    print(json.dumps(_json_safe(result.as_dict()), indent=2, sort_keys=True))
    return 0 if result.run_status == VALID_RUN else 1


if __name__ == "__main__":
    raise SystemExit(main())
