"""
tests_reporting.py

Unit tests for reporting.py, the report/evidence aggregation layer used by
PythonApplication157 under Script Contract v28.

These tests verify that reporting.py creates the full v28 workbook-ready table
set and sidecar CSV/JSON payloads from already-produced BTNS/WFC/Certified/
Ablation objects only. The reporting layer must remain an output boundary:
    - no polynomial coefficient construction;
    - no WFC candidate selection;
    - no Certified construction decisions;
    - no ingress projection;
    - no external-gold polynomial construction;
    - no Excel workbook reading/writing;
    - no Decimal/Fraction/NumPy/SymPy computation.
"""

from __future__ import annotations

import ast
import csv
import inspect
import json
from pathlib import Path
import tempfile
import unittest

import audit
import btns_core as core
import btns_poly as poly
import btns_wfc as wfc
import gold_reference as gold
import reporting
import run_wfc_ablation as ablation


def one(trace_id: str = "ONE", *, k_min: int = 0, k_max: int = 1) -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(trace_id: str = "TWO", *, k_min: int = 0, k_max: int = 1) -> core.BTNSNumber:
    return core.add_btns(
        one(trace_id=trace_id + "_A", k_min=k_min, k_max=k_max),
        one(trace_id=trace_id + "_B", k_min=k_min, k_max=k_max),
    )


def cfg(**overrides: object) -> poly.CampaignConfig:
    params: dict[str, object] = {
        "k_min": 0,
        "k_max": 1,
        "trace_prefix": "TEST_REPORTING_V28",
        "wfc_window_width": 0,
        "wfc_policy": wfc.RN_ZERO,
    }
    params.update(overrides)
    return poly.CampaignConfig(**params)


class EvidenceFixture:
    def __init__(self) -> None:
        self.config = cfg()
        self.r1 = one("R1")
        self.r2 = two("R2")
        self.noncert = poly.build_quadratic_coeffs_noncertified(self.r1, self.r2, self.config)
        self.cert = poly.build_quadratic_coeffs_certified_independent(self.r1, self.r2, self.config)
        self.matched = poly.build_quadratic_coeffs_noncertified_matched_depth(
            self.r1,
            self.r2,
            self.config.k_min,
            self.config,
            self.cert,
        )
        self.gold_ref = gold.build_gold_quadratic_from_root_strings("1", "2")
        self.gold_comparisons = gold.compare_coefficients_to_gold(self.noncert.coefficients, self.gold_ref.coefficients)
        self.gold_summary = gold.summarize_gold_comparisons(self.gold_comparisons)
        self.path_records = []
        self.audit_report = audit.audit_project(Path(__file__).resolve().parent, stage=audit.STAGE_CORE_STACK)
        self.ablation_run = ablation.run_wfc_ablation((self.r1, self.r2), self.config, gold_reference=self.gold_ref)

    def bundle(self) -> reporting.ReportingBundle:
        return reporting.build_workbook_ready_tables(
            run_config={
                "contract_version": "v28",
                "package_name": "PythonApplication157",
                "wfc_config": {"policy": wfc.RN_ZERO, "window_width": 0},
            },
            input_roots_all=(
                {"group_id": "G01", "root_index": 1, "root_decimal_string": "1"},
                {"group_id": "G01", "root_index": 2, "root_decimal_string": "2"},
            ),
            input_roots_selected=(
                {"group_id": "G01", "root_index": 1, "root_decimal_string": "1"},
                {"group_id": "G01", "root_index": 2, "root_decimal_string": "2"},
            ),
            arithmetic_self_tests=({"test_name": "core", "status": "PASS"},),
            addition_tests=({"test_name": "add", "status": "PASS"},),
            multiplication_tests=({"test_name": "mul", "status": "PASS"},),
            noncertified_result=self.noncert,
            certified_result=self.cert,
            matched_result=self.matched,
            gold_reference=self.gold_ref,
            gold_comparisons=self.gold_comparisons,
            gold_summary=self.gold_summary,
            certified_path_comparisons=self.path_records,
            trace_audit_report=self.audit_report,
            forbidden_arithmetic_audit=self.audit_report,
            manifest={"reference_label": reporting.REPORTING_REFERENCE_LABEL},
            settings_signature={"m": 2, "wfc_policy": wfc.RN_ZERO},
            excel_completeness_check={"status": "NOT_WRITTEN_IN_TEST", "required_sheets": len(reporting.DEFAULT_SHEET_ORDER)},
            campaign_summary=({"group_id": "G01", "status": "PASS"},),
            method_notes=({"note_id": "N1", "text": "reporting-only"},),
            certified_refinement_trace=tuple(),
            ablation_run=self.ablation_run,
            decimal_digits=6,
        )


class TestReportingTableAndBundle(unittest.TestCase):
    def test_reporting_table_columns_and_dict(self) -> None:
        table = reporting.ReportingTable("T", ({"a": 1, "b": 2}, {"b": 3, "c": 4}))

        self.assertEqual(table.row_count, 2)
        self.assertEqual(table.columns, ("a", "b", "c"))
        self.assertEqual(table.as_dict()["name"], "T")

    def test_reporting_table_rejects_bad_name_or_row(self) -> None:
        with self.assertRaises(ValueError):
            reporting.ReportingTable("", tuple())
        with self.assertRaises(TypeError):
            reporting.ReportingTable("T", (object(),))  # type: ignore[arg-type]

    def test_reporting_bundle_rejects_duplicate_table_names(self) -> None:
        table = reporting.ReportingTable("T", tuple())
        with self.assertRaises(ValueError):
            reporting.ReportingBundle((table, table))

    def test_bundle_metadata_uses_v28_identity(self) -> None:
        bundle = reporting.ReportingBundle((reporting.ReportingTable("T", tuple()),))
        payload = bundle.as_dict()

        self.assertEqual(payload["contract_version"], "v28")
        self.assertEqual(payload["package_name"], "PythonApplication157")
        self.assertEqual(payload["reference_label"], reporting.REPORTING_REFERENCE_LABEL)


class TestWorkbookReadyTables(unittest.TestCase):
    def test_build_workbook_ready_tables_contains_all_required_sheets(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()

        self.assertEqual(reporting.validate_required_sheet_names(bundle), tuple())
        self.assertEqual([table.name for table in bundle.tables], list(reporting.DEFAULT_SHEET_ORDER))
        self.assertEqual(len(bundle.tables), 42)

    def test_core_tables_have_expected_nonempty_rows(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()

        self.assertEqual(bundle.table_by_name(reporting.SHEET_NONCERTIFIED_COEFFICIENTS).row_count, 3)  # type: ignore[union-attr]
        self.assertEqual(bundle.table_by_name(reporting.SHEET_CERTIFIED_COEFFICIENTS).row_count, 3)  # type: ignore[union-attr]
        self.assertGreater(bundle.table_by_name(reporting.SHEET_POLYNOMIAL_EXPANSION_TRACE).row_count, 0)  # type: ignore[union-attr]
        self.assertGreater(bundle.table_by_name(reporting.SHEET_WFC_OPERATION_TRACE).row_count, 0)  # type: ignore[union-attr]
        self.assertGreater(bundle.table_by_name(reporting.SHEET_WFC_CANDIDATE_FAMILY).row_count, 0)  # type: ignore[union-attr]
        self.assertEqual(bundle.table_by_name(reporting.SHEET_MATCHED_DEPTH_FAIRNESS).row_count, 3)  # type: ignore[union-attr]

    def test_wfc_tables_expose_trace_candidate_and_policy_fields(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()

        op_rows = bundle.table_by_name(reporting.SHEET_WFC_OPERATION_TRACE).rows  # type: ignore[union-attr]
        cand_rows = bundle.table_by_name(reporting.SHEET_WFC_CANDIDATE_FAMILY).rows  # type: ignore[union-attr]
        strict_rows = bundle.table_by_name(reporting.SHEET_WFC_STRICT_ADMISSIBILITY).rows  # type: ignore[union-attr]
        tie_rows = bundle.table_by_name(reporting.SHEET_WFC_TIE_POLICY_SELECTION).rows  # type: ignore[union-attr]

        self.assertTrue(any("wfc_trace_id" in row for row in op_rows))
        self.assertTrue(any("candidate_id" in row for row in cand_rows))
        self.assertTrue(all("strict_status" in row for row in strict_rows))
        self.assertTrue(all("policy" in row for row in tie_rows))

    def test_gold_ablation_and_cross_summary_tables_are_populated(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()

        self.assertEqual(bundle.table_by_name(reporting.SHEET_GOLD_COEFFICIENTS).row_count, 3)  # type: ignore[union-attr]
        self.assertEqual(bundle.table_by_name(reporting.SHEET_GOLD_COMPARISON).row_count, 3)  # type: ignore[union-attr]
        self.assertEqual(bundle.table_by_name(reporting.SHEET_WFC_ABLATION_SUMMARY).row_count, 5)  # type: ignore[union-attr]
        self.assertEqual(bundle.table_by_name(reporting.SHEET_WFC_ABLATION_CONFIG).row_count, 5)  # type: ignore[union-attr]
        self.assertGreater(bundle.table_by_name(reporting.SHEET_WFC_AND_UCC_CROSS_SUMMARY).row_count, 0)  # type: ignore[union-attr]

    def test_workbook_payload_is_sheet_name_to_rows_mapping(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()
        payload = reporting.workbook_payload(bundle)

        self.assertEqual(set(payload), set(reporting.DEFAULT_SHEET_ORDER))
        self.assertEqual(len(payload[reporting.SHEET_NONCERTIFIED_COEFFICIENTS]), 3)
        self.assertIsInstance(payload[reporting.SHEET_RUN_CONFIG], list)

    def test_validate_required_sheet_names_reports_missing_sheet(self) -> None:
        bundle = reporting.ReportingBundle((reporting.ReportingTable(reporting.SHEET_RUN_CONFIG, tuple()),))
        missing = reporting.validate_required_sheet_names(bundle)

        self.assertIn(reporting.SHEET_WFC_OPERATION_TRACE, missing)
        self.assertNotIn(reporting.SHEET_RUN_CONFIG, missing)


class TestReportingHelperRows(unittest.TestCase):
    def test_coefficient_rows_include_path_and_wfc_metadata(self) -> None:
        fixture = EvidenceFixture()
        rows = reporting.coefficient_rows(fixture.noncert, digits=4, path_label="NC")

        self.assertEqual(len(rows), 3)
        for row in rows:
            self.assertEqual(row["path_label"], "NC")
            self.assertEqual(row["mode"], fixture.noncert.mode)
            self.assertIn("wfc_trace_id", row)
            self.assertIn("wfc_status", row)

    def test_ingress_rows_flatten_trace_payload(self) -> None:
        class FakeIngressResult:
            def as_dict(self) -> dict[str, object]:
                return {"trace": {"trace_id": "T1", "k_min": -1}, "digits": {0: 1}}

        rows = reporting.ingress_rows((FakeIngressResult(),))

        self.assertEqual(rows[0]["trace_trace_id"], "T1")
        self.assertEqual(rows[0]["trace_k_min"], -1)
        self.assertIn("digits", rows[0])

    def test_audit_rows_and_module_summary_rows(self) -> None:
        report = audit.audit_project(Path(__file__).resolve().parent, stage=audit.STAGE_FINAL_PACKAGE)
        module_rows = reporting.audit_module_summary_rows(report)
        violation_rows = reporting.audit_rows(report)

        self.assertGreater(len(module_rows), 0)
        self.assertTrue(all("module" in row and "status" in row for row in module_rows))
        self.assertEqual(violation_rows, tuple())

    def test_invalid_result_type_is_rejected_by_coefficient_rows(self) -> None:
        with self.assertRaises(TypeError):
            reporting.coefficient_rows(object())  # type: ignore[arg-type]

    def test_gold_reference_without_coefficient_records_is_rejected(self) -> None:
        with self.assertRaises(TypeError):
            reporting.gold_coefficient_rows(object())


class TestSidecarWriting(unittest.TestCase):
    def test_write_table_csv_creates_csv_file(self) -> None:
        table = reporting.ReportingTable("TestTable", ({"a": 1, "b": "x"}, {"a": 2, "b": "y"}))
        with tempfile.TemporaryDirectory() as tmp:
            path = reporting.write_table_csv(table, tmp)
            self.assertTrue(Path(path).exists())
            with Path(path).open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))

        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["a"], "1")

    def test_write_reporting_bundle_sidecars_writes_all_tables_and_manifest(self) -> None:
        fixture = EvidenceFixture()
        bundle = fixture.bundle()
        with tempfile.TemporaryDirectory() as tmp:
            result = reporting.write_reporting_bundle_sidecars(bundle, tmp)
            files = result.as_dict()["files"]

            self.assertEqual(len(files), len(reporting.DEFAULT_SHEET_ORDER) + 1)
            self.assertIn("reporting_bundle_manifest.json", files)
            manifest = json.loads(Path(files["reporting_bundle_manifest.json"]).read_text(encoding="utf-8"))
            self.assertEqual(manifest["reference_label"], reporting.REPORTING_REFERENCE_LABEL)
            self.assertTrue(Path(files[f"{reporting.SHEET_WFC_OPERATION_TRACE}.csv"]).exists())

    def test_write_selected_sidecars_only_writes_selected_tables(self) -> None:
        tables = (
            reporting.ReportingTable("A", ({"x": 1},)),
            reporting.ReportingTable("B", ({"y": 2},)),
        )
        with tempfile.TemporaryDirectory() as tmp:
            result = reporting.write_selected_sidecars(tables, tmp)
            files = result.as_dict()["files"]

        self.assertEqual(set(files), {"A.csv", "B.csv"})

    def test_empty_table_csv_is_allowed(self) -> None:
        table = reporting.ReportingTable("Empty", tuple())
        with tempfile.TemporaryDirectory() as tmp:
            path = reporting.write_table_csv(table, tmp)
            self.assertEqual(Path(path).read_text(encoding="utf-8"), "")


def production_tree_without_main() -> ast.Module:
    source = inspect.getsource(reporting)
    tree = ast.parse(source)
    body = []
    for index, node in enumerate(tree.body):
        if index == 0 and isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue
        if isinstance(node, ast.If):
            test = node.test
            is_main_guard = (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Name)
                and test.left.id == "__name__"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.Eq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == "__main__"
            )
            if is_main_guard:
                continue
        body.append(node)
    return ast.Module(body=body, type_ignores=[])


def production_source_without_main() -> str:
    tree = production_tree_without_main()
    return ast.unparse(tree)

class TestReportingBoundarySafety(unittest.TestCase):
    def test_reporting_source_has_no_forbidden_imports_or_construction_calls(self) -> None:
        tree = production_tree_without_main()

        forbidden_import_roots = {
            "decimal",
            "fractions",
            "numpy",
            "sympy",
            "openpyxl",
            "pandas",
            "xlrd",
            "pyxlsb",
            "ingress",
            "gold_reference",
        }
        forbidden_calls = {
            "Decimal",
            "Fraction",
            "eval",
            "exec",
            "parse_decimal_string_to_btns",
            "load_root_input_csv",
            "build_gold_polynomial_coefficients",
            "build_gold_polynomial_from_root_strings",
            "build_gold_quadratic_from_root_strings",
            "strict_wfc",
            "select_wfc_candidate",
            "propagate_wfc_candidate",
            "enumerate_wfc_candidates",
            "build_polynomial_coeffs_noncertified",
            "build_polynomial_coeffs_certified_independent",
            "build_polynomial_coeffs_noncertified_matched_depth",
            "certify_operation",
            "certify_coefficient",
            "request_certified_refinement",
            "load_workbook",
            "Workbook",
            "read_excel",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                root = module.split(".")[0]
                self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_reporting_allows_egress_only_for_report_rows(self) -> None:
        tree = production_tree_without_main()
        imported_roots: set[str] = set()
        imported_names: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imported_roots.add(alias.name.split(".")[0])
                    imported_names.add(alias.asname or alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                imported_roots.add(module.split(".")[0] if module else "")
                for alias in node.names:
                    imported_names.add(alias.asname or alias.name)
        self.assertIn("egress", imported_roots)
        self.assertIn("coefficients_to_report_rows", imported_names)
        self.assertNotIn("ingress", imported_roots)
        self.assertNotIn("gold_reference", imported_roots)

    def test_reporting_does_not_mutate_constructed_results(self) -> None:
        fixture = EvidenceFixture()
        before = tuple(coeff.trace_id for coeff in fixture.noncert.coefficients)
        _ = fixture.bundle()
        after = tuple(coeff.trace_id for coeff in fixture.noncert.coefficients)
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main(verbosity=2)
