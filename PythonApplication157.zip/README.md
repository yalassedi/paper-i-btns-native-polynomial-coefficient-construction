# PythonApplication157 — BTNS-Native m=10 Full Strict WFC Campaign, v28

`PythonApplication157.zip` is the consolidated `m = 10` package for the first scientific paper on BTNS/Sahar-3 native balanced-ternary arithmetic. It is promoted from the accepted `PythonApplication156` m=9 package and preserves the same v28 arithmetic, full strict WFC, Certified-path, matched-depth, stress, and reporting discipline.

## Package identity

```text
contract_version = v28
package_name = PythonApplication157
source_base_package = PythonApplication156
m = 10
operation_mode = BTNS_M10_NINTH_STAGE
runner = run_m10_campaign.py
stress_runner = run_m10_stress_campaign.py
reference_label = PythonApplication_BTNS_Native_v28_FULL_STRICT_WFC_MATCHED_DEPTH
```

Because the first executable stage is `m = 2`, the degree ladder is:

```text
m = 2 → First-stage
m = 3 → Second-stage
m = 4 → Third-stage
m = 5 → Fourth-stage
m = 6 → Fifth-stage
m = 7 → Sixth-stage
m = 8 → Seventh-stage
m = 9 → Eighth-stage
m = 10 → Ninth-stage
```

## Current-stage files

```text
run_m10_campaign.py
run_m10_stress_campaign.py
tests_run_m10_campaign.py
tests_run_m10_stress_campaign.py
sample_roots_m10.csv
sample_roots_m10_stress.csv
```

Earlier stage-specific runners, roots, and tests are intentionally omitted from this consolidated distributable package to avoid duplicated campaign scripts. The current package keeps the m = 10 files as the canonical stage files.

## Main m = 10 campaign command

```powershell
Set-Location "D:\03 Project - The Sahar Scientific Tetrahedron\Python\PythonApplication157"

python run_m10_campaign.py --input sample_roots_m10.csv --output btns_m10_output_157 --k-min-grid="-20,-30,-40,-50" --wfc-window-width 8 --decimal-digits 30
```

Expected main outputs include:

```text
btns_m10_output_157/
BTNS_m10_results_v28.xlsx
BTNS_m10_results_v28_workbook_payload.json
run_config.json
manifest.json
settings_signature.json
final_run_summary.json
wfc_operation_trace.csv
wfc_candidate_family.csv
wfc_strict_admissibility.csv
wfc_ablation_summary.csv
matched_depth_fairness.csv
operation_cost_accounting.csv
```

## Stress campaign command

```powershell
python tests_run_m10_stress_campaign.py
python run_m10_stress_campaign.py --output btns_m10_stress_output_157
```

The stress harness is diagnostic evidence. It is not a substitute for the clean production m = 10 campaign. It exercises adaptive Certified refinement/rebuild, strict-empty WFC handling, and WFC policy/window sensitivity.

## Verification commands

```powershell
python run_m10_campaign.py --self-check
python run_m10_stress_campaign.py --self-check
python tests_run_m10_campaign.py
python tests_run_m10_stress_campaign.py
python -m unittest discover -v
```

## Input boundary

`sample_roots_m10.csv` contains ten sensitive-root groups with ten roots per group. Roots 1–10 are active for the m = 10 campaign; all ten roots are active in the final m = 10 campaign. Decimal strings are ingress data only. All coefficient-producing operations remain inside the BTNS arithmetic path.

## Interpretation

A successful m = 10 run should be interpreted as a staged extension of the v28 package. The central evidence remains full strict WFC execution, WFC ablation, independent Certified and Non-Certified construction traces, adaptive governance, matched-depth fairness control, and reproducible artifact generation.
