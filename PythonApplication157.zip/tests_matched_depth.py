"""
tests_matched_depth.py

Unit tests for the matched-depth Non-Certified fairness control used by
PythonApplication157 under Script Contract v28.

These tests verify that matched-depth recomputation is not a separate arithmetic
module.  It is the required third construction path implemented inside
btns_poly.py:

    Certified adaptive/final depth  -> k_min^{cert,final}
    Non-Certified matched-depth     -> k_min^{noncert,matched}=k_min^{cert,final}

The tests ensure that the matched-depth path:
    - recomputes using the Non-Certified controller;
    - does not copy Certified coefficients, traces, WFC traces, candidate choices,
      or decision records;
    - preserves the same roots, WFC policy, window width, and CampaignConfig
      settings required for fairness;
    - emits matched-depth comparison records;
    - is recognized by btns_certified.py governance;
    - remains construction-boundary safe.
"""

from __future__ import annotations

import ast
import inspect
from dataclasses import replace
import unittest

import btns_certified as cert
import btns_core as core
import btns_poly as poly
import btns_wfc as wfc
import reporting


def one(trace_id: str = "ONE", *, k_min: int = 0, k_max: int = 1) -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(trace_id: str = "TWO", *, k_min: int = 0, k_max: int = 1) -> core.BTNSNumber:
    return core.add_btns(
        one(trace_id=f"{trace_id}_A", k_min=k_min, k_max=k_max),
        one(trace_id=f"{trace_id}_B", k_min=k_min, k_max=k_max),
    )


def basic_config(**overrides: object) -> poly.CampaignConfig:
    params: dict[str, object] = {
        "k_min": 0,
        "k_max": 1,
        "trace_prefix": "TEST_MATCHED_DEPTH_V28",
        "wfc_window_width": 0,
        "wfc_policy": wfc.RN_ZERO,
    }
    params.update(overrides)
    return poly.CampaignConfig(**params)


def build_reference_results(
    *,
    k_min: int = 0,
    k_max: int = 1,
    wfc_window_width: int = 0,
    wfc_policy: str = wfc.RN_ZERO,
) -> tuple[core.BTNSNumber, core.BTNSNumber, poly.PolynomialResult, poly.CertifiedPolynomialResult, poly.MatchedDepthPolynomialResult]:
    cfg = basic_config(k_min=k_min, k_max=k_max, wfc_window_width=wfc_window_width, wfc_policy=wfc_policy)
    r1 = one("R1", k_min=k_min, k_max=k_max)
    r2 = two("R2", k_min=k_min, k_max=k_max)
    noncert = poly.build_polynomial_coeffs_noncertified((r1, r2), cfg)
    certified = poly.build_polynomial_coeffs_certified_independent((r1, r2), cfg)
    matched = poly.build_polynomial_coeffs_noncertified_matched_depth(
        (r1, r2),
        certified_final_k_min=cfg.k_min,
        config=cfg,
        certified_result=certified,
    )
    return r1, r2, noncert, certified, matched


class TestMatchedDepthConstruction(unittest.TestCase):
    def test_matched_depth_result_shape_and_mode(self) -> None:
        _, _, _, certified, matched = build_reference_results()

        self.assertIsInstance(matched, poly.MatchedDepthPolynomialResult)
        self.assertEqual(matched.mode, poly.MODE_NONCERTIFIED_MATCHED_DEPTH)
        self.assertEqual(matched.m, 2)
        self.assertEqual(matched.status, poly.STATUS_OK)
        self.assertEqual(matched.certified_final_k_min, certified.coefficients[0].k_min)
        self.assertEqual(len(matched.coefficients), 3)
        self.assertEqual(len(matched.matched_depth_records), 3)

    def test_matched_depth_values_match_certified_at_same_depth(self) -> None:
        _, _, _, certified, matched = build_reference_results()

        for certified_coeff, matched_coeff in zip(certified.coefficients, matched.coefficients):
            self.assertTrue(core.btns_equal_digits(certified_coeff, matched_coeff))

        self.assertTrue(
            all(record.matched_depth_comparison == poly.MATCHED_DEPTH_EQUAL for record in matched.matched_depth_records)
        )

    def test_matched_depth_trace_ids_are_not_copied_from_certified(self) -> None:
        _, _, _, certified, matched = build_reference_results()

        for certified_coeff, matched_coeff in zip(certified.coefficients, matched.coefficients):
            self.assertNotEqual(certified_coeff.trace_id, matched_coeff.trace_id)
            self.assertNotEqual(certified_coeff.wfc_trace_id, matched_coeff.wfc_trace_id)

        for record in matched.matched_depth_records:
            self.assertNotEqual(record.certified_trace_id, record.matched_trace_id)

    def test_matched_depth_records_use_certified_final_k_min(self) -> None:
        cfg = basic_config(k_min=-1, k_max=1, wfc_window_width=1, wfc_policy=wfc.RN_EVEN)
        r1 = one("R1_NEG", k_min=-1, k_max=1)
        r2 = two("R2_NEG", k_min=-1, k_max=1)
        certified = poly.build_polynomial_coeffs_certified_independent((r1, r2), cfg)
        matched = poly.build_polynomial_coeffs_noncertified_matched_depth(
            (r1, r2),
            certified_final_k_min=-1,
            config=cfg,
            certified_result=certified,
        )

        for record in matched.matched_depth_records:
            self.assertEqual(record.certified_final_k_min, -1)
            self.assertEqual(record.noncert_matched_k_min, -1)
            self.assertEqual(record.matched_depth_comparison, poly.MATCHED_DEPTH_EQUAL)

        self.assertTrue(all(coefficient.k_min == -1 for coefficient in matched.coefficients))

    def test_matched_depth_preserves_wfc_settings(self) -> None:
        _, _, _, _, matched = build_reference_results(k_min=-1, k_max=1, wfc_window_width=1, wfc_policy=wfc.RN_EVEN)

        self.assertGreater(len(matched.wfc_results), 0)
        for result in matched.wfc_results:
            self.assertEqual(result.trace.policy, wfc.RN_EVEN)
            self.assertEqual(result.trace.window_width, 1)
            self.assertTrue(wfc.validate_wfc_trace(result.trace, result.candidates))

    def test_matched_depth_rejects_roots_that_are_not_deep_enough(self) -> None:
        cfg = basic_config(k_min=0, k_max=1, wfc_window_width=0)
        r1 = one("R1_SHALLOW", k_min=0, k_max=1)
        r2 = two("R2_SHALLOW", k_min=0, k_max=1)
        certified = poly.build_polynomial_coeffs_certified_independent((r1, r2), cfg)

        with self.assertRaises(ValueError):
            poly.build_polynomial_coeffs_noncertified_matched_depth(
                (r1, r2),
                certified_final_k_min=-1,
                config=cfg,
                certified_result=certified,
            )

    def test_matched_depth_can_run_without_certified_result_but_records_are_empty(self) -> None:
        cfg = basic_config()
        r1 = one("R1_NO_CERT")
        r2 = two("R2_NO_CERT")
        matched = poly.build_polynomial_coeffs_noncertified_matched_depth(
            (r1, r2),
            certified_final_k_min=cfg.k_min,
            config=cfg,
            certified_result=None,
        )

        self.assertEqual(matched.mode, poly.MODE_NONCERTIFIED_MATCHED_DEPTH)
        self.assertEqual(matched.matched_depth_records, tuple())
        self.assertEqual(len(matched.coefficients), 3)


class TestMatchedDepthGovernance(unittest.TestCase):
    def test_certified_governance_accepts_clean_matched_depth_recomputation(self) -> None:
        _, _, _, certified, matched = build_reference_results()
        records = cert.compare_certified_path_to_matched_depth_noncertified_path(certified, matched)

        self.assertEqual(len(records), 3)
        self.assertTrue(all(row.matched_depth_comparison == poly.MATCHED_DEPTH_EQUAL for row in records))
        self.assertTrue(all(not row.copied_trace_invalid for row in records))
        self.assertTrue(all(row.certified_trace_id != row.matched_trace_id for row in records))

    def test_certified_governance_flags_copied_certified_outputs_as_invalid(self) -> None:
        _, _, _, certified, _ = build_reference_results()
        copied = poly.MatchedDepthPolynomialResult(
            mode=poly.MODE_NONCERTIFIED_MATCHED_DEPTH,
            m=certified.m,
            coefficients=certified.coefficients,
            traces=certified.traces,
            status=certified.status,
            message="BAD copied Certified output",
            wfc_results=certified.wfc_results,
            certified_final_k_min=0,
            matched_depth_records=tuple(),
        )

        records = cert.compare_certified_path_to_matched_depth_noncertified_path(certified, copied)

        self.assertTrue(all(row.copied_trace_invalid for row in records))
        self.assertTrue(all(row.matched_depth_comparison == poly.MATCHED_DEPTH_NOT_RUN_INVALID for row in records))

    def test_certified_governance_detects_matched_depth_value_difference(self) -> None:
        _, _, _, certified, matched = build_reference_results()
        wrong_constant = core.make_btns_number_from_digits(
            {0: 1},
            k_min=0,
            k_max=1,
            source_tag=core.SOURCE_TEST,
            trace_id="WRONG_MATCHED_CONSTANT",
        )
        altered_coefficients = matched.coefficients[:-1] + (wrong_constant,)
        altered = replace(matched, coefficients=altered_coefficients)

        records = cert.compare_certified_path_to_matched_depth_noncertified_path(certified, altered)

        self.assertEqual(records[-1].matched_depth_comparison, poly.MATCHED_DEPTH_DIFFERENT)
        self.assertFalse(records[-1].copied_trace_invalid)

    def test_governance_rejects_wrong_result_types(self) -> None:
        _, _, noncert, certified, matched = build_reference_results()

        with self.assertRaises(TypeError):
            cert.compare_certified_path_to_matched_depth_noncertified_path(noncert, matched)  # type: ignore[arg-type]
        with self.assertRaises(TypeError):
            cert.compare_certified_path_to_matched_depth_noncertified_path(certified, noncert)  # type: ignore[arg-type]


class TestMatchedDepthReporting(unittest.TestCase):
    def test_reporting_matched_depth_rows_are_machine_readable(self) -> None:
        _, _, _, _, matched = build_reference_results()
        rows = reporting.matched_depth_rows(matched)

        self.assertEqual(len(rows), 3)
        for idx, row in enumerate(rows):
            self.assertEqual(row["coefficient_index"], idx)
            self.assertEqual(row["matched_depth_comparison"], poly.MATCHED_DEPTH_EQUAL)
            self.assertEqual(row["mode"], poly.MODE_NONCERTIFIED_MATCHED_DEPTH)
            self.assertEqual(row["m"], 2)
            self.assertIn("certified_trace_id", row)
            self.assertIn("matched_trace_id", row)

    def test_reporting_wfc_ucc_cross_summary_counts_matched_depth_tokens(self) -> None:
        _, _, noncert, certified, matched = build_reference_results()
        rows = reporting.wfc_and_ucc_cross_summary_rows(
            noncertified_result=noncert,
            certified_result=certified,
            matched_result=matched,
        )

        matched_rows = [row for row in rows if row["category"] == "MATCHED_DEPTH"]
        self.assertEqual(len(matched_rows), 1)
        self.assertEqual(matched_rows[0]["token"], poly.MATCHED_DEPTH_EQUAL)
        self.assertEqual(matched_rows[0]["count"], 3)


class TestMatchedDepthBoundarySafety(unittest.TestCase):
    def test_btns_poly_matched_depth_function_does_not_copy_certified_output(self) -> None:
        source = inspect.getsource(poly.build_polynomial_coeffs_noncertified_matched_depth)

        forbidden_fragments = (
            "coefficients=certified_result.coefficients",
            "traces=certified_result.traces",
            "wfc_results=certified_result.wfc_results",
            "return certified_result",
            "base = certified_result",
        )
        for fragment in forbidden_fragments:
            self.assertNotIn(fragment, source)

        self.assertIn("build_polynomial_coeffs_noncertified", source)

    def test_no_separate_btns_matched_depth_module_is_required_or_imported(self) -> None:
        source = inspect.getsource(poly)
        self.assertNotIn("import btns_matched_depth", source)
        self.assertNotIn("from btns_matched_depth", source)
        self.assertTrue(hasattr(poly, "build_polynomial_coeffs_noncertified_matched_depth"))

    def test_matched_depth_path_uses_no_gold_egress_ingress_or_excel_calls(self) -> None:
        source = inspect.getsource(poly.build_polynomial_coeffs_noncertified_matched_depth)
        tree = ast.parse(source)
        forbidden_calls = {
            "parse_decimal_string_to_btns",
            "load_root_input_csv",
            "btns_to_decimal_string_for_report",
            "build_gold_polynomial_coefficients",
            "build_gold_polynomial_from_root_strings",
            "read_excel",
            "load_workbook",
            "Decimal",
            "Fraction",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_matched_depth_result_is_immutable_dataclass_output(self) -> None:
        _, _, _, _, matched = build_reference_results()
        with self.assertRaises(Exception):
            matched.certified_final_k_min = -999  # type: ignore[misc]


if __name__ == "__main__":
    unittest.main(verbosity=2)
