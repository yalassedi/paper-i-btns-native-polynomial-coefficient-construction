"""
tests_gold_reference.py

Unit tests for gold_reference.py, the external evaluation-only gold layer used by
PythonApplication157 under Script Contract v28.

These tests verify that exact external reference values are computed only for
post-construction evaluation/reporting and never for BTNS coefficient
construction, WFC candidate selection, or Certified construction decisions.

They cover:
    - exact decimal/scientific-notation parsing into Fraction values;
    - exact gold polynomial expansion for m=2 and m=3;
    - GoldPolynomialReference records and dictionaries;
    - BTNS finite-center and interval conversion for comparison only;
    - coefficient-to-gold comparison rows and summaries;
    - power-of-3 scaled diagnostic helpers;
    - rejection of invalid/non-finite inputs;
    - boundary safety: no ingress, egress, WFC, polynomial construction,
      Certified path, Excel, NumPy, or SymPy calls inside gold_reference.py.
"""

from __future__ import annotations

import ast
import inspect
from fractions import Fraction
import unittest

import btns_core as core
import gold_reference as gold


def btns_one(trace_id: str = "ONE") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=0,
        k_max=0,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def btns_minus_three(trace_id: str = "MINUS_THREE") -> core.BTNSNumber:
    # -3 = -1 * 3^1.
    return core.make_btns_number_from_digits(
        {1: -1},
        k_min=0,
        k_max=1,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def btns_two(trace_id: str = "TWO") -> core.BTNSNumber:
    # 2 = 1 * 3^1 - 1.
    return core.make_btns_number_from_digits(
        {0: -1, 1: 1},
        k_min=0,
        k_max=1,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def btns_one_third(trace_id: str = "ONE_THIRD") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {-1: 1, 0: 0},
        k_min=-1,
        k_max=0,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


class TestGoldParsingAndFormatting(unittest.TestCase):
    def test_parse_decimal_and_scientific_notation_exactly(self) -> None:
        self.assertEqual(gold.parse_root_decimal_string_to_fraction("1.25"), Fraction(5, 4))
        self.assertEqual(gold.parse_root_decimal_string_to_fraction("1e-1"), Fraction(1, 10))
        self.assertEqual(gold.parse_root_decimal_string_to_fraction("-2"), Fraction(-2, 1))

    def test_invalid_or_nonfinite_root_strings_are_rejected(self) -> None:
        for bad in ("", "NaN", "Infinity", "-inf", "abc"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    gold.parse_root_decimal_string_to_fraction(bad)
        with self.assertRaises(TypeError):
            gold.parse_root_decimal_string_to_fraction(1.25)  # type: ignore[arg-type]

    def test_fraction_to_rational_string(self) -> None:
        self.assertEqual(gold.fraction_to_rational_string(Fraction(3, 1)), "3")
        self.assertEqual(gold.fraction_to_rational_string(Fraction(-5, 4)), "-5/4")
        with self.assertRaises(TypeError):
            gold.fraction_to_rational_string("1/3")  # type: ignore[arg-type]

    def test_fraction_to_decimal_string_is_deterministic_truncated(self) -> None:
        self.assertEqual(gold.fraction_to_decimal_string_for_report(Fraction(1, 3), 6), "0.333333")
        self.assertEqual(gold.fraction_to_decimal_string_for_report(Fraction(-5, 4), 3), "-1.250")
        self.assertEqual(gold.fraction_to_decimal_string_for_report(Fraction(2, 1), 0), "2")
        with self.assertRaises(ValueError):
            gold.fraction_to_decimal_string_for_report(Fraction(1, 3), -1)


class TestGoldPolynomialExpansion(unittest.TestCase):
    def test_build_gold_quadratic_coefficients_for_roots_one_and_two(self) -> None:
        ref = gold.build_gold_quadratic_from_root_strings("1", "2")

        self.assertEqual(ref.m, 2)
        self.assertEqual(ref.coefficients, (Fraction(1), Fraction(-3), Fraction(2)))
        self.assertTrue(ref.reference_id.startswith("GOLD_REF_"))
        self.assertEqual(ref.root_strings, ("1", "2"))

    def test_general_gold_polynomial_expansion_for_three_roots(self) -> None:
        coeffs = gold.build_gold_polynomial_coefficients((Fraction(1), Fraction(2), Fraction(3)))
        self.assertEqual(coeffs, (Fraction(1), Fraction(-6), Fraction(11), Fraction(-6)))

    def test_build_gold_polynomial_from_root_strings_honors_m_prefix(self) -> None:
        ref = gold.build_gold_polynomial_from_root_strings(("1", "2", "3"), m=2)
        self.assertEqual(ref.m, 2)
        self.assertEqual(ref.coefficients, (Fraction(1), Fraction(-3), Fraction(2)))
        with self.assertRaises(ValueError):
            gold.build_gold_polynomial_from_root_strings(("1",), m=2)
        with self.assertRaises(ValueError):
            gold.build_gold_polynomial_from_root_strings(tuple())

    def test_gold_reference_records_and_dict_are_machine_readable(self) -> None:
        ref = gold.build_gold_quadratic_from_root_strings("1", "2")
        records = ref.coefficient_records(digits=4)
        as_dict = ref.as_dict(digits=4)

        self.assertEqual(len(records), 3)
        self.assertEqual(records[0].as_dict()["degree_power"], 2)
        self.assertEqual(records[1].rational_string, "-3")
        self.assertEqual(records[2].decimal_string, "2.0000")
        self.assertEqual(as_dict["m"], 2)
        self.assertIn("coefficients", as_dict)


class TestBTNSComparisonHelpers(unittest.TestCase):
    def test_btns_finite_center_fraction_for_basic_numbers(self) -> None:
        self.assertEqual(gold.btns_finite_center_fraction(btns_one()), Fraction(1))
        self.assertEqual(gold.btns_finite_center_fraction(btns_minus_three()), Fraction(-3))
        self.assertEqual(gold.btns_finite_center_fraction(btns_two()), Fraction(2))
        self.assertEqual(gold.btns_finite_center_fraction(btns_one_third()), Fraction(1, 3))
        with self.assertRaises(ValueError):
            gold.btns_finite_center_fraction(object())  # type: ignore[arg-type]

    def test_tail_abs_and_interval_fraction(self) -> None:
        tail = core.TailBound(
            lower_exp=-1,
            abs_bound_num=1,
            abs_bound_den_power3=1,
            policy=core.TAIL_REFINEMENT,
            source=core.SOURCE_CERTIFIED,
        )
        uncertain = core.BTNSNumber(
            digits={0: 1},
            k_min=0,
            k_max=0,
            tail_bound=tail,
            canonicality_flag=core.CANONICAL_LEGAL,
            source_tag=core.SOURCE_CERTIFIED,
            trace_id="UNCERTAIN",
        )

        self.assertEqual(gold.tail_abs_fraction(tail), Fraction(1, 3))
        self.assertEqual(gold.btns_interval_fraction(uncertain), (Fraction(2, 3), Fraction(1), Fraction(4, 3)))

    def test_compare_coefficients_to_gold_zero_error(self) -> None:
        ref = gold.build_gold_quadratic_from_root_strings("1", "2")
        coeffs = (btns_one("C0"), btns_minus_three("C1"), btns_two("C2"))
        records = gold.compare_coefficients_to_gold(coeffs, ref.coefficients, digits=6)

        self.assertEqual(len(records), 3)
        self.assertTrue(all(row.error_sign_token == gold.ERROR_ZERO for row in records))
        self.assertTrue(all(row.abs_error_numerator == 0 for row in records))
        self.assertEqual(records[1].gold_decimal, "-3.000000")
        self.assertEqual(records[2].btns_center_decimal, "2.000000")

    def test_compare_coefficient_to_gold_positive_and_negative_errors(self) -> None:
        too_high = gold.compare_btns_coefficient_to_gold(btns_two("TOO_HIGH"), Fraction(1), 0, digits=3)
        too_low = gold.compare_btns_coefficient_to_gold(btns_one("TOO_LOW"), Fraction(2), 0, digits=3)

        self.assertEqual(too_high.error_sign_token, gold.ERROR_POSITIVE)
        self.assertEqual(too_low.error_sign_token, gold.ERROR_NEGATIVE)
        self.assertEqual(too_high.error_decimal, "1.000")
        self.assertEqual(too_low.error_decimal, "-1.000")

    def test_compare_coefficients_to_gold_rejects_count_mismatch(self) -> None:
        with self.assertRaises(ValueError):
            gold.compare_coefficients_to_gold((btns_one(),), (Fraction(1), Fraction(2)))

    def test_summarize_gold_comparisons(self) -> None:
        ref = gold.build_gold_quadratic_from_root_strings("1", "2")
        exact_records = gold.compare_coefficients_to_gold(
            (btns_one("C0"), btns_minus_three("C1"), btns_two("C2")),
            ref.coefficients,
        )
        exact_summary = gold.summarize_gold_comparisons(exact_records)

        self.assertEqual(exact_summary.coefficient_count, 3)
        self.assertEqual(exact_summary.zero_error_count, 3)
        self.assertEqual(exact_summary.max_abs_error_numerator, 0)

        empty_summary = gold.summarize_gold_comparisons(tuple())
        self.assertEqual(empty_summary.coefficient_count, 0)
        self.assertEqual(empty_summary.max_abs_error_denominator, 1)


class TestPower3DiagnosticHelpers(unittest.TestCase):
    def test_fraction_to_exact_power3_scaled_accepts_power3_denominators(self) -> None:
        value = gold.fraction_to_exact_power3_scaled(Fraction(2, 9))

        self.assertEqual(value.scaled_integer, 2)
        self.assertEqual(value.den_power3, 2)
        self.assertTrue(value.exact)
        self.assertEqual(value.rounding_policy, "EXACT_POWER3")

    def test_fraction_to_exact_power3_scaled_rejects_other_denominators(self) -> None:
        with self.assertRaises(ValueError):
            gold.fraction_to_exact_power3_scaled(Fraction(1, 6))
        with self.assertRaises(TypeError):
            gold.fraction_to_exact_power3_scaled("1/9")  # type: ignore[arg-type]

    def test_fraction_to_power3_scaled_rounding_policies(self) -> None:
        ties_zero = gold.fraction_to_power3_scaled(
            Fraction(1, 2),
            den_power3=1,
            rounding_policy=gold.ROUND_NEAREST_TIES_TO_ZERO,
        )
        ties_even = gold.fraction_to_power3_scaled(
            Fraction(1, 2),
            den_power3=1,
            rounding_policy=gold.ROUND_NEAREST_TIES_TO_EVEN,
        )
        trunc_neg = gold.fraction_to_power3_scaled(
            Fraction(-1, 2),
            den_power3=0,
            rounding_policy=gold.ROUND_TRUNCATE_TOWARD_ZERO,
        )
        floor_neg = gold.fraction_to_power3_scaled(
            Fraction(-1, 2),
            den_power3=0,
            rounding_policy=gold.ROUND_FLOOR_BALANCED,
        )

        self.assertEqual(ties_zero.scaled_integer, 1)
        self.assertEqual(ties_even.scaled_integer, 2)
        self.assertFalse(ties_zero.exact)
        self.assertEqual(trunc_neg.scaled_integer, 0)
        self.assertEqual(floor_neg.scaled_integer, -1)

    def test_fraction_to_power3_bracket(self) -> None:
        bracket = gold.fraction_to_power3_bracket(Fraction(1, 2), den_power3=1)

        self.assertEqual(bracket.lower_scaled_integer, 1)
        self.assertEqual(bracket.upper_scaled_integer, 2)
        self.assertEqual(bracket.den_power3, 1)
        self.assertEqual(bracket.as_dict()["den_power3"], 1)

    def test_power3_helpers_reject_invalid_arguments(self) -> None:
        with self.assertRaises(ValueError):
            gold.fraction_to_power3_scaled(Fraction(1), den_power3=-1)
        with self.assertRaises(ValueError):
            gold.fraction_to_power3_scaled(Fraction(1), den_power3=1, rounding_policy="BAD")
        with self.assertRaises(ValueError):
            gold.fraction_to_power3_bracket(Fraction(1), den_power3=-1)


class TestGoldReferenceBoundarySafety(unittest.TestCase):
    def test_gold_reference_source_has_no_forbidden_imports_or_construction_calls(self) -> None:
        source = inspect.getsource(gold)
        tree = ast.parse(source)

        forbidden_import_roots = {
            "decimal",
            "numpy",
            "sympy",
            "openpyxl",
            "pandas",
            "xlrd",
            "pyxlsb",
            "ingress",
            "egress",
            "btns_poly",
            "btns_certified",
            "btns_wfc",
            "reporting",
        }
        forbidden_calls = {
            "Decimal",
            "eval",
            "exec",
            "parse_decimal_string_to_btns",
            "load_root_input_csv",
            "btns_to_decimal_string_for_report",
            "build_polynomial_coeffs_noncertified",
            "build_polynomial_coeffs_certified_independent",
            "build_polynomial_coeffs_noncertified_matched_depth",
            "strict_wfc",
            "select_wfc_candidate",
            "certify_operation",
            "certify_coefficient",
            "request_certified_refinement",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                root = module.split(".")[0]
                self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_fraction_is_allowed_only_for_external_gold_reference(self) -> None:
        source = inspect.getsource(gold)
        tree = ast.parse(source)
        has_fraction_import = False
        has_decimal_import = False
        has_decimal_call = False
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if node.module == "fractions" and any(alias.name == "Fraction" for alias in node.names):
                    has_fraction_import = True
                if node.module == "decimal":
                    has_decimal_import = True
            elif isinstance(node, ast.Import):
                if any(alias.name.split(".")[0] == "decimal" for alias in node.names):
                    has_decimal_import = True
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Decimal":
                has_decimal_call = True
        self.assertTrue(has_fraction_import)
        self.assertFalse(has_decimal_import)
        self.assertFalse(has_decimal_call)

    def test_gold_reference_imports_only_btns_core_from_project_modules(self) -> None:
        source = inspect.getsource(gold)
        self.assertIn("from btns_core import", source)
        self.assertNotIn("import ingress", source)
        self.assertNotIn("import egress", source)
        self.assertNotIn("import btns_poly", source)
        self.assertNotIn("import btns_certified", source)
        self.assertNotIn("import btns_wfc", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
