"""
tests_poly.py

Unit tests for btns_poly.py, the BTNS-native m=2 polynomial construction
layer used by PythonApplication157 under Script Contract v28.

These tests verify that the polynomial layer preserves the stable P129/v22
integer-only BTNS construction while enforcing the v28 coefficient-commitment
rules:
    - Non-Certified and Certified paths are structurally distinct;
    - a_1 and a_2 are built from BTNS primitives only;
    - every committed coefficient carries a WFC trace;
    - exact leading coefficients are explicitly WFC_NOT_APPLICABLE;
    - matched-depth Non-Certified recomputation is a separate controller;
    - no gold/egress/Excel/Decimal/Fraction/NumPy/SymPy construction leakage
      appears in btns_poly.py.
"""

from __future__ import annotations

import inspect
import unittest

import btns_core as core
import btns_poly as poly
import btns_wfc as wfc


def one(k_min: int = 0, k_max: int = 0, trace_id: str = "ONE") -> core.BTNSNumber:
    return core.make_btns_number_from_digits(
        {0: 1},
        k_min=k_min,
        k_max=k_max,
        source_tag=core.SOURCE_TEST,
        trace_id=trace_id,
    )


def two(k_min: int = 0, k_max: int = 0, trace_id: str = "TWO") -> core.BTNSNumber:
    return core.add_btns(one(k_min=k_min, k_max=k_max, trace_id=trace_id + "_BASE"), one(k_min=k_min, k_max=k_max, trace_id=trace_id + "_BASE2"))


def basic_config(**overrides: object) -> poly.CampaignConfig:
    params: dict[str, object] = {
        "k_min": 0,
        "k_max": 0,
        "trace_prefix": "TEST_POLY_V28",
        "wfc_window_width": 0,
        "wfc_policy": wfc.RN_ZERO,
    }
    params.update(overrides)
    return poly.CampaignConfig(**params)


def expected_a1_for_roots_1_and_2() -> core.BTNSNumber:
    # -(1 + 2) = -3 = -1 * 3^1.
    return core.make_btns_number_from_digits(
        {1: -1},
        k_min=0,
        k_max=1,
        source_tag=core.SOURCE_TEST,
        trace_id="EXPECTED_A1",
    )


def expected_a2_for_roots_1_and_2() -> core.BTNSNumber:
    # 1 * 2 = 2 = 1 * 3^1 - 1.
    return core.make_btns_number_from_digits(
        {0: -1, 1: 1},
        k_min=0,
        k_max=1,
        source_tag=core.SOURCE_TEST,
        trace_id="EXPECTED_A2",
    )


class TestCampaignConfig(unittest.TestCase):
    def test_config_builds_wfc_config(self) -> None:
        cfg = basic_config(wfc_window_width=1, wfc_policy=wfc.RN_EVEN)
        wfc_cfg = cfg.make_wfc_config()
        self.assertEqual(wfc_cfg.window_width, 1)
        self.assertEqual(wfc_cfg.policy, wfc.RN_EVEN)
        self.assertEqual(wfc_cfg.boundary_mode, wfc.LOWER_BOUNDARY_COMPENSATED)

    def test_config_rejects_bad_wfc_policy(self) -> None:
        with self.assertRaises(ValueError):
            basic_config(wfc_policy="RN-BAD")

    def test_config_rejects_negative_window_width(self) -> None:
        with self.assertRaises(ValueError):
            basic_config(wfc_window_width=-1)


class TestNonCertifiedM2Construction(unittest.TestCase):
    def test_noncertified_quadratic_coefficients_for_roots_one_and_two(self) -> None:
        cfg = basic_config()
        result = poly.build_quadratic_coeffs_noncertified(one(trace_id="R1"), two(trace_id="R2"), cfg)

        self.assertEqual(result.mode, poly.MODE_NONCERTIFIED)
        self.assertEqual(result.m, 2)
        self.assertEqual(result.status, poly.STATUS_OK)
        self.assertEqual(len(result.coefficients), 3)
        self.assertTrue(core.btns_equal_digits(result.coefficients[0], one(trace_id="EXPECTED_LEADING")))
        self.assertTrue(core.btns_equal_digits(result.coefficients[1], expected_a1_for_roots_1_and_2()))
        self.assertTrue(core.btns_equal_digits(result.coefficients[2], expected_a2_for_roots_1_and_2()))

    def test_noncertified_committed_coefficients_have_wfc_traces(self) -> None:
        cfg = basic_config()
        result = poly.build_quadratic_coeffs_noncertified(one(trace_id="R1"), two(trace_id="R2"), cfg)

        self.assertEqual(result.coefficients[0].wfc_status, wfc.WFC_NOT_APPLICABLE)
        for coeff in result.coefficients:
            self.assertIsNotNone(coeff.wfc_trace_id)
            self.assertIsNotNone(coeff.wfc_status)
            self.assertTrue(core.validate_digits(coeff))

        nonleading = result.coefficients[1:]
        self.assertTrue(all(coeff.wfc_status != wfc.WFC_NOT_APPLICABLE for coeff in nonleading))

    def test_noncertified_wfc_result_traces_validate(self) -> None:
        cfg = basic_config()
        result = poly.build_quadratic_coeffs_noncertified(one(trace_id="R1"), two(trace_id="R2"), cfg)

        self.assertGreaterEqual(len(result.wfc_results), 3)
        for wfc_result in result.wfc_results:
            self.assertTrue(wfc.validate_wfc_trace(wfc_result.trace, wfc_result.candidates))

    def test_noncertified_traces_expose_wfc_fields_for_commits(self) -> None:
        cfg = basic_config()
        result = poly.build_quadratic_coeffs_noncertified(one(trace_id="R1"), two(trace_id="R2"), cfg)
        commit_traces = [trace for trace in result.traces if "COMMIT" in trace.operation_type]

        self.assertGreaterEqual(len(commit_traces), 2)
        for trace in commit_traces:
            self.assertTrue(trace.wfc_trace_id)
            self.assertTrue(trace.wfc_status)
            self.assertEqual(trace.wfc_window_width, cfg.wfc_window_width)
            self.assertEqual(trace.wfc_policy, cfg.wfc_policy)
            self.assertGreaterEqual(trace.wfc_candidate_count, 1)


class TestCertifiedIndependentConstruction(unittest.TestCase):
    def test_certified_path_matches_values_but_has_distinct_traces(self) -> None:
        cfg = basic_config()
        r1 = one(trace_id="R1")
        r2 = two(trace_id="R2")
        noncert = poly.build_quadratic_coeffs_noncertified(r1, r2, cfg)
        cert = poly.build_quadratic_coeffs_certified_independent(r1, r2, cfg)

        self.assertEqual(cert.mode, poly.MODE_CERTIFIED)
        self.assertEqual(cert.m, 2)
        self.assertEqual(cert.status, poly.STATUS_OK)
        self.assertTrue(cert.certified_path_id)
        self.assertGreater(len(cert.certified_decision_chain), 0)
        self.assertGreater(len(cert.operation_certificates), 0)

        for idx in range(3):
            self.assertTrue(core.btns_equal_digits(cert.coefficients[idx], noncert.coefficients[idx]))
            self.assertNotEqual(cert.coefficients[idx].trace_id, noncert.coefficients[idx].trace_id)

    def test_certified_coefficients_have_certified_source_and_wfc_traces(self) -> None:
        cfg = basic_config()
        cert = poly.build_quadratic_coeffs_certified_independent(one(trace_id="R1"), two(trace_id="R2"), cfg)

        for coeff in cert.coefficients:
            self.assertEqual(coeff.source_tag, core.SOURCE_CERTIFIED)
            self.assertIsNotNone(coeff.wfc_trace_id)
            self.assertIsNotNone(coeff.wfc_status)

        self.assertEqual(cert.coefficients[0].wfc_status, wfc.WFC_NOT_APPLICABLE)
        self.assertTrue(all(dec.certified_construction_token == poly.CERT_ACCEPT for dec in cert.certified_decision_chain))

    def test_certified_operation_certificates_include_wfc_fields_for_commit_steps(self) -> None:
        cfg = basic_config()
        cert = poly.build_quadratic_coeffs_certified_independent(one(trace_id="R1"), two(trace_id="R2"), cfg)

        wfc_certificates = [certif for certif in cert.operation_certificates if certif.wfc_trace_id]
        self.assertGreaterEqual(len(wfc_certificates), 3)
        for certif in wfc_certificates:
            self.assertIsNotNone(certif.wfc_status)
            self.assertIsNotNone(certif.wfc_window_width)
            self.assertIsNotNone(certif.wfc_policy)
            self.assertIn(certif.decision_token, {poly.CERT_ACCEPT, poly.CERT_TUBE_HOLD})

    def test_certified_compatibility_entry_point_uses_independent_controller(self) -> None:
        cfg = basic_config()
        result = poly.build_polynomial_coeffs_certified([one(trace_id="R1"), two(trace_id="R2")], cfg)
        self.assertIsInstance(result, poly.CertifiedPolynomialResult)
        self.assertEqual(result.mode, poly.MODE_CERTIFIED)
        self.assertTrue(result.certified_path_id)


class TestMatchedDepthControl(unittest.TestCase):
    def test_matched_depth_recomputes_noncertified_and_reports_equal_values(self) -> None:
        cfg = basic_config()
        r1 = one(trace_id="R1")
        r2 = two(trace_id="R2")
        cert = poly.build_quadratic_coeffs_certified_independent(r1, r2, cfg)
        matched = poly.build_quadratic_coeffs_noncertified_matched_depth(r1, r2, cfg.k_min, cfg, cert)

        self.assertEqual(matched.mode, poly.MODE_NONCERTIFIED_MATCHED_DEPTH)
        self.assertEqual(matched.m, 2)
        self.assertEqual(matched.certified_final_k_min, cfg.k_min)
        self.assertEqual(len(matched.matched_depth_records), 3)
        self.assertTrue(all(record.matched_depth_comparison == poly.MATCHED_DEPTH_EQUAL for record in matched.matched_depth_records))
        for record in matched.matched_depth_records:
            self.assertNotEqual(record.certified_trace_id, record.matched_trace_id)

    def test_matched_depth_without_certified_result_still_recomputes(self) -> None:
        cfg = basic_config()
        matched = poly.build_quadratic_coeffs_noncertified_matched_depth(one(trace_id="R1"), two(trace_id="R2"), cfg.k_min, cfg)

        self.assertEqual(matched.mode, poly.MODE_NONCERTIFIED_MATCHED_DEPTH)
        self.assertEqual(len(matched.matched_depth_records), 0)
        self.assertTrue(all(coeff.source_tag == core.SOURCE_COEFFICIENT for coeff in matched.coefficients))

    def test_matched_depth_rejects_roots_not_projected_deep_enough(self) -> None:
        cfg = basic_config()
        with self.assertRaises(ValueError):
            poly.build_quadratic_coeffs_noncertified_matched_depth(
                one(trace_id="R1"),
                two(trace_id="R2"),
                certified_final_k_min=-2,
                config=cfg,
            )


class TestWindowAndTraceVariants(unittest.TestCase):
    def test_window_width_one_path_preserves_wfc_width_in_traces(self) -> None:
        cfg = basic_config(k_min=-1, k_max=0, wfc_window_width=1)
        r1 = one(k_min=-1, k_max=0, trace_id="R1")
        r2 = two(k_min=-1, k_max=0, trace_id="R2")
        result = poly.build_quadratic_coeffs_noncertified(r1, r2, cfg)

        self.assertEqual(result.m, 2)
        for wfc_result in result.wfc_results:
            self.assertEqual(wfc_result.trace.window_width, 1)
            self.assertTrue(wfc.validate_wfc_trace(wfc_result.trace, wfc_result.candidates))

    def test_coefficient_digit_table_contains_index_trace_status_and_digits(self) -> None:
        cfg = basic_config()
        result = poly.build_quadratic_coeffs_noncertified(one(trace_id="R1"), two(trace_id="R2"), cfg)
        rows = poly.coefficient_digit_table(result)

        self.assertEqual(len(rows), 3)
        for idx, trace_id, status, digit_string in rows:
            self.assertIsInstance(idx, int)
            self.assertTrue(trace_id)
            self.assertTrue(status)
            self.assertTrue(digit_string.startswith("["))


class TestInputAndBoundarySafety(unittest.TestCase):
    def test_empty_root_list_is_rejected(self) -> None:
        cfg = basic_config()
        with self.assertRaises(ValueError):
            poly.build_polynomial_coeffs_noncertified([], cfg)

    def test_non_btns_root_is_rejected(self) -> None:
        cfg = basic_config()
        with self.assertRaises(ValueError):
            poly.build_polynomial_coeffs_noncertified([object()], cfg)  # type: ignore[list-item]

    def test_btns_poly_source_does_not_import_forbidden_construction_dependencies(self) -> None:
        source = inspect.getsource(poly)
        forbidden_fragments = (
            "from decimal",
            "import decimal",
            "Decimal(",
            "from fractions",
            "import fractions",
            "Fraction(",
            "import numpy",
            "from numpy",
            "np.",
            "import sympy",
            "from sympy",
            "openpyxl.load_workbook",
            "pandas.read_excel",
            "xlrd",
            "pyxlsb",
            "gold_reference",
            "btns_to_decimal_string_for_report",
            "to_decimal(",
            "as_decimal(",
        )
        for fragment in forbidden_fragments:
            self.assertNotIn(fragment, source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
