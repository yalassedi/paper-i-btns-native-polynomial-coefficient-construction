"""
gold_reference.py

External gold-reference layer for PythonApplication157 under Script Contract v28.

This module is evaluation/reporting-only. It computes exact external reference
polynomial coefficients from the original decimal root strings using rational
arithmetic, and it compares constructed BTNS coefficients against those external
references after construction has completed.

Allowed here by contract:
    - exact Fraction parsing of finite decimal/scientific-notation strings;
    - exact rational polynomial expansion for external reference values;
    - post-construction error/comparison rows;
    - optional power-of-3 scaled diagnostic values for certificate/report use.

Forbidden here by design:
    - no BTNS coefficient construction;
    - no WFC candidate selection;
    - no Certified construction decisions;
    - no ingress-side root projection;
    - no egress/reporting feedback into construction;
    - no Excel workbook reading;
    - no NumPy/SymPy polynomial or root solving.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
from typing import Iterable, Optional, Sequence, Tuple

from btns_core import BTNSNumber, TailBound, validate_digits


RADIX = 3
DEFAULT_GOLD_DECIMAL_DIGITS = 30

TRUE = "TRUE"
TUBE = "TUBE"
FALSE = "FALSE"

ERROR_ZERO = "ERROR_ZERO"
ERROR_POSITIVE = "ERROR_POSITIVE"
ERROR_NEGATIVE = "ERROR_NEGATIVE"

ROUND_TRUNCATE_TOWARD_ZERO = "ROUND_TRUNCATE_TOWARD_ZERO"
ROUND_NEAREST_TIES_TO_ZERO = "ROUND_NEAREST_TIES_TO_ZERO"
ROUND_NEAREST_TIES_TO_EVEN = "ROUND_NEAREST_TIES_TO_EVEN"
ROUND_FLOOR_BALANCED = "ROUND_FLOOR_BALANCED"

ALLOWED_POWER3_ROUNDING_POLICIES = {
    ROUND_TRUNCATE_TOWARD_ZERO,
    ROUND_NEAREST_TIES_TO_ZERO,
    ROUND_NEAREST_TIES_TO_EVEN,
    ROUND_FLOOR_BALANCED,
}


@dataclass(frozen=True)
class GoldCoefficientRecord:
    """External gold coefficient record in leading-to-constant order."""

    coefficient_index: int
    degree_power: int
    numerator: int
    denominator: int
    rational_string: str
    decimal_string: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "degree_power": self.degree_power,
            "numerator": self.numerator,
            "denominator": self.denominator,
            "rational_string": self.rational_string,
            "decimal_string": self.decimal_string,
        }


@dataclass(frozen=True)
class GoldPolynomialReference:
    """Exact external polynomial reference P(x)=prod_i (x-r_i)."""

    m: int
    root_strings: Tuple[str, ...]
    root_values: Tuple[Fraction, ...]
    coefficients: Tuple[Fraction, ...]
    reference_id: str

    def coefficient_records(self, digits: int = DEFAULT_GOLD_DECIMAL_DIGITS) -> Tuple[GoldCoefficientRecord, ...]:
        rows = []
        for idx, value in enumerate(self.coefficients):
            rows.append(
                GoldCoefficientRecord(
                    coefficient_index=idx,
                    degree_power=self.m - idx,
                    numerator=value.numerator,
                    denominator=value.denominator,
                    rational_string=fraction_to_rational_string(value),
                    decimal_string=fraction_to_decimal_string_for_report(value, digits),
                )
            )
        return tuple(rows)

    def as_dict(self, digits: int = DEFAULT_GOLD_DECIMAL_DIGITS) -> dict[str, object]:
        return {
            "m": self.m,
            "reference_id": self.reference_id,
            "root_strings": list(self.root_strings),
            "root_rationals": [fraction_to_rational_string(value) for value in self.root_values],
            "coefficients": [row.as_dict() for row in self.coefficient_records(digits)],
        }


@dataclass(frozen=True)
class GoldComparisonRecord:
    """Post-construction comparison between one BTNS coefficient and gold."""

    coefficient_index: int
    coefficient_trace_id: str
    coefficient_wfc_trace_id: str
    coefficient_wfc_status: str
    gold_numerator: int
    gold_denominator: int
    btns_center_numerator: int
    btns_center_denominator: int
    error_numerator: int
    error_denominator: int
    abs_error_numerator: int
    abs_error_denominator: int
    error_sign_token: str
    gold_decimal: str
    btns_center_decimal: str
    error_decimal: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "coefficient_trace_id": self.coefficient_trace_id,
            "coefficient_wfc_trace_id": self.coefficient_wfc_trace_id,
            "coefficient_wfc_status": self.coefficient_wfc_status,
            "gold_numerator": self.gold_numerator,
            "gold_denominator": self.gold_denominator,
            "btns_center_numerator": self.btns_center_numerator,
            "btns_center_denominator": self.btns_center_denominator,
            "error_numerator": self.error_numerator,
            "error_denominator": self.error_denominator,
            "abs_error_numerator": self.abs_error_numerator,
            "abs_error_denominator": self.abs_error_denominator,
            "error_sign_token": self.error_sign_token,
            "gold_decimal": self.gold_decimal,
            "btns_center_decimal": self.btns_center_decimal,
            "error_decimal": self.error_decimal,
        }


@dataclass(frozen=True)
class GoldSummary:
    coefficient_count: int
    max_abs_error_numerator: int
    max_abs_error_denominator: int
    mean_abs_error_numerator: int
    mean_abs_error_denominator: int
    zero_error_count: int

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_count": self.coefficient_count,
            "max_abs_error_numerator": self.max_abs_error_numerator,
            "max_abs_error_denominator": self.max_abs_error_denominator,
            "mean_abs_error_numerator": self.mean_abs_error_numerator,
            "mean_abs_error_denominator": self.mean_abs_error_denominator,
            "zero_error_count": self.zero_error_count,
        }


@dataclass(frozen=True)
class Power3ScaledValue:
    """Diagnostic scaled value: scaled_integer / 3**den_power3."""

    scaled_integer: int
    den_power3: int
    exact: bool
    rounding_policy: str

    def as_dict(self) -> dict[str, object]:
        return {
            "scaled_integer": self.scaled_integer,
            "den_power3": self.den_power3,
            "exact": self.exact,
            "rounding_policy": self.rounding_policy,
        }


@dataclass(frozen=True)
class Power3Bracket:
    """Exact bracketing of a rational by power-of-3 scaled integers."""

    lower_scaled_integer: int
    upper_scaled_integer: int
    den_power3: int

    def as_dict(self) -> dict[str, int]:
        return {
            "lower_scaled_integer": self.lower_scaled_integer,
            "upper_scaled_integer": self.upper_scaled_integer,
            "den_power3": self.den_power3,
        }


def _stable_id(parts: Iterable[object], length: int = 32) -> str:
    return sha256("|".join(str(part) for part in parts).encode("utf-8")).hexdigest()[:length]


def _pow3(exp: int) -> int:
    if not isinstance(exp, int):
        raise TypeError("exp must be int")
    if exp < 0:
        raise ValueError("power exponent must be non-negative")
    return RADIX ** exp


def _floor_fraction(value: Fraction) -> int:
    return value.numerator // value.denominator


def _ceil_fraction(value: Fraction) -> int:
    return -((-value.numerator) // value.denominator)


def parse_root_decimal_string_to_fraction(root_string: str) -> Fraction:
    """Parse a finite decimal/scientific-notation string exactly.

    This is external-gold parsing, not ingress projection. It must never feed
    candidate selection or coefficient construction.
    """

    if not isinstance(root_string, str):
        raise TypeError("root_string must be str")
    text = root_string.strip()
    if not text:
        raise ValueError("root_string must not be empty")
    lowered = text.lower()
    if any(token in lowered for token in ("nan", "inf")):
        raise ValueError("NaN and Infinity are forbidden gold inputs")
    try:
        return Fraction(text)
    except Exception as exc:  # pragma: no cover - preserves precise exception chain
        raise ValueError(f"invalid finite decimal root string: {root_string!r}") from exc


def fraction_to_rational_string(value: Fraction) -> str:
    if not isinstance(value, Fraction):
        raise TypeError("value must be Fraction")
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


def _require_decimal_digits(digits: int) -> int:
    if not isinstance(digits, int):
        raise TypeError("digits must be int")
    if digits < 0:
        raise ValueError("digits must be non-negative")
    return digits


def fraction_to_decimal_string_for_report(value: Fraction, digits: int = DEFAULT_GOLD_DECIMAL_DIGITS) -> str:
    """Deterministic truncated decimal string for external reports."""

    if not isinstance(value, Fraction):
        raise TypeError("value must be Fraction")
    places = _require_decimal_digits(digits)
    sign = "-" if value < 0 else ""
    num = abs(value.numerator)
    den = value.denominator
    integer_part, remainder = divmod(num, den)
    if places == 0:
        return f"{sign}{integer_part}"
    out = []
    for _ in range(places):
        remainder *= 10
        digit, remainder = divmod(remainder, den)
        out.append(str(digit))
    return f"{sign}{integer_part}." + "".join(out)


def build_gold_polynomial_coefficients(root_values: Sequence[Fraction]) -> Tuple[Fraction, ...]:
    """Return exact coefficients of prod_i (x-r_i), leading to constant."""

    if not root_values:
        raise ValueError("at least one root is required")
    coefficients: Tuple[Fraction, ...] = (Fraction(1),)
    for root in root_values:
        if not isinstance(root, Fraction):
            raise TypeError("root_values must contain Fraction objects")
        old = coefficients
        new = [Fraction(0) for _ in range(len(old) + 1)]
        new[0] = old[0]
        for idx in range(1, len(old)):
            new[idx] = old[idx] - root * old[idx - 1]
        new[-1] = -root * old[-1]
        coefficients = tuple(new)
    return coefficients


def build_gold_polynomial_from_root_strings(root_strings: Sequence[str], m: Optional[int] = None) -> GoldPolynomialReference:
    """Build an exact external gold reference from decimal root strings."""

    if not root_strings:
        raise ValueError("root_strings must not be empty")
    selected_strings = tuple(str(item).strip() for item in root_strings)
    if m is not None:
        if not isinstance(m, int) or m <= 0:
            raise ValueError("m must be a positive integer or None")
        if len(selected_strings) < m:
            raise ValueError("not enough root strings for requested m")
        selected_strings = selected_strings[:m]
    root_values = tuple(parse_root_decimal_string_to_fraction(item) for item in selected_strings)
    coefficients = build_gold_polynomial_coefficients(root_values)
    ref_id = "GOLD_REF_" + _stable_id((selected_strings, tuple(fraction_to_rational_string(v) for v in root_values), coefficients), 24)
    return GoldPolynomialReference(
        m=len(root_values),
        root_strings=selected_strings,
        root_values=root_values,
        coefficients=coefficients,
        reference_id=ref_id,
    )


def build_gold_quadratic_from_root_strings(r1: str, r2: str) -> GoldPolynomialReference:
    """Convenience wrapper for m=2: x^2 -(r1+r2)x + r1*r2."""

    return build_gold_polynomial_from_root_strings((r1, r2), m=2)


def btns_finite_center_fraction(x: BTNSNumber) -> Fraction:
    """Return finite BTNS digit-center value as an exact Fraction."""

    if not isinstance(x, BTNSNumber) or not validate_digits(x):
        raise ValueError("btns_finite_center_fraction requires a legal BTNSNumber")
    total = Fraction(0)
    for exponent, digit in x.digits.items():
        if exponent >= 0:
            total += Fraction(int(digit) * _pow3(exponent), 1)
        else:
            total += Fraction(int(digit), _pow3(-exponent))
    return total


def tail_abs_fraction(tail: Optional[TailBound]) -> Fraction:
    if tail is None or tail.abs_bound_num == 0:
        return Fraction(0)
    return Fraction(tail.abs_bound_num, _pow3(tail.abs_bound_den_power3))


def btns_interval_fraction(x: BTNSNumber) -> Tuple[Fraction, Fraction, Fraction]:
    """Return lower, center, upper using finite center and TailBound."""

    center = btns_finite_center_fraction(x)
    tail = tail_abs_fraction(x.tail_bound)
    return center - tail, center, center + tail


def compare_btns_coefficient_to_gold(
    coefficient: BTNSNumber,
    gold_value: Fraction,
    coefficient_index: int,
    *,
    digits: int = DEFAULT_GOLD_DECIMAL_DIGITS,
) -> GoldComparisonRecord:
    """Compare one constructed BTNS coefficient to one external gold value."""

    if not isinstance(gold_value, Fraction):
        raise TypeError("gold_value must be Fraction")
    if not isinstance(coefficient_index, int):
        raise TypeError("coefficient_index must be int")
    center = btns_finite_center_fraction(coefficient)
    error = center - gold_value
    abs_error = abs(error)
    if error == 0:
        sign = ERROR_ZERO
    elif error > 0:
        sign = ERROR_POSITIVE
    else:
        sign = ERROR_NEGATIVE
    return GoldComparisonRecord(
        coefficient_index=coefficient_index,
        coefficient_trace_id=coefficient.trace_id or "NO_TRACE",
        coefficient_wfc_trace_id=coefficient.wfc_trace_id or "",
        coefficient_wfc_status=coefficient.wfc_status or "",
        gold_numerator=gold_value.numerator,
        gold_denominator=gold_value.denominator,
        btns_center_numerator=center.numerator,
        btns_center_denominator=center.denominator,
        error_numerator=error.numerator,
        error_denominator=error.denominator,
        abs_error_numerator=abs_error.numerator,
        abs_error_denominator=abs_error.denominator,
        error_sign_token=sign,
        gold_decimal=fraction_to_decimal_string_for_report(gold_value, digits),
        btns_center_decimal=fraction_to_decimal_string_for_report(center, digits),
        error_decimal=fraction_to_decimal_string_for_report(error, digits),
    )


def compare_coefficients_to_gold(
    coefficients: Sequence[BTNSNumber],
    gold_coefficients: Sequence[Fraction],
    *,
    digits: int = DEFAULT_GOLD_DECIMAL_DIGITS,
) -> Tuple[GoldComparisonRecord, ...]:
    if len(coefficients) != len(gold_coefficients):
        raise ValueError("coefficient and gold coefficient counts differ")
    return tuple(
        compare_btns_coefficient_to_gold(coefficient, gold_value, idx, digits=digits)
        for idx, (coefficient, gold_value) in enumerate(zip(coefficients, gold_coefficients))
    )


def summarize_gold_comparisons(records: Sequence[GoldComparisonRecord]) -> GoldSummary:
    if not records:
        return GoldSummary(0, 0, 1, 0, 1, 0)
    errors = [Fraction(row.abs_error_numerator, row.abs_error_denominator) for row in records]
    max_error = max(errors)
    mean_error = sum(errors, Fraction(0)) / len(errors)
    zero_count = sum(1 for error in errors if error == 0)
    return GoldSummary(
        coefficient_count=len(records),
        max_abs_error_numerator=max_error.numerator,
        max_abs_error_denominator=max_error.denominator,
        mean_abs_error_numerator=mean_error.numerator,
        mean_abs_error_denominator=mean_error.denominator,
        zero_error_count=zero_count,
    )


def _round_fraction_to_int(value: Fraction, rounding_policy: str) -> int:
    if rounding_policy not in ALLOWED_POWER3_ROUNDING_POLICIES:
        raise ValueError(f"unregistered rounding policy: {rounding_policy}")
    if rounding_policy == ROUND_FLOOR_BALANCED:
        return _floor_fraction(value)
    if rounding_policy == ROUND_TRUNCATE_TOWARD_ZERO:
        if value >= 0:
            return _floor_fraction(value)
        return -_floor_fraction(-value)
    floor_value = _floor_fraction(value)
    remainder = value - floor_value
    twice = remainder * 2
    if twice < 1:
        return floor_value
    if twice > 1:
        return floor_value + 1
    lower = floor_value
    upper = floor_value + 1
    if rounding_policy == ROUND_NEAREST_TIES_TO_ZERO:
        return lower if abs(lower) <= abs(upper) else upper
    if rounding_policy == ROUND_NEAREST_TIES_TO_EVEN:
        return lower if lower % 2 == 0 else upper
    raise ValueError(f"unhandled rounding policy: {rounding_policy}")


def fraction_to_exact_power3_scaled(value: Fraction) -> Power3ScaledValue:
    """Return exact numerator / 3**p representation when possible.

    Raises ValueError if the rational denominator contains primes other than 3.
    """

    if not isinstance(value, Fraction):
        raise TypeError("value must be Fraction")
    denominator = value.denominator
    power = 0
    while denominator % RADIX == 0 and denominator > 1:
        denominator //= RADIX
        power += 1
    if denominator != 1:
        raise ValueError("value is not exactly representable over a power-of-3 denominator")
    return Power3ScaledValue(
        scaled_integer=value.numerator,
        den_power3=power,
        exact=True,
        rounding_policy="EXACT_POWER3",
    )


def fraction_to_power3_scaled(
    value: Fraction,
    den_power3: int,
    rounding_policy: str = ROUND_NEAREST_TIES_TO_ZERO,
) -> Power3ScaledValue:
    """Return rounded diagnostic scaled_integer / 3**den_power3."""

    if not isinstance(value, Fraction):
        raise TypeError("value must be Fraction")
    if not isinstance(den_power3, int) or den_power3 < 0:
        raise ValueError("den_power3 must be a non-negative int")
    scaled = value * _pow3(den_power3)
    scaled_integer = _round_fraction_to_int(scaled, rounding_policy)
    exact = Fraction(scaled_integer, _pow3(den_power3)) == value
    return Power3ScaledValue(
        scaled_integer=scaled_integer,
        den_power3=den_power3,
        exact=exact,
        rounding_policy=rounding_policy,
    )


def fraction_to_power3_bracket(value: Fraction, den_power3: int) -> Power3Bracket:
    """Return exact lower/upper integer bracket at denominator 3**den_power3."""

    if not isinstance(value, Fraction):
        raise TypeError("value must be Fraction")
    if not isinstance(den_power3, int) or den_power3 < 0:
        raise ValueError("den_power3 must be a non-negative int")
    scaled = value * _pow3(den_power3)
    return Power3Bracket(
        lower_scaled_integer=_floor_fraction(scaled),
        upper_scaled_integer=_ceil_fraction(scaled),
        den_power3=den_power3,
    )


__all__ = [
    "RADIX",
    "DEFAULT_GOLD_DECIMAL_DIGITS",
    "TRUE",
    "TUBE",
    "FALSE",
    "ERROR_ZERO",
    "ERROR_POSITIVE",
    "ERROR_NEGATIVE",
    "ROUND_TRUNCATE_TOWARD_ZERO",
    "ROUND_NEAREST_TIES_TO_ZERO",
    "ROUND_NEAREST_TIES_TO_EVEN",
    "ROUND_FLOOR_BALANCED",
    "ALLOWED_POWER3_ROUNDING_POLICIES",
    "GoldCoefficientRecord",
    "GoldPolynomialReference",
    "GoldComparisonRecord",
    "GoldSummary",
    "Power3ScaledValue",
    "Power3Bracket",
    "parse_root_decimal_string_to_fraction",
    "fraction_to_rational_string",
    "fraction_to_decimal_string_for_report",
    "build_gold_polynomial_coefficients",
    "build_gold_polynomial_from_root_strings",
    "build_gold_quadratic_from_root_strings",
    "btns_finite_center_fraction",
    "tail_abs_fraction",
    "btns_interval_fraction",
    "compare_btns_coefficient_to_gold",
    "compare_coefficients_to_gold",
    "summarize_gold_comparisons",
    "fraction_to_exact_power3_scaled",
    "fraction_to_power3_scaled",
    "fraction_to_power3_bracket",
]


if __name__ == "__main__":
    from btns_core import make_btns_number_from_digits

    ref = build_gold_quadratic_from_root_strings("1", "2")
    assert [fraction_to_rational_string(v) for v in ref.coefficients] == ["1", "-3", "2"]

    c0 = make_btns_number_from_digits({0: 1}, 0, 0, trace_id="gold_c0")
    c1 = make_btns_number_from_digits({1: -1}, 0, 1, trace_id="gold_c1")
    c2 = make_btns_number_from_digits({0: -1, 1: 1}, 0, 1, trace_id="gold_c2")
    comparisons = compare_coefficients_to_gold((c0, c1, c2), ref.coefficients)
    assert summarize_gold_comparisons(comparisons).zero_error_count == 3
    assert fraction_to_power3_scaled(Fraction(1, 2), 1).scaled_integer == 1
    print("gold_reference.py self-check PASS")
