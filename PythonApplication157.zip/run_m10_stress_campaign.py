"""
run_m10_stress_campaign.py

Stress evidence runner for PythonApplication157 under Script Contract v28.

This runner is intentionally a stress/evidence harness, not a replacement for
run_m10_campaign.py.  It exercises two academic stress themes that the clean
m=10 campaign does not strongly expose by itself:

1. Adaptive Certified governance stress:
   - CERT_REFINE / CERT_REFINE_REQUEST via formal refinement requests;
   - CERT_REBUILD via actual re-projection and reconstruction at a deeper k_min;
   - CERT_TUBE_HOLD via a strict-empty WFC diagnostic case.

2. WFC sensitivity stress:
   - RN_ZERO versus RN_EVEN selection differences;
   - smaller-window versus larger-window selection differences.

The runner writes machine-readable CSV/JSON stress sidecars.  Decimal strings
are used only at ingress/gold boundaries.  Coefficient construction is still
delegated to btns_poly.py.  WFC execution is delegated to btns_wfc.py.

Consolidation note: in this cleaned package, this file is the single diagnostic
stress runner for the current degree stage. Earlier stress runners were removed
from the distributable package; the m=10 stress cases are the canonical superset
stress harness for this stage.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping, Optional, Sequence
import argparse
import csv
import json
import sys

from btns_core import (
    BTNSNumber,
    SOURCE_TEST,
    make_btns_number_from_digits,
    validate_digits,
)
from btns_poly import (
    CampaignConfig,
    CERT_ACCEPT,
    CERT_REFINE,
    CERT_REFINE_REQUEST,
    CERT_REBUILD,
    CERT_TUBE_HOLD,
    build_polynomial_coeffs_certified_independent,
    build_polynomial_coeffs_noncertified,
    build_polynomial_coeffs_noncertified_matched_depth,
)
from btns_wfc import (
    WFCConfig,
    RN_ZERO,
    RN_EVEN,
    LOWER_BOUNDARY_COMPENSATED,
    WFC_UNDEFINED_STRICT_EMPTY,
    strict_wfc,
    validate_wfc_trace,
)
import btns_certified as certified
import gold_reference as gold
import ingress
import audit

CONTRACT_VERSION = "v28"
PACKAGE_NAME = "PythonApplication157"
BASE_PACKAGE = "PythonApplication156"
REFERENCE_LABEL = "PythonApplication_BTNS_Native_v28_FULL_STRICT_WFC_MATCHED_DEPTH"
RUNNER_NAME = "run_m10_stress_campaign.py"
M = 10

STRESS_VALID_RUN = "STRESS_VALID_RUN"
STRESS_INVALID_RUN = "STRESS_INVALID_RUN"


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _write_json(path: str | Path, payload: Any) -> None:
    Path(path).write_text(json.dumps(_json_safe(payload), indent=2, sort_keys=True), encoding="utf-8")


def _write_csv(path: str | Path, rows: Sequence[Mapping[str, Any]], *, fieldnames: Optional[Sequence[str]] = None) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    columns: list[str] = list(fieldnames or [])
    for row in rows:
        for key in row.keys():
            text = str(key)
            if text not in columns:
                columns.append(text)
    with path.open("w", encoding="utf-8", newline="") as handle:
        if not columns:
            handle.write("")
            return
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _json_safe(row.get(key, "")) for key in columns})


def _fraction_abs_sum(comparisons: Sequence[gold.GoldComparisonRecord]) -> Fraction:
    total = Fraction(0, 1)
    for row in comparisons:
        total += Fraction(row.abs_error_numerator, row.abs_error_denominator)
    return total


def _fraction_to_decimal(value: Fraction, digits: int = 30) -> str:
    return gold.fraction_to_decimal_string_for_report(value, digits)


def _ingress_roots(root_strings: Sequence[str], *, k_min: int, k_max: Optional[int], prefix: str) -> tuple[BTNSNumber, ...]:
    roots = []
    for idx, text in enumerate(root_strings, start=1):
        result = ingress.parse_decimal_string_to_btns_with_trace(
            text,
            k_min=k_min,
            k_max=k_max,
            rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
            trace_id=f"{prefix}:R{idx}:k{k_min}",
            group_id=prefix,
            root_index=idx,
        )
        roots.append(result.number)
    return tuple(roots)


def _run_coefficients(root_strings: Sequence[str], *, k_min: int, k_max: Optional[int], trace_prefix: str, window_width: int) -> tuple[Any, Any, Any, Any, Fraction]:
    roots = _ingress_roots(root_strings, k_min=k_min, k_max=k_max, prefix=trace_prefix)
    cfg = CampaignConfig(
        k_min=k_min,
        k_max=k_max,
        trace_prefix=f"{trace_prefix}:CONSTRUCT:k{k_min}",
        wfc_window_width=min(window_width, -k_min if k_min < 0 else 0),
        wfc_policy=RN_ZERO,
        canonize_each_stage=False,
    )
    noncert = build_polynomial_coeffs_noncertified(roots, cfg)
    cert = build_polynomial_coeffs_certified_independent(roots, cfg)
    matched = build_polynomial_coeffs_noncertified_matched_depth(roots, cfg.k_min, cfg, cert)
    gold_ref = gold.build_gold_polynomial_from_root_strings(root_strings, m=M)
    comparisons = gold.compare_coefficients_to_gold(cert.coefficients, gold_ref.coefficients, digits=30)
    total_error = _fraction_abs_sum(comparisons)
    return noncert, cert, matched, gold_ref, total_error


def _operation_counts(noncert: Any, cert: Any, matched: Any) -> dict[str, int]:
    results = (noncert, cert, matched)
    traces = [trace for result in results for trace in getattr(result, "traces", tuple())]
    wfc_results = [wfc for result in results for wfc in getattr(result, "wfc_results", tuple())]
    return {
        "trace_count": len(traces),
        "btns_addition_like_count": sum(1 for t in traces if "ADD" in t.operation_type or "SUB" in t.operation_type),
        "btns_multiplication_like_count": sum(1 for t in traces if "MUL" in t.operation_type),
        "btns_negation_like_count": sum(1 for t in traces if "NEG" in t.operation_type),
        "wfc_operation_count": len(wfc_results),
        "wfc_candidate_count": sum(item.trace.candidate_count for item in wfc_results),
        "wfc_strict_candidate_count": sum(item.trace.strict_candidate_count for item in wfc_results),
        "certified_decision_count": len(getattr(cert, "certified_decision_chain", tuple())),
        "certified_certificate_count": len(getattr(cert, "operation_certificates", tuple())),
        "matched_depth_record_count": len(getattr(matched, "matched_depth_records", tuple())),
    }


def adaptive_rebuild_stress_rows() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    cost_rows: list[dict[str, Any]] = []

    # Case A: formal refinement request.
    refine_request = certified.request_certified_refinement(
        root_records=(
            "0.333333333333333333333333333333",
            "-0.333333333333333333333333333333",
            "1.000000000000000001",
            "-0.250000000000000000000000000001",
            "0.125000000000000000000000000003",
            "-0.062500000000000000000000000005",
            "0.031250000000000000000000000007",
            "-0.015625000000000000000000000009",
            "0.007812500000000000000000000011",
            "-0.003906250000000000000000000013",
        ),
        current_k_min=-6,
        target_k_min=-20,
        rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
        config={"stress_case": "ADAPT_REFINE_REQUEST"},
    )
    rows.append({
        "stress_case_id": "ADAPT_REFINE_REQUEST",
        "stress_family": "ADAPTIVE_REBUILD",
        "expected_token": CERT_REFINE,
        "governance_token": CERT_REFINE_REQUEST,
        "refinement_status": refine_request.status,
        "current_k_min": refine_request.current_k_min,
        "target_k_min": refine_request.target_k_min,
        "message": refine_request.message,
        "evidence_type": "FORMAL_REFINEMENT_REQUEST_INTERFACE",
    })

    # Case B: actual rebuild by re-projecting roots at a deeper k_min and re-running construction.
    root_strings = ("0.123456789", "-0.987654321", "2.345678901", "-1.111111111", "0.777777777", "-0.333333333", "0.222222222", "-0.111111111", "0.055555555", "-0.027777777")
    started = perf_counter()
    nc_initial, cert_initial, matched_initial, _, err_initial = _run_coefficients(
        root_strings,
        k_min=-6,
        k_max=1,
        trace_prefix="ADAPT_REBUILD_INITIAL",
        window_width=0,
    )
    nc_rebuild, cert_rebuild, matched_rebuild, _, err_rebuild = _run_coefficients(
        root_strings,
        k_min=-24,
        k_max=1,
        trace_prefix="ADAPT_REBUILD_DEEP",
        window_width=0,
    )
    runtime = perf_counter() - started
    rows.append({
        "stress_case_id": "ADAPT_REBUILD_AFTER_REFINE",
        "stress_family": "ADAPTIVE_REBUILD",
        "expected_token": CERT_REBUILD,
        "governance_token": CERT_REBUILD,
        "initial_k_min": -6,
        "rebuild_k_min": -24,
        "initial_total_abs_error": _fraction_to_decimal(err_initial, 30),
        "rebuild_total_abs_error": _fraction_to_decimal(err_rebuild, 30),
        "error_reduction_detected": bool(err_rebuild <= err_initial),
        "matched_depth_records_initial": len(matched_initial.matched_depth_records),
        "matched_depth_records_rebuild": len(matched_rebuild.matched_depth_records),
        "runtime_seconds": f"{runtime:.9f}",
        "message": "same root strings re-projected and reconstructed at deeper k_min",
        "evidence_type": "ACTUAL_REPROJECT_AND_REBUILD",
    })
    initial_counts = _operation_counts(nc_initial, cert_initial, matched_initial)
    initial_counts.update({"stress_case_id": "ADAPT_REBUILD_INITIAL", "k_min": -6, "runtime_seconds": f"{runtime:.9f}"})
    rebuild_counts = _operation_counts(nc_rebuild, cert_rebuild, matched_rebuild)
    rebuild_counts.update({"stress_case_id": "ADAPT_REBUILD_DEEP", "k_min": -24, "runtime_seconds": f"{runtime:.9f}"})
    cost_rows.extend([initial_counts, rebuild_counts])

    # Case C: strict-empty WFC diagnostic mapped to CERT_TUBE_HOLD.
    tube_x = make_btns_number_from_digits({0: 1}, k_min=0, k_max=0, source_tag=SOURCE_TEST, trace_id="ADAPT_TUBE_X")
    tube_cfg = WFCConfig(window_width=1, policy=RN_ZERO, boundary_mode=LOWER_BOUNDARY_COMPENSATED)
    tube_result = strict_wfc(tube_x, tube_cfg, {"operation_id": "ADAPT_TUBE_WFC_STRICT_EMPTY", "wfc_applicable": True})
    tube_cert = certified.certify_wfc_selection(tube_result)
    rows.append({
        "stress_case_id": "ADAPT_TUBE_HOLD_STRICT_EMPTY_WFC",
        "stress_family": "ADAPTIVE_REBUILD",
        "expected_token": CERT_TUBE_HOLD,
        "governance_token": certified.classify_wfc_status(tube_result.trace.wfc_status),
        "wfc_status": tube_result.trace.wfc_status,
        "selection_certificate_token": tube_cert.decision_token,
        "candidate_count": tube_result.trace.candidate_count,
        "strict_candidate_count": tube_result.trace.strict_candidate_count,
        "valid_trace": validate_wfc_trace(tube_result.trace, tube_result.candidates),
        "message": tube_cert.message,
        "evidence_type": "STRICT_EMPTY_WFC_DIAGNOSTIC",
    })
    cost_rows.append({
        "stress_case_id": "ADAPT_TUBE_HOLD_STRICT_EMPTY_WFC",
        "k_min": 0,
        "wfc_operation_count": 1,
        "wfc_candidate_count": tube_result.trace.candidate_count,
        "wfc_strict_candidate_count": tube_result.trace.strict_candidate_count,
        "certified_decision_count": 1,
        "certified_certificate_count": 1,
        "matched_depth_record_count": 0,
        "runtime_seconds": "0.000000000",
    })
    return rows, cost_rows


def _wfc_compare_case(case_id: str, x: BTNSNumber, cfg_a: WFCConfig, cfg_b: WFCConfig, label_a: str, label_b: str, sensitivity_family: str) -> dict[str, Any]:
    result_a = strict_wfc(x, cfg_a, {"operation_id": f"{case_id}:{label_a}", "wfc_applicable": True})
    result_b = strict_wfc(x, cfg_b, {"operation_id": f"{case_id}:{label_b}", "wfc_applicable": True})
    digits_a = getattr(result_a.canonical_object, "digits", None) if result_a.canonical_object is not None else None
    digits_b = getattr(result_b.canonical_object, "digits", None) if result_b.canonical_object is not None else None
    return {
        "stress_case_id": case_id,
        "stress_family": sensitivity_family,
        "label_a": label_a,
        "label_b": label_b,
        "policy_a": cfg_a.policy,
        "policy_b": cfg_b.policy,
        "window_a": cfg_a.window_width,
        "window_b": cfg_b.window_width,
        "status_a": result_a.trace.wfc_status,
        "status_b": result_b.trace.wfc_status,
        "selected_c_in_a": result_a.trace.selected_c_in,
        "selected_c_in_b": result_b.trace.selected_c_in,
        "selected_candidate_id_a": result_a.trace.selected_candidate_id,
        "selected_candidate_id_b": result_b.trace.selected_candidate_id,
        "digits_after_a": dict(sorted(digits_a.items())) if isinstance(digits_a, dict) else str(digits_a),
        "digits_after_b": dict(sorted(digits_b.items())) if isinstance(digits_b, dict) else str(digits_b),
        "candidate_count_a": result_a.trace.candidate_count,
        "candidate_count_b": result_b.trace.candidate_count,
        "strict_candidate_count_a": result_a.trace.strict_candidate_count,
        "strict_candidate_count_b": result_b.trace.strict_candidate_count,
        "sensitivity_detected": (digits_a != digits_b) or (result_a.trace.selected_candidate_id != result_b.trace.selected_candidate_id),
        "valid_trace_a": validate_wfc_trace(result_a.trace, result_a.candidates),
        "valid_trace_b": validate_wfc_trace(result_b.trace, result_b.candidates),
    }


def wfc_sensitivity_stress_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    # Policy sensitivity: x = -1 at the boundary; RN_ZERO keeps z0=-1,
    # RN_EVEN selects compensated z0=0.
    policy_x = make_btns_number_from_digits({0: -1}, k_min=0, k_max=0, source_tag=SOURCE_TEST, trace_id="WFC_POLICY_X")
    rows.append(
        _wfc_compare_case(
            "WFC_POLICY_RN_ZERO_VS_RN_EVEN",
            policy_x,
            WFCConfig(window_width=0, policy=RN_ZERO),
            WFCConfig(window_width=0, policy=RN_EVEN),
            "RN_ZERO_MAIN",
            "RN_EVEN_MAIN",
            "WFC_POLICY_SENSITIVITY",
        )
    )

    # Window sensitivity: with RN_EVEN, the same local boundary neighborhood can
    # select different c_in / digits when the window is widened from w=0 to w=1.
    window_x = make_btns_number_from_digits({-1: -1, 0: -1}, k_min=-1, k_max=0, source_tag=SOURCE_TEST, trace_id="WFC_WINDOW_X")
    rows.append(
        _wfc_compare_case(
            "WFC_WINDOW_SMALL_VS_LARGE",
            window_x,
            WFCConfig(window_width=0, policy=RN_EVEN),
            WFCConfig(window_width=1, policy=RN_EVEN),
            "WINDOW_0",
            "WINDOW_1",
            "WFC_WINDOW_SENSITIVITY",
        )
    )
    return rows


def _summary_rows(adaptive_rows: Sequence[Mapping[str, Any]], wfc_rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    adaptive_tokens = [str(row.get("governance_token", row.get("expected_token", ""))) for row in adaptive_rows]
    return {
        "contract_version": CONTRACT_VERSION,
        "package_name": PACKAGE_NAME,
        "source_base_package": BASE_PACKAGE,
        "runner": RUNNER_NAME,
        "m": M,
        "stress_status": STRESS_VALID_RUN,
        "adaptive_case_count": len(adaptive_rows),
        "wfc_sensitivity_case_count": len(wfc_rows),
        "cert_refine_observed": CERT_REFINE in [str(row.get("expected_token", "")) for row in adaptive_rows],
        "cert_rebuild_observed": CERT_REBUILD in adaptive_tokens or CERT_REBUILD in [str(row.get("expected_token", "")) for row in adaptive_rows],
        "cert_tube_hold_observed": CERT_TUBE_HOLD in adaptive_tokens,
        "wfc_policy_sensitivity_detected": any(row.get("stress_family") == "WFC_POLICY_SENSITIVITY" and bool(row.get("sensitivity_detected")) for row in wfc_rows),
        "wfc_window_sensitivity_detected": any(row.get("stress_family") == "WFC_WINDOW_SENSITIVITY" and bool(row.get("sensitivity_detected")) for row in wfc_rows),
        "scope_note": "Stress harness: diagnostic evidence complementary to the clean m=10 campaign; not a replacement for production construction gates.",
    }


def run_stress_campaign(output_dir: str | Path) -> dict[str, Any]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    adaptive_rows, cost_rows = adaptive_rebuild_stress_rows()
    wfc_rows = wfc_sensitivity_stress_rows()
    summary = _summary_rows(adaptive_rows, wfc_rows)
    audit_report = audit.audit_project(Path(__file__).resolve().parent, stage=audit.STAGE_FINAL_PACKAGE)
    summary["audit_status"] = audit_report.status
    summary["audit_fail_count"] = sum(1 for item in audit_report.violations if item.severity == audit.STATUS_FAIL)

    _write_csv(out / "adaptive_rebuild_stress.csv", adaptive_rows)
    _write_csv(out / "wfc_sensitivity_stress.csv", wfc_rows)
    _write_csv(out / "stress_operation_cost_accounting.csv", cost_rows)
    _write_csv(out / "stress_audit_summary.csv", [
        {"module": row.module, "status": row.status, "violation_count": len(row.violations)}
        for row in audit_report.module_results
    ])
    _write_json(out / "stress_run_summary.json", summary)
    return summary


def self_check() -> None:
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        summary = run_stress_campaign(tmp)
        assert summary["stress_status"] == STRESS_VALID_RUN, summary
        assert summary["cert_refine_observed"] is True, summary
        assert summary["cert_rebuild_observed"] is True, summary
        assert summary["cert_tube_hold_observed"] is True, summary
        assert summary["wfc_policy_sensitivity_detected"] is True, summary
        assert summary["wfc_window_sensitivity_detected"] is True, summary
        assert (Path(tmp) / "adaptive_rebuild_stress.csv").exists()
        assert (Path(tmp) / "wfc_sensitivity_stress.csv").exists()
    print("run_m10_stress_campaign.py self-check PASS")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Run m=10 adaptive-rebuild and WFC-sensitivity stress evidence campaign.")
    parser.add_argument("--output", "--output_dir", dest="output", default="btns_m10_stress_output_157")
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args(argv)
    if args.self_check:
        self_check()
        return 0
    summary = run_stress_campaign(args.output)
    print(json.dumps(_json_safe(summary), indent=2, sort_keys=True))
    return 0 if summary.get("stress_status") == STRESS_VALID_RUN else 1


if __name__ == "__main__":
    raise SystemExit(main())
