"""
ingress.py

Ingress boundary module for PythonApplication157 under Script Contract v28.

This module is allowed to parse external decimal root strings because root
input is an explicit ingress boundary. It converts CSV/string inputs into finite
BTNSNumber objects. After this boundary, coefficient construction must use only
BTNSNumber objects and BTNS primitives.

Allowed here by contract:
    - exact Fraction-based parsing of finite decimal/scientific-notation strings
    - controlled projection into BTNS digits at the campaign k_min
    - CSV root-input loading
    - formal refinement support by re-projecting the same root strings deeper

Forbidden here by design:
    - no Excel workbook reading
    - no coefficient construction
    - no polynomial expansion
    - no external-gold coefficient computation
    - no egress/reporting conversion
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import csv
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from btns_core import (
    CANONICAL_LEGAL,
    SOURCE_INGRESS,
    TAIL_INGRESS_ROUNDING,
    DIGIT_SET,
    RADIX,
    BTNSNumber,
    TailBound,
    validate_digits,
)


ROUND_TRUNCATE_TOWARD_ZERO = "ROUND_TRUNCATE_TOWARD_ZERO"
ROUND_NEAREST_TIES_TO_ZERO = "ROUND_NEAREST_TIES_TO_ZERO"
ROUND_NEAREST_TIES_TO_EVEN = "ROUND_NEAREST_TIES_TO_EVEN"
ROUND_FLOOR_BALANCED = "ROUND_FLOOR_BALANCED"

DEFAULT_ROUNDING_POLICY = ROUND_NEAREST_TIES_TO_ZERO

ALLOWED_ROUNDING_POLICIES = {
    ROUND_TRUNCATE_TOWARD_ZERO,
    ROUND_NEAREST_TIES_TO_ZERO,
    ROUND_NEAREST_TIES_TO_EVEN,
    ROUND_FLOOR_BALANCED,
}

REQUIRED_ROOT_COLUMNS = (
    "group_id",
    "root_index",
    "root_decimal_string",
    "active_for_m",
    "notes",
)

FORBIDDEN_EXCEL_SUFFIXES = {".xlsx", ".xls", ".xlsm", ".xlsb"}


@dataclass(frozen=True)
class RootInputRow:
    """One CSV root-input row before BTNS projection."""

    group_id: str
    root_index: int
    root_decimal_string: str
    active_for_m: str
    notes: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.group_id, str) or not self.group_id.strip():
            raise ValueError("group_id must be a non-empty string")
        if not isinstance(self.root_index, int) or self.root_index <= 0:
            raise ValueError("root_index must be a positive integer")
        if not isinstance(self.root_decimal_string, str) or not self.root_decimal_string.strip():
            raise ValueError("root_decimal_string must be a non-empty string")
        if not isinstance(self.active_for_m, str):
            raise TypeError("active_for_m must be stored as string")
        if not isinstance(self.notes, str):
            raise TypeError("notes must be a string")


@dataclass(frozen=True)
class IngressTrace:
    """Trace emitted by decimal-string to BTNS ingress projection."""

    trace_id: str
    original_root_string: str
    group_id: str
    root_index: int
    k_min: int
    k_max: int
    rounding_policy: str
    scaled_integer: int
    generated_digits: Tuple[Tuple[int, int], ...]
    tail_lower_exp: int
    tail_abs_bound_num: int
    tail_abs_bound_den_power3: int
    tail_policy: str
    source: str

    def as_dict(self) -> dict[str, object]:
        return {
            "trace_id": self.trace_id,
            "original_root_string": self.original_root_string,
            "group_id": self.group_id,
            "root_index": self.root_index,
            "k_min": self.k_min,
            "k_max": self.k_max,
            "rounding_policy": self.rounding_policy,
            "scaled_integer": self.scaled_integer,
            "generated_digits": list(self.generated_digits),
            "tail_lower_exp": self.tail_lower_exp,
            "tail_abs_bound_num": self.tail_abs_bound_num,
            "tail_abs_bound_den_power3": self.tail_abs_bound_den_power3,
            "tail_policy": self.tail_policy,
            "source": self.source,
        }


@dataclass(frozen=True)
class IngressResult:
    """BTNS ingress result plus trace metadata."""

    number: BTNSNumber
    trace: IngressTrace

    def as_dict(self) -> dict[str, object]:
        return {
            "trace": self.trace.as_dict(),
            "number_trace_id": self.number.trace_id,
            "k_min": self.number.k_min,
            "k_max": self.number.k_max,
            "digits": dict(sorted(self.number.digits.items())),
            "tail_abs_bound_num": 0 if self.number.tail_bound is None else self.number.tail_bound.abs_bound_num,
            "tail_abs_bound_den_power3": 0 if self.number.tail_bound is None else self.number.tail_bound.abs_bound_den_power3,
        }


def _stable_trace_id(parts: Iterable[object]) -> str:
    text = "|".join(str(part) for part in parts)
    return sha256(text.encode("utf-8")).hexdigest()[:32]


def _pow3(exp: int) -> int:
    if exp < 0:
        raise ValueError("power exponent must be non-negative")
    return RADIX ** exp


def _require_policy(rounding_policy: str) -> str:
    if not isinstance(rounding_policy, str) or not rounding_policy:
        raise ValueError("rounding_policy must be a non-empty string")
    if rounding_policy not in ALLOWED_ROUNDING_POLICIES:
        raise ValueError(f"unregistered rounding policy: {rounding_policy}")
    return rounding_policy


def _parse_decimal_string_exact(root_string: str) -> Fraction:
    """Parse a finite decimal/scientific-notation string into exact Fraction.

    Fraction(text) does not go through binary floating point, so this stays at
    the ingress boundary and does not contaminate construction arithmetic.
    """

    if not isinstance(root_string, str):
        raise TypeError("root_string must be str")
    text = root_string.strip()
    if not text:
        raise ValueError("root_string must not be empty")
    lowered = text.lower()
    if any(token in lowered for token in ("nan", "inf")):
        raise ValueError("NaN and Infinity are forbidden root inputs")
    try:
        return Fraction(text)
    except Exception as exc:  # pragma: no cover - keeps parse exception precise
        raise ValueError(f"invalid finite decimal root string: {root_string!r}") from exc


def _floor_fraction(x: Fraction) -> int:
    return x.numerator // x.denominator


def _ceil_fraction(x: Fraction) -> int:
    return -((-x.numerator) // x.denominator)


def _round_fraction_to_int(x: Fraction, rounding_policy: str) -> int:
    """Round exact Fraction to integer using controlled v28 policies."""

    policy = _require_policy(rounding_policy)

    if policy == ROUND_FLOOR_BALANCED:
        return _floor_fraction(x)

    if policy == ROUND_TRUNCATE_TOWARD_ZERO:
        if x >= 0:
            return _floor_fraction(x)
        return -_floor_fraction(-x)

    floor_value = _floor_fraction(x)
    remainder = x - floor_value
    twice = remainder * 2

    if twice < 1:
        return floor_value
    if twice > 1:
        return floor_value + 1

    # Exact half tie.
    lower = floor_value
    upper = floor_value + 1
    if policy == ROUND_NEAREST_TIES_TO_ZERO:
        return lower if abs(lower) <= abs(upper) else upper
    if policy == ROUND_NEAREST_TIES_TO_EVEN:
        return lower if lower % 2 == 0 else upper

    raise ValueError(f"unhandled rounding policy: {policy}")


def _scale_to_k_min(value: Fraction, k_min: int) -> Fraction:
    """Return value / 3**k_min as an exact Fraction."""

    if not isinstance(k_min, int):
        raise TypeError("k_min must be int")
    if k_min >= 0:
        return value / _pow3(k_min)
    return value * _pow3(-k_min)


def _value_from_scaled_integer(scaled_integer: int, k_min: int) -> Fraction:
    """Return scaled_integer * 3**k_min as exact Fraction."""

    if k_min >= 0:
        return Fraction(scaled_integer * _pow3(k_min), 1)
    return Fraction(scaled_integer, _pow3(-k_min))


def _ceil_abs_fraction_to_power3_bound(value: Fraction, den_power3: int) -> int:
    """Return ceil(abs(value) * 3**den_power3)."""

    if den_power3 < 0:
        raise ValueError("den_power3 must be non-negative")
    magnitude = abs(value)
    if magnitude == 0:
        return 0
    return _ceil_fraction(magnitude * _pow3(den_power3))


def _balanced_integer_digits(n: int) -> Dict[int, int]:
    """Convert an integer to balanced ternary digits over exponents >= 0."""

    if not isinstance(n, int):
        raise TypeError("n must be int")
    if n == 0:
        return {0: 0}

    digits: Dict[int, int] = {}
    exponent = 0
    current = n
    while current != 0:
        current, remainder = divmod(current, RADIX)
        if remainder == 0:
            digit = 0
        elif remainder == 1:
            digit = 1
        else:
            digit = -1
            current += 1
        digits[exponent] = digit
        exponent += 1
    return digits


def _shift_digits(digits: Dict[int, int], shift: int) -> Dict[int, int]:
    return {exponent + shift: digit for exponent, digit in digits.items() if digit != 0}


def _complete_digits(digits: Dict[int, int], k_min: int, k_max: int) -> Dict[int, int]:
    complete = {exponent: 0 for exponent in range(k_min, k_max + 1)}
    for exponent, digit in digits.items():
        if digit not in DIGIT_SET:
            raise ValueError("illegal balanced ternary digit generated")
        if k_min <= exponent <= k_max:
            complete[exponent] = digit
        elif digit != 0:
            raise ValueError("nonzero digit outside completed range")
    return complete


def _digits_tuple(digits: Dict[int, int]) -> Tuple[Tuple[int, int], ...]:
    return tuple(sorted((int(k), int(v)) for k, v in digits.items()))


def infer_k_max_from_root_string(root_string: str) -> int:
    """Infer a safe nonnegative k_max from the exact root magnitude."""

    value = _parse_decimal_string_exact(root_string)
    if value == 0:
        return 0
    magnitude = abs(value)
    k = 0
    power = Fraction(1, 1)
    while power <= magnitude:
        power *= RADIX
        k += 1
    return k


def parse_decimal_string_to_btns_with_trace(
    root_string: str,
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str = DEFAULT_ROUNDING_POLICY,
    trace_id: str = "INGRESS",
    group_id: str = "UNSPECIFIED_GROUP",
    root_index: int = 0,
) -> IngressResult:
    """Project a decimal root string into a finite BTNSNumber plus trace.

    Decimal/rational parsing is intentionally confined to this ingress boundary.
    The returned BTNSNumber is the only value that should cross into construction
    modules.
    """

    if not isinstance(k_min, int):
        raise TypeError("k_min must be int")
    if k_max is not None and not isinstance(k_max, int):
        raise TypeError("k_max must be int or None")
    policy = _require_policy(rounding_policy)

    value = _parse_decimal_string_exact(root_string)
    scaled = _scale_to_k_min(value, k_min)
    scaled_integer = _round_fraction_to_int(scaled, policy)
    represented_value = _value_from_scaled_integer(scaled_integer, k_min)
    error = value - represented_value

    integer_digits = _balanced_integer_digits(scaled_integer)
    shifted = _shift_digits(integer_digits, k_min)

    inferred_max = max(shifted) if shifted else 0
    if k_max is None:
        effective_k_max = inferred_max if inferred_max >= 0 else 0
    else:
        effective_k_max = k_max if k_max >= inferred_max else inferred_max
    effective_k_min = k_min
    if effective_k_min > effective_k_max:
        effective_k_max = effective_k_min

    completed = _complete_digits(shifted, effective_k_min, effective_k_max)

    tail_den_power = -k_min if k_min < 0 else 0
    tail_num = _ceil_abs_fraction_to_power3_bound(error, tail_den_power)
    tail = TailBound(
        lower_exp=k_min,
        abs_bound_num=tail_num,
        abs_bound_den_power3=tail_den_power,
        policy=TAIL_INGRESS_ROUNDING,
        source=SOURCE_INGRESS,
    )

    generated_trace = _stable_trace_id(
        (
            trace_id,
            group_id,
            root_index,
            root_string.strip(),
            k_min,
            effective_k_max,
            policy,
            scaled_integer,
            _digits_tuple(completed),
            tail_num,
            tail_den_power,
        )
    )

    number = BTNSNumber(
        digits=completed,
        k_min=effective_k_min,
        k_max=effective_k_max,
        tail_bound=tail,
        canonicality_flag=CANONICAL_LEGAL,
        source_tag=SOURCE_INGRESS,
        precision_depth=k_min,
        trace_id=generated_trace,
    )
    if not validate_digits(number):
        raise ArithmeticError("ingress generated an illegal BTNSNumber")

    trace = IngressTrace(
        trace_id=generated_trace,
        original_root_string=root_string.strip(),
        group_id=group_id,
        root_index=root_index,
        k_min=effective_k_min,
        k_max=effective_k_max,
        rounding_policy=policy,
        scaled_integer=scaled_integer,
        generated_digits=_digits_tuple(completed),
        tail_lower_exp=tail.lower_exp,
        tail_abs_bound_num=tail.abs_bound_num,
        tail_abs_bound_den_power3=tail.abs_bound_den_power3,
        tail_policy=tail.policy,
        source=SOURCE_INGRESS,
    )
    return IngressResult(number=number, trace=trace)


def parse_decimal_string_to_btns(
    root_string: str,
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str,
    trace_id: str,
) -> BTNSNumber:
    """Mandatory v28 ingress function returning only the BTNSNumber."""

    return parse_decimal_string_to_btns_with_trace(
        root_string=root_string,
        k_min=k_min,
        k_max=k_max,
        rounding_policy=rounding_policy,
        trace_id=trace_id,
    ).number


def _parse_active_for_m(value: str, m: int) -> bool:
    text = (value or "").strip().lower()
    if text in {"true", "yes", "y", "1", "active"}:
        return True
    if text in {"false", "no", "n", "0", "inactive", ""}:
        return False
    try:
        return int(text) == m
    except ValueError:
        return False


def load_root_input_csv(csv_path: str | Path) -> Tuple[RootInputRow, ...]:
    """Load the allowed CSV root-input format.

    Excel paths are explicitly rejected. Only CSV text is accepted.
    """

    path = Path(csv_path)
    if path.suffix.lower() in FORBIDDEN_EXCEL_SUFFIXES:
        raise ValueError("FORBIDDEN_EXCEL_INPUT: root input must be CSV, not Excel")
    if path.suffix.lower() != ".csv":
        raise ValueError("root input file must have .csv extension")

    rows: List[RootInputRow] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("CSV has no header")
        missing = [name for name in REQUIRED_ROOT_COLUMNS if name not in reader.fieldnames]
        if missing:
            raise ValueError(f"CSV missing required columns: {missing}")
        for line_no, row in enumerate(reader, start=2):
            try:
                root_index = int(str(row["root_index"]).strip())
            except Exception as exc:
                raise ValueError(f"invalid root_index at CSV line {line_no}") from exc
            rows.append(
                RootInputRow(
                    group_id=str(row["group_id"]).strip(),
                    root_index=root_index,
                    root_decimal_string=str(row["root_decimal_string"]).strip(),
                    active_for_m=str(row["active_for_m"]).strip(),
                    notes=str(row.get("notes", "")).strip(),
                )
            )
    return tuple(rows)


def select_roots_for_m(rows: Sequence[RootInputRow], m: int) -> Tuple[RootInputRow, ...]:
    """Select roots for a degree campaign.

    For m=2, the default is root_index = 1 and 2 for each group unless
    active_for_m explicitly marks roots for that campaign.
    """

    if not isinstance(m, int) or m <= 0:
        raise ValueError("m must be a positive integer")

    by_group: Dict[str, List[RootInputRow]] = {}
    for row in rows:
        if not isinstance(row, RootInputRow):
            raise TypeError("rows must contain RootInputRow objects")
        by_group.setdefault(row.group_id, []).append(row)

    selected: List[RootInputRow] = []
    for group_id in sorted(by_group):
        group_rows = sorted(by_group[group_id], key=lambda item: item.root_index)
        explicit = [row for row in group_rows if _parse_active_for_m(row.active_for_m, m)]
        if explicit:
            chosen = explicit[:m]
        else:
            chosen = [row for row in group_rows if 1 <= row.root_index <= m]
        if len(chosen) < m:
            raise ValueError(f"group {group_id} does not contain {m} selectable roots")
        selected.extend(chosen[:m])
    return tuple(selected)


def ingress_roots_for_m(
    rows: Sequence[RootInputRow],
    m: int,
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str = DEFAULT_ROUNDING_POLICY,
    trace_prefix: str = "INGRESS",
) -> Tuple[IngressResult, ...]:
    """Convert selected root rows into BTNS ingress results."""

    selected = select_roots_for_m(rows, m=m)
    results: List[IngressResult] = []
    for row in selected:
        trace_id = _stable_trace_id((trace_prefix, row.group_id, row.root_index, m, k_min, k_max, rounding_policy))
        results.append(
            parse_decimal_string_to_btns_with_trace(
                root_string=row.root_decimal_string,
                k_min=k_min,
                k_max=k_max,
                rounding_policy=rounding_policy,
                trace_id=trace_id,
                group_id=row.group_id,
                root_index=row.root_index,
            )
        )
    return tuple(results)


def ingress_numbers_for_m(
    rows: Sequence[RootInputRow],
    m: int,
    k_min: int,
    k_max: Optional[int],
    rounding_policy: str = DEFAULT_ROUNDING_POLICY,
    trace_prefix: str = "INGRESS",
) -> Tuple[BTNSNumber, ...]:
    """Convenience wrapper returning only projected BTNSNumber roots."""

    return tuple(
        result.number
        for result in ingress_roots_for_m(
            rows=rows,
            m=m,
            k_min=k_min,
            k_max=k_max,
            rounding_policy=rounding_policy,
            trace_prefix=trace_prefix,
        )
    )


# Compatibility aliases for old migration scripts. New code should use BTNS names.
parse_decimal_string_to_btns3 = parse_decimal_string_to_btns
parse_decimal_string_to_btns3_with_trace = parse_decimal_string_to_btns_with_trace


__all__ = [
    "ROUND_TRUNCATE_TOWARD_ZERO",
    "ROUND_NEAREST_TIES_TO_ZERO",
    "ROUND_NEAREST_TIES_TO_EVEN",
    "ROUND_FLOOR_BALANCED",
    "DEFAULT_ROUNDING_POLICY",
    "ALLOWED_ROUNDING_POLICIES",
    "REQUIRED_ROOT_COLUMNS",
    "FORBIDDEN_EXCEL_SUFFIXES",
    "RootInputRow",
    "IngressTrace",
    "IngressResult",
    "infer_k_max_from_root_string",
    "parse_decimal_string_to_btns",
    "parse_decimal_string_to_btns_with_trace",
    "load_root_input_csv",
    "select_roots_for_m",
    "ingress_roots_for_m",
    "ingress_numbers_for_m",
]


if __name__ == "__main__":
    one = parse_decimal_string_to_btns(
        "1",
        k_min=0,
        k_max=None,
        rounding_policy=DEFAULT_ROUNDING_POLICY,
        trace_id="one",
    )
    assert validate_digits(one)
    assert one.digits[0] == 1

    third = parse_decimal_string_to_btns(
        "0.333333333333",
        k_min=-6,
        k_max=None,
        rounding_policy=DEFAULT_ROUNDING_POLICY,
        trace_id="third",
    )
    assert validate_digits(third)
    assert third.k_min == -6

    rows = (
        RootInputRow("G01", 1, "1", "true", ""),
        RootInputRow("G01", 2, "2", "true", ""),
        RootInputRow("G01", 3, "3", "false", ""),
    )
    ing = ingress_roots_for_m(rows, m=2, k_min=0, k_max=None)
    assert len(ing) == 2
    assert all(validate_digits(item.number) for item in ing)
    print("ingress.py self-check PASS")
