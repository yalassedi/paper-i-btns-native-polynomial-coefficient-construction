"""
tests_ingress.py

Unit tests for ingress.py, the CSV/string ingress boundary used by
PythonApplication157 under Script Contract v28.

These tests verify that decimal root strings enter only through the ingress
boundary and are projected into finite BTNSNumber objects before any
coefficient-producing BTNS construction occurs.

The tests cover:
    - exact decimal/scientific-notation parsing at ingress;
    - controlled v28 rounding policies;
    - BTNSNumber projection and ingress trace emission;
    - CSV root loading with the required root-input columns;
    - m=2 root selection, including default root_index selection and explicit
      active_for_m overrides;
    - rejection of Excel inputs;
    - construction-boundary safety: no polynomial construction, egress,
      reporting, or gold-reference calls inside ingress.py.
"""

from __future__ import annotations

import ast
import csv
import inspect
from pathlib import Path
import tempfile
import unittest

import btns_core as core
import ingress


REQUIRED_COLUMNS = [
    "group_id",
    "root_index",
    "root_decimal_string",
    "active_for_m",
    "notes",
]


def write_csv(path: Path, rows: list[dict[str, object]], *, columns: list[str] | None = None) -> None:
    fieldnames = columns or REQUIRED_COLUMNS
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


class TestDecimalStringProjection(unittest.TestCase):
    def test_parse_one_to_btns_number_only_api(self) -> None:
        x = ingress.parse_decimal_string_to_btns(
            "1",
            k_min=0,
            k_max=None,
            rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
            trace_id="PARSE_ONE",
        )

        self.assertIsInstance(x, core.BTNSNumber)
        self.assertTrue(core.validate_digits(x))
        self.assertEqual(x.source_tag, core.SOURCE_INGRESS)
        self.assertEqual(x.digits[0], 1)
        self.assertIsNotNone(x.tail_bound)
        self.assertEqual(x.tail_bound.abs_bound_num, 0)
        self.assertEqual(x.tail_bound.policy, core.TAIL_INGRESS_ROUNDING)

    def test_parse_two_generates_balanced_integer_digits(self) -> None:
        result = ingress.parse_decimal_string_to_btns_with_trace(
            "2",
            k_min=0,
            k_max=None,
            rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
            trace_id="PARSE_TWO",
            group_id="G01",
            root_index=2,
        )

        x = result.number
        self.assertTrue(core.validate_digits(x))
        self.assertEqual(x.digits[0], -1)
        self.assertEqual(x.digits[1], 1)
        self.assertEqual(result.trace.group_id, "G01")
        self.assertEqual(result.trace.root_index, 2)
        self.assertEqual(result.trace.rounding_policy, ingress.DEFAULT_ROUNDING_POLICY)
        self.assertEqual(result.trace.tail_abs_bound_num, 0)

    def test_scientific_notation_is_parsed_at_ingress(self) -> None:
        result = ingress.parse_decimal_string_to_btns_with_trace(
            "1e0",
            k_min=0,
            k_max=None,
            rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
            trace_id="SCI_ONE",
            group_id="G01",
            root_index=1,
        )

        self.assertEqual(result.number.digits[0], 1)
        self.assertEqual(result.trace.original_root_string, "1e0")

    def test_invalid_decimal_strings_are_rejected(self) -> None:
        for bad in ("", "NaN", "Infinity", "abc"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    ingress.parse_decimal_string_to_btns(
                        bad,
                        k_min=0,
                        k_max=None,
                        rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
                        trace_id="BAD",
                    )

    def test_unregistered_rounding_policy_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ingress.parse_decimal_string_to_btns(
                "1",
                k_min=0,
                k_max=None,
                rounding_policy="ROUND_BAD",
                trace_id="BAD_POLICY",
            )


class TestRoundingPolicies(unittest.TestCase):
    def test_nearest_ties_to_zero_rounds_half_to_zero_at_integer_grid(self) -> None:
        x = ingress.parse_decimal_string_to_btns(
            "0.5",
            k_min=0,
            k_max=0,
            rounding_policy=ingress.ROUND_NEAREST_TIES_TO_ZERO,
            trace_id="HALF_TIES_ZERO",
        )

        self.assertEqual(x.digits[0], 0)
        self.assertIsNotNone(x.tail_bound)
        self.assertEqual(x.tail_bound.abs_bound_num, 1)

    def test_nearest_ties_to_even_differs_from_ties_to_zero_on_fractional_grid(self) -> None:
        ties_zero = ingress.parse_decimal_string_to_btns(
            "0.5",
            k_min=-1,
            k_max=0,
            rounding_policy=ingress.ROUND_NEAREST_TIES_TO_ZERO,
            trace_id="HALF_GRID_TIES_ZERO",
        )
        ties_even = ingress.parse_decimal_string_to_btns(
            "0.5",
            k_min=-1,
            k_max=0,
            rounding_policy=ingress.ROUND_NEAREST_TIES_TO_EVEN,
            trace_id="HALF_GRID_TIES_EVEN",
        )

        # At k_min=-1, 0.5 * 3 = 1.5. Ties-to-zero chooses 1;
        # ties-to-even chooses 2 = [-1, +1] at shifted exponents.
        self.assertEqual(ties_zero.digits[-1], 1)
        self.assertEqual(ties_even.digits[-1], -1)
        self.assertEqual(ties_even.digits[0], 1)

    def test_floor_and_truncate_differ_for_negative_fraction(self) -> None:
        floor_value = ingress.parse_decimal_string_to_btns(
            "-0.5",
            k_min=0,
            k_max=0,
            rounding_policy=ingress.ROUND_FLOOR_BALANCED,
            trace_id="NEG_HALF_FLOOR",
        )
        trunc_value = ingress.parse_decimal_string_to_btns(
            "-0.5",
            k_min=0,
            k_max=0,
            rounding_policy=ingress.ROUND_TRUNCATE_TOWARD_ZERO,
            trace_id="NEG_HALF_TRUNC",
        )

        self.assertEqual(floor_value.digits[0], -1)
        self.assertEqual(trunc_value.digits[0], 0)

    def test_infer_k_max_is_safe_for_basic_magnitudes(self) -> None:
        self.assertEqual(ingress.infer_k_max_from_root_string("0"), 0)
        self.assertGreaterEqual(ingress.infer_k_max_from_root_string("1"), 1)
        self.assertGreaterEqual(ingress.infer_k_max_from_root_string("10"), 3)


class TestCSVLoadingAndSelection(unittest.TestCase):
    def test_load_root_input_csv_reads_required_columns(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample_roots_m2.csv"
            write_csv(
                path,
                [
                    {"group_id": "G01", "root_index": 1, "root_decimal_string": "1", "active_for_m": "", "notes": "a"},
                    {"group_id": "G01", "root_index": 2, "root_decimal_string": "2", "active_for_m": "", "notes": "b"},
                ],
            )

            rows = ingress.load_root_input_csv(path)

        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0].group_id, "G01")
        self.assertEqual(rows[0].root_index, 1)
        self.assertEqual(rows[0].root_decimal_string, "1")

    def test_load_root_input_csv_rejects_missing_required_column(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad_roots.csv"
            write_csv(
                path,
                [{"group_id": "G01", "root_index": 1, "root_decimal_string": "1", "active_for_m": ""}],
                columns=["group_id", "root_index", "root_decimal_string", "active_for_m"],
            )

            with self.assertRaises(ValueError):
                ingress.load_root_input_csv(path)

    def test_excel_paths_are_rejected_as_forbidden_input(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            ingress.load_root_input_csv("roots.xlsx")
        self.assertIn("FORBIDDEN_EXCEL_INPUT", str(ctx.exception))

    def test_non_csv_extension_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ingress.load_root_input_csv("roots.txt")

    def test_default_m2_selection_uses_root_indices_one_and_two_per_group(self) -> None:
        rows = (
            ingress.RootInputRow("G02", 3, "30", "", ""),
            ingress.RootInputRow("G02", 1, "10", "", ""),
            ingress.RootInputRow("G02", 2, "20", "", ""),
            ingress.RootInputRow("G01", 1, "1", "", ""),
            ingress.RootInputRow("G01", 2, "2", "", ""),
            ingress.RootInputRow("G01", 3, "3", "", ""),
        )

        selected = ingress.select_roots_for_m(rows, m=2)

        self.assertEqual([(row.group_id, row.root_index) for row in selected], [("G01", 1), ("G01", 2), ("G02", 1), ("G02", 2)])

    def test_explicit_active_for_m_overrides_default_indices(self) -> None:
        rows = (
            ingress.RootInputRow("G01", 1, "1", "false", ""),
            ingress.RootInputRow("G01", 2, "2", "false", ""),
            ingress.RootInputRow("G01", 3, "3", "2", ""),
            ingress.RootInputRow("G01", 4, "4", "2", ""),
        )

        selected = ingress.select_roots_for_m(rows, m=2)

        self.assertEqual([row.root_index for row in selected], [3, 4])

    def test_selection_rejects_group_with_insufficient_roots(self) -> None:
        rows = (ingress.RootInputRow("G01", 1, "1", "", ""),)
        with self.assertRaises(ValueError):
            ingress.select_roots_for_m(rows, m=2)


class TestIngressRootsForM(unittest.TestCase):
    def test_ingress_roots_for_m_returns_traced_btns_roots(self) -> None:
        rows = (
            ingress.RootInputRow("G01", 1, "1", "", ""),
            ingress.RootInputRow("G01", 2, "2", "", ""),
            ingress.RootInputRow("G02", 1, "-1", "", ""),
            ingress.RootInputRow("G02", 2, "0.5", "", ""),
        )

        results = ingress.ingress_roots_for_m(
            rows,
            m=2,
            k_min=-1,
            k_max=1,
            rounding_policy=ingress.ROUND_NEAREST_TIES_TO_ZERO,
            trace_prefix="INGRESS_TEST",
        )

        self.assertEqual(len(results), 4)
        for result in results:
            self.assertIsInstance(result.number, core.BTNSNumber)
            self.assertTrue(core.validate_digits(result.number))
            self.assertEqual(result.number.source_tag, core.SOURCE_INGRESS)
            self.assertEqual(result.trace.source, core.SOURCE_INGRESS)
            self.assertEqual(result.trace.k_min, -1)
            self.assertEqual(result.trace.rounding_policy, ingress.ROUND_NEAREST_TIES_TO_ZERO)
            self.assertEqual(result.number.trace_id, result.trace.trace_id)

    def test_ingress_numbers_for_m_returns_only_numbers(self) -> None:
        rows = (
            ingress.RootInputRow("G01", 1, "1", "", ""),
            ingress.RootInputRow("G01", 2, "2", "", ""),
        )

        numbers = ingress.ingress_numbers_for_m(rows, m=2, k_min=0, k_max=None)

        self.assertEqual(len(numbers), 2)
        self.assertTrue(all(isinstance(number, core.BTNSNumber) for number in numbers))
        self.assertTrue(all(core.validate_digits(number) for number in numbers))

    def test_ingress_trace_as_dict_is_machine_readable(self) -> None:
        result = ingress.parse_decimal_string_to_btns_with_trace(
            "1.25",
            k_min=-2,
            k_max=1,
            rounding_policy=ingress.ROUND_NEAREST_TIES_TO_ZERO,
            trace_id="TRACE_DICT",
            group_id="G01",
            root_index=1,
        )

        row = result.as_dict()
        self.assertIn("trace", row)
        self.assertIn("digits", row)
        self.assertEqual(row["number_trace_id"], result.trace.trace_id)


class TestIngressBoundarySafety(unittest.TestCase):
    def test_ingress_source_uses_no_excel_egress_gold_reporting_or_poly_construction_imports(self) -> None:
        source = inspect.getsource(ingress)
        tree = ast.parse(source)

        forbidden_import_roots = {
            "openpyxl",
            "pandas",
            "xlrd",
            "pyxlsb",
            "egress",
            "gold_reference",
            "reporting",
            "btns_poly",
            "btns_certified",
            "numpy",
            "sympy",
        }
        forbidden_calls = {
            "load_workbook",
            "read_excel",
            "btns_to_decimal_string_for_report",
            "to_decimal",
            "as_decimal",
            "build_polynomial_coeffs_noncertified",
            "build_polynomial_coeffs_certified_independent",
            "build_polynomial_coeffs_noncertified_matched_depth",
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                root = module.split(".")[0]
                self.assertNotIn(root, forbidden_import_roots)
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name):
                    self.assertNotIn(func.id, forbidden_calls)
                elif isinstance(func, ast.Attribute):
                    self.assertNotIn(func.attr, forbidden_calls)

    def test_ingress_source_allows_fraction_only_at_boundary(self) -> None:
        source = inspect.getsource(ingress)
        self.assertIn("from fractions import Fraction", source)
        self.assertNotIn("from decimal", source)
        self.assertNotIn("Decimal(", source)

    def test_compatibility_aliases_return_btns_number(self) -> None:
        x = ingress.parse_decimal_string_to_btns3(
            "1",
            k_min=0,
            k_max=None,
            rounding_policy=ingress.DEFAULT_ROUNDING_POLICY,
            trace_id="ALIAS",
        )
        self.assertIsInstance(x, core.BTNSNumber)
        self.assertTrue(core.validate_digits(x))


if __name__ == "__main__":
    unittest.main(verbosity=2)
