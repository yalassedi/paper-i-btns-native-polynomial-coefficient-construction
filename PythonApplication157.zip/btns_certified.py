"""
btns_certified.py

Certified governance layer for the BTNS-native PythonApplication157
m = 2 package under Script Contract v28.

This module is intentionally construction-boundary safe:
    - no Decimal / Fraction arithmetic
    - no NumPy / SymPy
    - no Excel, workbook, gold-reference, egress, or reporting calls
    - no coefficient construction by decimal arithmetic

Role of this module:
    - provide UCC-style TRUE/TUBE/FALSE classification over integer-scaled
      BTNS interval enclosures;
    - certify operation outputs and coefficient intervals after construction;
    - certify WFC candidates and WFC selections;
    - expose a formal certified refinement request interface;
    - compare Certified vs Non-Certified and Certified vs matched-depth
      Non-Certified outputs without copying either path.

This module does not replace btns_poly.py's independent Certified controller.
Instead, it gives the current campaign runner a clean certification/governance API while
preserving the v28 path-separation rule.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple

from btns_core import (
    BTNSNumber,
    TailBound,
    TAIL_REFINEMENT,
    SOURCE_CERTIFIED,
    btns_equal_digits,
    validate_digits,
)
from btns_poly import (
    CERT_ACCEPT,
    CERT_REBUILD,
    CERT_REFINE,
    CERT_REFINE_REQUEST,
    CERT_REJECT,
    CERT_TUBE_HOLD,
    MATCHED_DEPTH_DIFFERENT,
    MATCHED_DEPTH_EQUAL,
    MATCHED_DEPTH_NOT_RUN_INVALID,
    OperationCertificate,
    PolynomialResult,
    CertifiedPolynomialResult,
    MatchedDepthPolynomialResult,
)
from btns_wfc import (
    WFCCandidate,
    WFCSelectionResult,
    WFCTrace,
    STRICT_PASS,
    WFC_NOT_APPLICABLE,
    WFC_UNDEFINED_STRICT_EMPTY,
    WFC_VALUE_PRESERVATION_FAIL,
    WFC_NO_LEAKAGE_FAIL,
    WFC_SUPPORT_FAIL,
    validate_wfc_trace,
)


TRUE = "TRUE"
TUBE = "TUBE"
FALSE = "FALSE"

CERT_PATH_DISTINCT_FROM_NONCERT = "CERT_PATH_DISTINCT_FROM_NONCERT"
CERT_PATH_IDENTICAL_TO_NONCERT_INVALID = "CERT_PATH_IDENTICAL_TO_NONCERT_INVALID"
CERT_VALUE_EQUAL_TO_NONCERT = "CERT_VALUE_EQUAL_TO_NONCERT"
CERT_VALUE_DIFFERENT_FROM_NONCERT = "CERT_VALUE_DIFFERENT_FROM_NONCERT"
VALUE_IDENTICAL_TRACE_DIFFERENT = "VALUE_IDENTICAL_TRACE_DIFFERENT"
VALUE_DIFFERENT_TRACE_DIFFERENT = "VALUE_DIFFERENT_TRACE_DIFFERENT"
VALUE_IDENTICAL_TRACE_IDENTICAL_INVALID = "VALUE_IDENTICAL_TRACE_IDENTICAL_INVALID"
VALUE_DIFFERENT_TRACE_IDENTICAL_INVALID = "VALUE_DIFFERENT_TRACE_IDENTICAL_INVALID"

WFC_CANDIDATE_CERTIFIED = "WFC_CANDIDATE_CERTIFIED"
WFC_CANDIDATE_REJECTED = "WFC_CANDIDATE_REJECTED"
WFC_SELECTION_CERTIFIED = "WFC_SELECTION_CERTIFIED"
WFC_SELECTION_REJECTED = "WFC_SELECTION_REJECTED"

REFINEMENT_REQUESTED = "REFINEMENT_REQUESTED"
REFINEMENT_NOT_REQUIRED = "REFINEMENT_NOT_REQUIRED"
REFINEMENT_INVALID = "REFINEMENT_INVALID"


@dataclass(frozen=True)
class IntervalEnclosure:
    """Integer-scaled closed interval [lower_num, upper_num] / 3**den_power3."""

    lower_num: int
    upper_num: int
    den_power3: int
    center_num: int
    tail_abs_num: int
    tail_abs_den_power3: int
    source_trace_id: str

    def __post_init__(self) -> None:
        for name in (
            "lower_num",
            "upper_num",
            "den_power3",
            "center_num",
            "tail_abs_num",
            "tail_abs_den_power3",
        ):
            if not isinstance(getattr(self, name), int):
                raise TypeError(f"{name} must be int")
        if self.den_power3 < 0:
            raise ValueError("den_power3 must be non-negative")
        if self.tail_abs_den_power3 < 0:
            raise ValueError("tail_abs_den_power3 must be non-negative")
        if self.tail_abs_num < 0:
            raise ValueError("tail_abs_num must be non-negative")
        if self.lower_num > self.upper_num:
            raise ValueError("lower_num must be <= upper_num")
        if not isinstance(self.source_trace_id, str) or not self.source_trace_id:
            raise ValueError("source_trace_id must be a non-empty string")

    @property
    def width_num(self) -> int:
        return self.upper_num - self.lower_num

    @property
    def width_den_power3(self) -> int:
        return self.den_power3

    def as_dict(self) -> dict[str, object]:
        return {
            "lower_num": self.lower_num,
            "upper_num": self.upper_num,
            "den_power3": self.den_power3,
            "center_num": self.center_num,
            "tail_abs_num": self.tail_abs_num,
            "tail_abs_den_power3": self.tail_abs_den_power3,
            "width_num": self.width_num,
            "width_den_power3": self.width_den_power3,
            "source_trace_id": self.source_trace_id,
        }


@dataclass(frozen=True)
class CoefficientCertificate:
    coefficient_index: int
    coefficient_trace_id: str
    interval: IntervalEnclosure
    decision_token: str
    gold_num: Optional[int]
    gold_den_power3: Optional[int]
    accepted_width_num: int
    accepted_width_den_power3: int
    message: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "coefficient_trace_id": self.coefficient_trace_id,
            "interval": self.interval.as_dict(),
            "decision_token": self.decision_token,
            "gold_num": self.gold_num,
            "gold_den_power3": self.gold_den_power3,
            "accepted_width_num": self.accepted_width_num,
            "accepted_width_den_power3": self.accepted_width_den_power3,
            "message": self.message,
        }


@dataclass(frozen=True)
class CertifiedRefinementRequest:
    root_records: Tuple[object, ...]
    current_k_min: int
    target_k_min: int
    rounding_policy: str
    status: str
    message: str

    def as_dict(self) -> dict[str, object]:
        return {
            "root_records": [str(item) for item in self.root_records],
            "current_k_min": self.current_k_min,
            "target_k_min": self.target_k_min,
            "rounding_policy": self.rounding_policy,
            "status": self.status,
            "message": self.message,
        }


@dataclass(frozen=True)
class WFCCandidateCertificate:
    candidate_id: str
    c_in: int
    q0: int
    legal_digit_status: str
    value_preservation_status: str
    support_status: str
    no_leakage_status: str
    strict_status: str
    decision_token: str
    message: str

    def as_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "c_in": self.c_in,
            "q0": self.q0,
            "legal_digit_status": self.legal_digit_status,
            "value_preservation_status": self.value_preservation_status,
            "support_status": self.support_status,
            "no_leakage_status": self.no_leakage_status,
            "strict_status": self.strict_status,
            "decision_token": self.decision_token,
            "message": self.message,
        }


@dataclass(frozen=True)
class WFCSelectionCertificate:
    wfc_trace_id: str
    selected_candidate_id: Optional[str]
    selected_c_in: Optional[int]
    q0_selected: Optional[int]
    wfc_status: str
    strict_candidate_count: int
    decision_token: str
    message: str

    def as_dict(self) -> dict[str, object]:
        return {
            "wfc_trace_id": self.wfc_trace_id,
            "selected_candidate_id": self.selected_candidate_id,
            "selected_c_in": self.selected_c_in,
            "q0_selected": self.q0_selected,
            "wfc_status": self.wfc_status,
            "strict_candidate_count": self.strict_candidate_count,
            "decision_token": self.decision_token,
            "message": self.message,
        }


@dataclass(frozen=True)
class CandidateAcceptanceRecord:
    accepted: bool
    candidate_id: Optional[str]
    decision_token: str
    reason: str

    def as_dict(self) -> dict[str, object]:
        return {
            "accepted": self.accepted,
            "candidate_id": self.candidate_id,
            "decision_token": self.decision_token,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class PathComparisonRecord:
    coefficient_index: int
    certified_trace_id: str
    other_trace_id: str
    value_comparison_token: str
    path_comparison_token: str
    trace_comparison_token: str

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "certified_trace_id": self.certified_trace_id,
            "other_trace_id": self.other_trace_id,
            "value_comparison_token": self.value_comparison_token,
            "path_comparison_token": self.path_comparison_token,
            "trace_comparison_token": self.trace_comparison_token,
        }


@dataclass(frozen=True)
class MatchedDepthGovernanceRecord:
    coefficient_index: int
    certified_trace_id: str
    matched_trace_id: str
    matched_depth_comparison: str
    copied_trace_invalid: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "coefficient_index": self.coefficient_index,
            "certified_trace_id": self.certified_trace_id,
            "matched_trace_id": self.matched_trace_id,
            "matched_depth_comparison": self.matched_depth_comparison,
            "copied_trace_invalid": self.copied_trace_invalid,
        }


def _stable_id(parts: Iterable[object], length: int = 32) -> str:
    return sha256("|".join(str(part) for part in parts).encode("utf-8")).hexdigest()[:length]


def _pow3(exp: int) -> int:
    if exp < 0:
        raise ValueError("power exponent must be non-negative")
    return 3 ** exp


def _trace_of(x: BTNSNumber) -> str:
    return x.trace_id or "NO_TRACE"


def _tail_pair(tail: Optional[TailBound]) -> tuple[int, int]:
    if tail is None or tail.abs_bound_num == 0:
        return 0, 0
    return tail.abs_bound_num, tail.abs_bound_den_power3


def _align_num(num: int, den: int, common_den: int) -> int:
    if common_den < den:
        raise ValueError("common_den must be >= den")
    return num * _pow3(common_den - den)


def _finite_value_scaled(x: BTNSNumber) -> tuple[int, int]:
    """Return finite digit value as (num, den_power3), no tail included."""

    if not validate_digits(x):
        raise ValueError("finite value scaling requires legal BTNSNumber")
    den = -x.k_min if x.k_min < 0 else 0
    total = 0
    for exponent, digit in x.digits.items():
        total += int(digit) * _pow3(exponent + den)
    return total, den


def compute_tail_bound(x: BTNSNumber) -> TailBound:
    """Return x.tail_bound or a zero bound as a structured TailBound."""

    if not isinstance(x, BTNSNumber) or not validate_digits(x):
        raise ValueError("compute_tail_bound requires a legal BTNSNumber")
    if x.tail_bound is not None:
        return x.tail_bound
    lower_exp = x.k_min
    den_power = -lower_exp if lower_exp < 0 else 0
    return TailBound(
        lower_exp=lower_exp,
        abs_bound_num=0,
        abs_bound_den_power3=den_power,
        policy=TAIL_REFINEMENT,
        source=SOURCE_CERTIFIED,
    )


def make_interval_enclosure(x: BTNSNumber) -> IntervalEnclosure:
    """Build a BTNS interval enclosure using finite digits and TailBound only."""

    center_num, center_den = _finite_value_scaled(x)
    tail = compute_tail_bound(x)
    tail_num, tail_den = _tail_pair(tail)
    common_den = center_den if center_den >= tail_den else tail_den
    center_common = _align_num(center_num, center_den, common_den)
    tail_common = _align_num(tail_num, tail_den, common_den)
    return IntervalEnclosure(
        lower_num=center_common - tail_common,
        upper_num=center_common + tail_common,
        den_power3=common_den,
        center_num=center_common,
        tail_abs_num=tail_common,
        tail_abs_den_power3=common_den,
        source_trace_id=_trace_of(x),
    )


def classify_true_tube_false(
    interval: IntervalEnclosure,
    gold_num: int,
    gold_den_power3: int,
    accepted_width_num: int,
    accepted_width_den_power3: int,
) -> str:
    """Classify interval against an external gold value after construction.

    All quantities are integer-scaled by powers of 3. This function is pure
    post-construction classification; it does not build coefficients or select
    construction candidates.
    """

    for name, value in (
        ("gold_num", gold_num),
        ("gold_den_power3", gold_den_power3),
        ("accepted_width_num", accepted_width_num),
        ("accepted_width_den_power3", accepted_width_den_power3),
    ):
        if not isinstance(value, int):
            raise TypeError(f"{name} must be int")
    if gold_den_power3 < 0 or accepted_width_den_power3 < 0:
        raise ValueError("denominator powers must be non-negative")
    if accepted_width_num < 0:
        raise ValueError("accepted_width_num must be non-negative")

    value_den = interval.den_power3 if interval.den_power3 >= gold_den_power3 else gold_den_power3
    lower = _align_num(interval.lower_num, interval.den_power3, value_den)
    upper = _align_num(interval.upper_num, interval.den_power3, value_den)
    gold = _align_num(gold_num, gold_den_power3, value_den)

    if gold < lower or gold > upper:
        return FALSE

    width_den = interval.width_den_power3 if interval.width_den_power3 >= accepted_width_den_power3 else accepted_width_den_power3
    width = _align_num(interval.width_num, interval.width_den_power3, width_den)
    accepted = _align_num(accepted_width_num, accepted_width_den_power3, width_den)
    if width <= accepted:
        return TRUE
    return TUBE


def certify_coefficient(
    coefficient: BTNSNumber,
    coefficient_index: int,
    *,
    gold_num: Optional[int] = None,
    gold_den_power3: Optional[int] = None,
    accepted_width_num: int = 1,
    accepted_width_den_power3: int = 30,
) -> CoefficientCertificate:
    """Post-construction coefficient certificate.

    If no gold value is supplied, the certificate remains TUBE because external
    truth comparison has not been performed. This keeps gold out of construction.
    """

    if not isinstance(coefficient_index, int):
        raise TypeError("coefficient_index must be int")
    enclosure = make_interval_enclosure(coefficient)
    if gold_num is None or gold_den_power3 is None:
        decision = TUBE
        message = "NO_EXTERNAL_GOLD_SUPPLIED_POST_CONSTRUCTION"
        gnum = None
        gden = None
    else:
        decision = classify_true_tube_false(
            enclosure,
            gold_num,
            gold_den_power3,
            accepted_width_num,
            accepted_width_den_power3,
        )
        message = "POST_CONSTRUCTION_GOLD_CLASSIFICATION"
        gnum = gold_num
        gden = gold_den_power3

    return CoefficientCertificate(
        coefficient_index=coefficient_index,
        coefficient_trace_id=_trace_of(coefficient),
        interval=enclosure,
        decision_token=decision,
        gold_num=gnum,
        gold_den_power3=gden,
        accepted_width_num=accepted_width_num,
        accepted_width_den_power3=accepted_width_den_power3,
        message=message,
    )


def certify_operation(
    operation_name: str,
    output: BTNSNumber,
    inputs: Sequence[BTNSNumber],
    *,
    wfc_result: Optional[WFCSelectionResult] = None,
    decision_token: str = CERT_ACCEPT,
    refinement_status: str = REFINEMENT_NOT_REQUIRED,
) -> OperationCertificate:
    """Create an operation-level certificate compatible with btns_poly.py."""

    if not isinstance(operation_name, str) or not operation_name:
        raise ValueError("operation_name must be a non-empty string")
    if not isinstance(output, BTNSNumber) or not validate_digits(output):
        raise ValueError("output must be a legal BTNSNumber")
    for item in inputs:
        if not isinstance(item, BTNSNumber) or not validate_digits(item):
            raise ValueError("all operation inputs must be legal BTNSNumber objects")

    if wfc_result is None:
        wfc_trace_id = None
        wfc_status = output.wfc_status
        wfc_window_width = None
        wfc_policy = None
        wfc_candidate_count = None
        wfc_strict_candidate_count = None
        wfc_selected_c_in = None
        wfc_selected_candidate_id = None
    else:
        if not validate_wfc_trace(wfc_result.trace, wfc_result.candidates):
            raise ValueError("cannot certify operation with invalid WFC trace")
        wfc_trace_id = wfc_result.trace.wfc_trace_id
        wfc_status = wfc_result.trace.wfc_status
        wfc_window_width = wfc_result.trace.window_width
        wfc_policy = wfc_result.trace.policy
        wfc_candidate_count = wfc_result.trace.candidate_count
        wfc_strict_candidate_count = wfc_result.trace.strict_candidate_count
        wfc_selected_c_in = wfc_result.trace.selected_c_in
        wfc_selected_candidate_id = wfc_result.trace.selected_candidate_id

    operation_id = "CERT_OP_" + _stable_id((operation_name, tuple(_trace_of(x) for x in inputs), _trace_of(output), decision_token), 24)
    return OperationCertificate(
        operation_id=operation_id,
        operation_name=operation_name,
        input_trace_ids=tuple(_trace_of(x) for x in inputs),
        output_trace_id=_trace_of(output),
        k_min=output.k_min,
        k_max=output.k_max,
        tail_bound=output.tail_bound,
        canonicality_status=output.canonicality_flag,
        wfc_trace_id=wfc_trace_id,
        wfc_status=wfc_status,
        wfc_window_width=wfc_window_width,
        wfc_policy=wfc_policy,
        wfc_candidate_count=wfc_candidate_count,
        wfc_strict_candidate_count=wfc_strict_candidate_count,
        wfc_selected_c_in=wfc_selected_c_in,
        wfc_selected_candidate_id=wfc_selected_candidate_id,
        decision_token=decision_token,
        refinement_status=refinement_status,
        certified_construction_token=decision_token,
    )


def request_certified_refinement(
    root_records: Sequence[object],
    current_k_min: int,
    target_k_min: int,
    rounding_policy: str,
    config: object,
) -> CertifiedRefinementRequest:
    """Formal refinement request interface; runner performs actual ingress.

    This function deliberately does not import or call ingress.py. The v28 design
    requires the Certified path to request refinement and the runner to return to
    the ingress boundary.
    """

    if not isinstance(current_k_min, int) or not isinstance(target_k_min, int):
        raise TypeError("current_k_min and target_k_min must be int")
    if not isinstance(rounding_policy, str) or not rounding_policy:
        raise ValueError("rounding_policy must be a non-empty string")
    if target_k_min >= current_k_min:
        return CertifiedRefinementRequest(
            root_records=tuple(root_records),
            current_k_min=current_k_min,
            target_k_min=target_k_min,
            rounding_policy=rounding_policy,
            status=REFINEMENT_INVALID,
            message="target_k_min must be deeper than current_k_min",
        )
    return CertifiedRefinementRequest(
        root_records=tuple(root_records),
        current_k_min=current_k_min,
        target_k_min=target_k_min,
        rounding_policy=rounding_policy,
        status=REFINEMENT_REQUESTED,
        message="runner must re-project the same root strings at target_k_min via ingress.py",
    )


def certify_wfc_candidate(candidate: WFCCandidate) -> WFCCandidateCertificate:
    if not isinstance(candidate, WFCCandidate):
        raise TypeError("candidate must be WFCCandidate")
    if candidate.strict_status == STRICT_PASS and candidate.q0 == 0:
        token = WFC_CANDIDATE_CERTIFIED
        message = "candidate satisfies strict WFC predicates"
    else:
        token = WFC_CANDIDATE_REJECTED
        reasons: list[str] = []
        if candidate.q0 != 0:
            reasons.append("q0 leakage")
        if candidate.value_preservation_status == WFC_VALUE_PRESERVATION_FAIL:
            reasons.append("value preservation fail")
        if candidate.no_leakage_status == WFC_NO_LEAKAGE_FAIL:
            reasons.append("no-leakage fail")
        if candidate.support_status == WFC_SUPPORT_FAIL:
            reasons.append("support fail")
        if not reasons:
            reasons.append("strict_status != STRICT_PASS")
        message = "; ".join(reasons)
    return WFCCandidateCertificate(
        candidate_id=candidate.candidate_id,
        c_in=candidate.c_in,
        q0=candidate.q0,
        legal_digit_status=candidate.legal_digit_status,
        value_preservation_status=candidate.value_preservation_status,
        support_status=candidate.support_status,
        no_leakage_status=candidate.no_leakage_status,
        strict_status=candidate.strict_status,
        decision_token=token,
        message=message,
    )


def certify_wfc_selection(result: WFCSelectionResult) -> WFCSelectionCertificate:
    if not isinstance(result, WFCSelectionResult):
        raise TypeError("result must be WFCSelectionResult")
    valid = validate_wfc_trace(result.trace, result.candidates)
    if result.trace.wfc_status == WFC_NOT_APPLICABLE:
        return WFCSelectionCertificate(
            wfc_trace_id=result.trace.wfc_trace_id,
            selected_candidate_id=result.trace.selected_candidate_id,
            selected_c_in=result.trace.selected_c_in,
            q0_selected=result.trace.q0_selected,
            wfc_status=result.trace.wfc_status,
            strict_candidate_count=result.trace.strict_candidate_count,
            decision_token=WFC_SELECTION_CERTIFIED if valid else WFC_SELECTION_REJECTED,
            message="WFC explicitly not applicable" if valid else "invalid WFC_NOT_APPLICABLE trace",
        )
    if result.trace.wfc_status == WFC_UNDEFINED_STRICT_EMPTY:
        return WFCSelectionCertificate(
            wfc_trace_id=result.trace.wfc_trace_id,
            selected_candidate_id=None,
            selected_c_in=None,
            q0_selected=None,
            wfc_status=result.trace.wfc_status,
            strict_candidate_count=result.trace.strict_candidate_count,
            decision_token=CERT_TUBE_HOLD,
            message="strict WFC family empty; Certified governance may refine, rebuild, hold TUBE, or reject",
        )
    if valid and result.trace.q0_selected == 0 and result.trace.selected_candidate_id is not None:
        token = WFC_SELECTION_CERTIFIED
        message = "selected WFC candidate is trace-valid and no-leakage strict"
    else:
        token = WFC_SELECTION_REJECTED
        message = "selected WFC candidate or trace failed validation"
    return WFCSelectionCertificate(
        wfc_trace_id=result.trace.wfc_trace_id,
        selected_candidate_id=result.trace.selected_candidate_id,
        selected_c_in=result.trace.selected_c_in,
        q0_selected=result.trace.q0_selected,
        wfc_status=result.trace.wfc_status,
        strict_candidate_count=result.trace.strict_candidate_count,
        decision_token=token,
        message=message,
    )


def classify_wfc_status(status: str) -> str:
    """Map WFC status to a Certified governance token."""

    if status == WFC_UNDEFINED_STRICT_EMPTY:
        return CERT_TUBE_HOLD
    if status in {WFC_VALUE_PRESERVATION_FAIL, WFC_NO_LEAKAGE_FAIL, WFC_SUPPORT_FAIL}:
        return CERT_REJECT
    if status == WFC_NOT_APPLICABLE:
        return CERT_ACCEPT
    if isinstance(status, str) and status.startswith("WFC_"):
        return CERT_ACCEPT
    return CERT_REJECT


def certified_candidate_acceptance(candidates: Sequence[Any], *, reason: str = "CERTIFIED_INTERVAL_OR_WFC_ACCEPTANCE") -> CandidateAcceptanceRecord:
    """Accept the first certified candidate according to construction-time metadata.

    This helper never uses external gold or decimal error minimization. It is a
    deterministic construction-time acceptance helper for runner/certified logic.
    """

    for candidate in candidates:
        if isinstance(candidate, WFCCandidate):
            cert = certify_wfc_candidate(candidate)
            if cert.decision_token == WFC_CANDIDATE_CERTIFIED:
                return CandidateAcceptanceRecord(True, candidate.candidate_id, CERT_ACCEPT, reason)
        elif isinstance(candidate, BTNSNumber) and validate_digits(candidate):
            return CandidateAcceptanceRecord(True, _trace_of(candidate), CERT_ACCEPT, reason)
    return CandidateAcceptanceRecord(False, None, CERT_REJECT, "no acceptable certified candidate")


def _compare_coefficients(cert_coeff: BTNSNumber, other_coeff: BTNSNumber, idx: int) -> PathComparisonRecord:
    same_value = btns_equal_digits(cert_coeff, other_coeff)
    same_trace = _trace_of(cert_coeff) == _trace_of(other_coeff)
    if same_value and not same_trace:
        trace_token = VALUE_IDENTICAL_TRACE_DIFFERENT
    elif (not same_value) and not same_trace:
        trace_token = VALUE_DIFFERENT_TRACE_DIFFERENT
    elif same_value and same_trace:
        trace_token = VALUE_IDENTICAL_TRACE_IDENTICAL_INVALID
    else:
        trace_token = VALUE_DIFFERENT_TRACE_IDENTICAL_INVALID

    value_token = CERT_VALUE_EQUAL_TO_NONCERT if same_value else CERT_VALUE_DIFFERENT_FROM_NONCERT
    path_token = CERT_PATH_IDENTICAL_TO_NONCERT_INVALID if same_trace else CERT_PATH_DISTINCT_FROM_NONCERT
    return PathComparisonRecord(
        coefficient_index=idx,
        certified_trace_id=_trace_of(cert_coeff),
        other_trace_id=_trace_of(other_coeff),
        value_comparison_token=value_token,
        path_comparison_token=path_token,
        trace_comparison_token=trace_token,
    )


def compare_certified_path_to_noncertified_path(
    certified_result: CertifiedPolynomialResult,
    noncertified_result: PolynomialResult,
) -> tuple[PathComparisonRecord, ...]:
    if not isinstance(certified_result, CertifiedPolynomialResult):
        raise TypeError("certified_result must be CertifiedPolynomialResult")
    if not isinstance(noncertified_result, PolynomialResult):
        raise TypeError("noncertified_result must be PolynomialResult")
    count = min(len(certified_result.coefficients), len(noncertified_result.coefficients))
    return tuple(
        _compare_coefficients(certified_result.coefficients[idx], noncertified_result.coefficients[idx], idx)
        for idx in range(count)
    )


def compare_certified_path_to_matched_depth_noncertified_path(
    certified_result: CertifiedPolynomialResult,
    matched_result: MatchedDepthPolynomialResult,
) -> tuple[MatchedDepthGovernanceRecord, ...]:
    if not isinstance(certified_result, CertifiedPolynomialResult):
        raise TypeError("certified_result must be CertifiedPolynomialResult")
    if not isinstance(matched_result, MatchedDepthPolynomialResult):
        raise TypeError("matched_result must be MatchedDepthPolynomialResult")
    records: list[MatchedDepthGovernanceRecord] = []
    count = min(len(certified_result.coefficients), len(matched_result.coefficients))
    for idx in range(count):
        cert = certified_result.coefficients[idx]
        matched = matched_result.coefficients[idx]
        equal = btns_equal_digits(cert, matched)
        same_trace = _trace_of(cert) == _trace_of(matched)
        token = MATCHED_DEPTH_EQUAL if equal else MATCHED_DEPTH_DIFFERENT
        if same_trace:
            token = MATCHED_DEPTH_NOT_RUN_INVALID
        records.append(
            MatchedDepthGovernanceRecord(
                coefficient_index=idx,
                certified_trace_id=_trace_of(cert),
                matched_trace_id=_trace_of(matched),
                matched_depth_comparison=token,
                copied_trace_invalid=same_trace,
            )
        )
    return tuple(records)


__all__ = [
    "TRUE",
    "TUBE",
    "FALSE",
    "CERT_PATH_DISTINCT_FROM_NONCERT",
    "CERT_PATH_IDENTICAL_TO_NONCERT_INVALID",
    "CERT_VALUE_EQUAL_TO_NONCERT",
    "CERT_VALUE_DIFFERENT_FROM_NONCERT",
    "VALUE_IDENTICAL_TRACE_DIFFERENT",
    "VALUE_DIFFERENT_TRACE_DIFFERENT",
    "VALUE_IDENTICAL_TRACE_IDENTICAL_INVALID",
    "VALUE_DIFFERENT_TRACE_IDENTICAL_INVALID",
    "WFC_CANDIDATE_CERTIFIED",
    "WFC_CANDIDATE_REJECTED",
    "WFC_SELECTION_CERTIFIED",
    "WFC_SELECTION_REJECTED",
    "REFINEMENT_REQUESTED",
    "REFINEMENT_NOT_REQUIRED",
    "REFINEMENT_INVALID",
    "IntervalEnclosure",
    "CoefficientCertificate",
    "CertifiedRefinementRequest",
    "WFCCandidateCertificate",
    "WFCSelectionCertificate",
    "CandidateAcceptanceRecord",
    "PathComparisonRecord",
    "MatchedDepthGovernanceRecord",
    "compute_tail_bound",
    "make_interval_enclosure",
    "classify_true_tube_false",
    "certify_operation",
    "certify_coefficient",
    "request_certified_refinement",
    "certified_candidate_acceptance",
    "compare_certified_path_to_noncertified_path",
    "compare_certified_path_to_matched_depth_noncertified_path",
    "certify_wfc_candidate",
    "certify_wfc_selection",
    "classify_wfc_status",
]


if __name__ == "__main__":
    from btns_core import make_btns_number_from_digits, add_btns
    from btns_poly import CampaignConfig, build_quadratic_coeffs_certified_independent, build_quadratic_coeffs_noncertified, build_quadratic_coeffs_noncertified_matched_depth
    from btns_wfc import RN_ZERO

    cfg = CampaignConfig(k_min=0, k_max=0, trace_prefix="CERT_SELFTEST", wfc_window_width=0, wfc_policy=RN_ZERO)
    one = make_btns_number_from_digits({0: 1}, 0, 0, trace_id="one")
    two = add_btns(one, one)
    noncert = build_quadratic_coeffs_noncertified(one, two, cfg)
    cert = build_quadratic_coeffs_certified_independent(one, two, cfg)
    matched = build_quadratic_coeffs_noncertified_matched_depth(one, two, cfg.k_min, cfg, cert)

    path_records = compare_certified_path_to_noncertified_path(cert, noncert)
    matched_records = compare_certified_path_to_matched_depth_noncertified_path(cert, matched)
    assert all(record.path_comparison_token == CERT_PATH_DISTINCT_FROM_NONCERT for record in path_records)
    assert all(record.matched_depth_comparison == MATCHED_DEPTH_EQUAL for record in matched_records)
    assert certify_coefficient(cert.coefficients[1], 1).decision_token == TUBE
    print("btns_certified.py self-check PASS")
